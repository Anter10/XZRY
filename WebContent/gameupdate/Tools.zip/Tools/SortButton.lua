local SortButton = class("SortButton", RequireModel.CommonNode)

-- {dir == 2, num = 5, rect = cc.rect(0,215,47,35), callback = callbuttonback, labelnametab = {}}
-- @dir：横着还是竖直方向 @num：RadioButton数量 @rect：RadioButton的位置和宽高，@callback：点击button回调方法 @labelnametab 标签名
function SortButton:ctor(parma)
	self.super.ctor(self)
	self.data = parma

	self.num_of_button = self.data.num         -- button数量
	self.button_width  = self.data.rect.width  -- button宽度
	self.button_height = self.data.rect.height -- button高度
	self.startPosX     = self.data.rect.x      -- 开始buttonX坐标
	self.startPosY     = self.data.rect.y      -- 开始buttonY坐标
    self.labelnametab  = self.data.labelname   -- 标签名
    self.buttonnodetab = {}                    -- RadioButton表
    self.selectviewindex = 1                   -- 当前按钮下标
    
end

-- 初始化button
function SortButton:initButton(normalimage,selectedimage, disabledImage)
	local function buttonCallback(sender)
		self.selectviewindex = sender:getTag()
		self.data.callback(self.selectviewindex)
	end
	for i=1,self.num_of_button do
		local buttonname
		if self.labelnametab and self.labelnametab[i] then
			buttonname = self.labelnametab[i]
		else
			buttonname = nil
		end
		local buttonnode = RequireModel.Button.new(normalimage,selectedimage, disabledImage, buttonname)
		buttonnode:setTag(i)
		local posY = self.startPosY - (10*i + self.button_height * (i+1))
        local posX = self.startPosX + (10*i + self.button_width * (i+1))
        if self.data.dir == 1 then
        	buttonnode:setPosition(cc.p(posX, 0))
        else
        	buttonnode:setPosition(cc.p(0, posY))
        end
		if self.data.dir == 1 then
        	buttonnode:setPosition(cc.p(posX, 0))
        else
        	buttonnode:setPosition(cc.p(0, posY))
        end
        self:addChild(buttonnode)
        buttonnode:setCallback(buttonCallback)
        self.buttonnodetab[#self.buttonnodetab+1] = buttonnode
	end
end

return SortButton