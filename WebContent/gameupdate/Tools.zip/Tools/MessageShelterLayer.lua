local MessageShelterLayer = class("MessageShelterLayer", RequireModel.CommonFullSceneUI)

function MessageShelterLayer:ctor()
	self.super.ctor(self)


	-- 多少秒后将自己移除
	local function remove()
		self:removeSelf()
	end
	
	local delay = cc.DelayTime:create(2)
	local call  = cc.CallFunc:create(remove)
	local seq   = cc.Sequence:create(delay, call)
    self:runAction(seq)
end

function MessageShelterLayer:onExit()
	self:stopAllActions()
end

return MessageShelterLayer