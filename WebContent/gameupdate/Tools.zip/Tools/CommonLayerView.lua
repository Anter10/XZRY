-- 公共的层 用于管理某些通用的UI

local CommonLayerView = class("CommonLayerView",function()
   return cc.Layer:create()
end)

-- 界面的UIID
CommonLayerView.__uiid   = "该层还没有设置界面的ID"
-- 界面类型
CommonLayerView.__type = 1


local graynumber = 0


-- 添加当前半透明的次数
function CommonLayerView.addGrayNumber()
    graynumber = graynumber + 1
    -- printError("添加灰色层")
end

-- 减少当前半透明的次数
function CommonLayerView.cutGrayNumber()
    if graynumber > 0 then
       graynumber = graynumber - 1
    end
end

-- 清空灰色层级
function CommonLayerView.clearGrayNumber()
    graynumber = 0 
end


-- 弹出层级
local alllayerzorder = 100


-- 构造函数
function CommonLayerView:ctor()
	self:enableNodeEvents()
    self.layerrect = nil
    self.isTouchClose = true -- 是否具有点击关闭功能
    self.touches = {}
    self.hasgray = false          -- 是否需要半透明
    self.rsself  = true
end

-- 播放背景音乐
function CommonLayerView:initMusics()
    local uilayer = getSystemData():getGameViewsDataByClassName(self.__cname)
    if uilayer then
       local musics  =  uilayer:getMusic()
       self.musics = getStringArray(musics, ",")
       print(self.__cname,"当前场景的音乐 —————————————————————— ",json.encode(musics))
    end
end

-- 播放背景音乐
function CommonLayerView:playMusic()
       if self.musics and #self.musics > 0 and tonumber(self.musics[1]) ~= 0 then
          local ismusic = false
          if #self.musics == 1 then
             ismusic = true
          end
           for audoIndex,audioid in ipairs(self.musics) do
               local data = getSystemData():getGameMusicById(audioid)
               if data then
                  self.hasmusics   = true
                  local musiclfile = "UI_music/"..data:getFileName()
                  local loop       = data:getLoop()
                  RequireModel.GameMusic.playMusic(musiclfile, loop, ismusic)
               end
           end

        end
end


function CommonLayerView:stopEffect()
    if self.musics and #self.musics > 0 and RequireModel.GameMusic.musicName and tonumber(self.musics[1]) ~= 0 then
       print("1停止音乐1")
       RequireModel.GameMusic.stopAllEffects(function() self:playMusic() end)
    else
       print("1停止音乐2")
       self:playMusic()
    end
end

-- 是否需要半透明
function CommonLayerView:hasGrayLayer()
    return self.hasgray
end

-- 得到界面的ID
function CommonLayerView:getUIID()
    return self.__uiid
end

-- 设置界面的ID
-- @uiid: 设置的界面ID
function CommonLayerView:setUIID( uiid )
    self.__uiid = uiid
end
function CommonLayerView:startMusic()
    self:initMusics()
    self:stopEffect()
end
-- 进入节点
function CommonLayerView:onEnter()
    self:startMusic()
    print("进入几点男男女女男男女女男女"..self.__cname)
    -- self.shadelayer = RequireModel.CommonLayerView.new()
    -- self.shadelayer:OpenTouch()
    -- self:addChild(self.shadelayer)
    -- local isshade = true
    -- local function updata(delta)
    --     isshade = false
    --     if self.shadelayer then
    --         self.shadelayer:removeFromParent(true)
    --         self.shadelayer = nil 
    --     end
    -- end
    -- self.schedulyid = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updata,0.1,false)
    
    -- self:addKeyboardListener()
end

-- 点击关闭回调函数
function CommonLayerView:touchCloseCallback()
    -- UIJump:backTo()
end

-- 点击结束回调函数
function CommonLayerView:setTouchEndedCallback()
    
end

function CommonLayerView:backToCall()
    print("返回的数据  = ",UIJump:getBackData())
end

-- 设置节点名称
function CommonLayerView:setNodeName(uiid)
    self:setName(tostring(uiid))
end

-- 设置点击区域范围
function CommonLayerView:setTouchRect(rect)
    self.layerrect = rect
end

function CommonLayerView:becomeBlackBackground()
     -- printError("当前添加的半透明层数  = "..tostring(graynumber))
     if graynumber == 0 then
        CommonLayerView.addGrayNumber()
        local sz = cc.c4f(0,0,0,146)
        self._layer = cc.LayerColor:create(sz)
        
        self._layer:setContentSize(cc.size(winsize.width + 400, winsize.height + 400))
        self._layer:setAnchorPoint(cc.p(0.5, 0.5))
        self._layer:setPosition(cc.p(-200, -200))
        
        self:addChild(self._layer,-1)   
     end
     self.hasgray = true
end

-- 设置是否可以点击关闭当前层
function CommonLayerView:setTouchClose(flag)
    self.isTouchClose = flag
end


function CommonLayerView:openMoreTouch()
        -- 开始触摸
    -- local function onTouchesBegan(touches, event)
    --     for i,touch in next,touches do
    --         -- print("点击数目12  = ",#self.touches)
    --         if #self.touches < 2 then
    --            table.insert(self.touches,touch)
    --            -- print("点击数目  = ",#self.touches)
    --            if #self.touches >= 2 then
    --               self.listener:setSwallowTouches(true)
    --               return false
    --            end
    --         else
    --            break
    --         end
    --      end
    --      return true
    -- end

    -- -- 移动触摸
    -- local function onTouchesMoved(touchs, event)
    --     -- self:onTouchMoved(touchs,event)
    -- end

    -- -- 结束触摸
    -- local function onTouchesEnded(touchs, event)
    --      for k,ttouch in pairs(touchs) do
    --          for touchesIndex,touch in pairs(self.touches) do
    --              if touch ==  ttouch then
    --                 table.remove(self.touches, touchesIndex)
    --              end
    --          end

    --      end
    --      if #self.touches < 2 then
    --         self.listener:setSwallowTouches(false)
    --      end
    -- end

    -- self.listener  = cc.EventListenerTouchAllAtOnce:create()
    -- self.listener:registerScriptHandler(onTouchesBegan,cc.Handler.EVENT_TOUCHES_BEGAN )
    -- self.listener:registerScriptHandler(onTouchesMoved,cc.Handler.EVENT_TOUCHES_MOVED )
    -- self.listener:registerScriptHandler(onTouchesEnded,cc.Handler.EVENT_TOUCHES_ENDED )
    -- local eventDispatcher = self:getEventDispatcher()
    -- eventDispatcher:addEventListenerWithSceneGraphPriority(self.listener , self)
end


--打开触摸
function CommonLayerView:OpenTouch()
    if self.listener~=nil then
        return
    end
    self.listener = cc.EventListenerTouchOneByOne:create()
    -- 开始触摸
    local function onTouchBegan(touch, event)
        local c=self:getParent()
        while c~=nil do 
            if c:isVisible()==false then
                return false
            end
            c=c:getParent()
        end

        return self:onTouchBegan(touch,event)
    end

    -- 移动触摸
    local function onTouchMoved(touch, event)
        self:onTouchMoved(touch,event)
    end

    -- 结束触摸
    local function onTouchEnded(touch, event)
        self:onTouchEnded(touch, event)
    end

    self.listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    self.listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
    self.listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
    self.eventDispatcher = self:getEventDispatcher()
    self.listener:setSwallowTouches(true)
    self.eventDispatcher:addEventListenerWithSceneGraphPriority(self.listener, self)
end


-- 移除触事件
function CommonLayerView:removeTouchEvent()
    if self.listener then
        self.listener:setSwallowTouches(false)
        self.eventDispatcher:removeEventListenersForType(cc.EVENT_TOUCH_ONE_BY_ONE)
        self.listener = nil
    end
end


--设置是否吞吃触摸
function CommonLayerView:setSwallowTouches(needSwallow)
    self.listener:setSwallowTouches(needSwallow)
end

-- 触摸开始
function CommonLayerView:onTouchBegan(touch, event)
	 return true
end

-- 触摸移动
function CommonLayerView:onTouchMoved(touch, event)
	 
end

-- 触摸结束
function CommonLayerView:onTouchEnded(touch, event)
    local touchPoint = touch:getLocation()
	if self.layerrect and not cc.rectContainsPoint(self.layerrect,cc.p(touchPoint.x, touchPoint.y)) and self.isTouchClose then
        self:touchCloseCallback()
    elseif self.layerrect and cc.rectContainsPoint(self.layerrect,cc.p(touchPoint.x, touchPoint.y)) then
        self:setTouchEndedCallback()
    end
end

-- 退出节点
function CommonLayerView:onExit()
	if self.Cleanupresources then
		self:Cleanupresources()
	end
end

-- 处理网络数据请求
function CommonLayerView:dealSocketData(data)
	 
end

-- 弹出自己
function CommonLayerView:Show()
    alllayerzorder = alllayerzorder + 1
    local rootnode = getCurrentRunNode()
    ---- print("CommonLayerView type = ",type(rootnode))
    if rootnode then
       rootnode:addChild(self,1280)
    end
end

-- rs:不需要自己删除
function CommonLayerView:setRemoveSelf(rs)
    self.rsself = rs
    print(self.__cname,"rs",rs)
    --printError("当前的view")
end

function CommonLayerView:isRemoveSelf()
    return self.rsself 
end

-- 移除自己
function CommonLayerView:removeSelf()
        alllayerzorder = alllayerzorder - 1
    	self:removeFromParent(true)
    	self = nil
 
end

return CommonLayerView
