-- 对话框管理类
local RolesDialogManager = class("RolesDialogManager",{})


function RolesDialogManager:ctor()
	-- 游戏系统对话框条件初始
    
end


-- 给定界面判断是否有对话框产生
function RolesDialogManager:hasCondition()
	 
end

-- 根据界面ID  判断当前的界面中是否有
-- @uiid: 界面的ID
function RolesDialogManager:checkConditionBuUIId(uiid, dialogid)
	 
end

-- 设置剧情对话完成后的回调函数
function RolesDialogManager:setFinishCallback( finishCall )
	self.finishCall = finishCall
end





return RolesDialogManager