--按钮
local Button=class("Button",RequireModel.CommonNode)

function Button:ctor(normalImage,selectedImage,disabledImage, string)
	self.super.ctor(self)
	self.id=0
	self.parentisscrollview=false

	self.isfocuscanceloffsetininch=false--是否通过触摸移动距离取消触摸
	self.focuscanceloffsetininch=7/160--取消触摸的距离
	self.touchbeganposition=cc.p(0,0)--开始触摸的位置
	self.isfocuscanced=false--是否已经取消触摸
	self.focuscancedcallback=nil--触摸取消时的回调函数

	self.jumptime = 0--getSystemData():getGameTimesDataById(AboutGameTimes.openchestitemtime):getValue()  -- 缩放比例
	self.scalenum = getSystemData():getGameTimesDataById(23):getValue() -- 缩放比例

	self.parentscrollviewnode=nil
	-- 正常状态下的表现
	self.normalSprite       = nil
	-- 选中状态的表现
	self.selectedSprite     = nil
	-- 放开点击后的表现
	self.disabledSprite     = nil
	-- 选中后的调用方法
	self.selectedcallback   = nil
	-- 放开后的调用方法
	self.unselectedcallback = nil
    -- 设置按钮的点击事件
	self.callback           = nil
	-- 设置标签
	self.label              = nil
	--随按钮缩放的子节点集合
	self.scalechildtab		= {}
	
	
    -- self.size = cc.size(120, 80)
    -- self:setContentSize(cc.size(120, 80))
	if normalImage~=nil then
		if type(normalImage)=="userdata" then
			self.normalSprite=cc.Sprite:createWithSpriteFrame(normalImage)
		elseif type(normalImage)=="string" then
			self.normalSprite=createSprite(normalImage)
		end
		local size = self.normalSprite:getContentSize() 
		self.size  = self.normalSprite:getContentSize() 
		self:setContentSize(self.size)
		self.normalSprite:setPosition(size.width/2,size.height/2)
		self:addChild(self.normalSprite, -1)
		-- local layer = cc.LayerColor:create(cc.c4f(244,122,111,255))
	 --     layer:setContentSize(self.size)
	 --     self:addChild(layer,10)
		self.normalfile = normalImage
	end
	if selectedImage~=nil then
		if type(selectedImage)=="userdata" then
			self.selectedSprite=cc.Sprite:createWithSpriteFrame(selectedImage)
		elseif type(selectedImage)=="string" then
			self.selectedSprite=createSprite(selectedImage)
		end
		local size = self.selectedSprite:getContentSize() 
		self.selectedSprite:setPosition(size.width/2,size.height/2)
		self:addChild(self.selectedSprite, -2)
	end
	if disabledImage ~= nil then
	   if type(disabledImage)=="userdata" then
		  self.disabledSprite=cc.Sprite:createWithSpriteFrame(disabledImage)
	   elseif type(disabledImage)=="string" then
		  self.disabledSprite=createSprite(disabledImage)
	   end
	   local size = self.disabledSprite:getContentSize()
	   self.disabledSprite:setPosition(size.width/2,size.height/2)
	   self:addChild(self.disabledSprite,-3)
	end
	if string ~= nil then
		if self.normalSprite then
			self.labelsize = self.normalSprite:getContentSize()
		else
			self.labelsize = cc.size(0,0)
		end
		self.label = Font.getTextLabel(string,22,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(self.labelsize.width/2,self.labelsize.height/2),32,false)
	end
	
	self:setAnchorPoint(0.5,0.5)
	if self.normalSprite then
	   self:setContentSize(self.normalSprite:getContentSize())
	elseif self.label then
		self:setContentSize(self.label:getContentSize())
		self.label:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
	end
	
    
	self:OpenTouch()
	self.isselected=false
	self:setbuttonbyselected()
end

-- 得到三张图片
function Button:getNSESprite()
	return self.normalSprite, self.selectedSprite ,self.disabledSprite
end

-- 设置音效类型
-- @at: 音效类型
function Button:setStartAudio( at )
	self.audiotype = at
end

-- 得到音效类型
function Button:getStartAudio()
	return self.audiotype
end
-- 得到正常状态下的技能图片
function Button:getNormalFile()
	return self.normalfile
end

function Button:getSize()
	return self.size
end
-- 设置按钮的缩放尺寸
-- @tscale: 点击的时候缩放的尺寸
function Button:setChangeScale( tscale )
	local scale = 1.1
	if tscale then
	   scale = tscale
	end
	self.selectedSprite:setScale(scale)
end
-- 刷新现实的图标
function Button:setTextures( normal, selected, enable )
	 if self.normalSprite and normal then
	 	self.normalSprite:setTexture(normal)
	 	self.normalfile = normal
	 end
	 if self.selectedSprite  and selected then
        self.selectedSprite:setTexture(selected)
	 end
	 if self.disabledSprite and enable then
        self.disabledSprite:setTexture(enable)
	 end
end

function Button:setParentScrollview(scrollviewnode)
	self.parentisscrollview=true
	self.parentscrollviewnode=scrollviewnode
	self:setSwallowTouches(false)
end

function Button:setIsFocusCancelOffsetIninch(is)
	self.isfocuscanceloffsetininch=is
end
function Button:setFocusCancedCallback(funcallback)
	self.focuscancedcallback=funcallback
end
function Button:setLabelText(string)
	if self.label then
		self.label:setString(string)
	end
end
--设置按钮按下回调函数
function Button:setSelectedCallback(funcallback)
	self.selectedcallback=funcallback
end
--设置按钮未被按下回调函数
function Button:setunSelectedCallback(funcallback)
	self.unselectedcallback=funcallback
end

--设置按钮回调函数
function Button:setCallback(funcallback)
	self.callback = funcallback
end

-- 触摸开始
function Button:onTouchBegan(touch, event)
	print("onTouchBegan",json.encode(self:getContentSize()))
	 if self.audiotype then
        playUIAudio(self.audiotype)
	 end
	 if self.parentisscrollview then
		if self.parentscrollviewnode:isNodeVisible(self)==false then
		   return false
		end
	 end
	 print("2 = ",self.enableTouch)
	 if not self:isEnabled() then
        return false
	 end
	 print("1")
	 if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
		self.touchbeganposition=touch:getLocation()
		self.isfocuscanced=false
		self:setselected(true)
		return true
	 end
	 print("3")
	return false
end


-- 触摸移动
function Button:onTouchMoved(touch, event)
	if self.isfocuscanceloffsetininch and self.isfocuscanced==false then
		if twoPointDistance(self.touchbeganposition.x,self.touchbeganposition.y,touch:getLocation().x,touch:getLocation().y)>self.focuscanceloffsetininch then
			self.isfocuscanced=true
			if self.focuscancedcallback then
			   self.focuscancedcallback(self)
			end
		end
	end
	if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
		self:setselected(true)
	else
		self:setselected(false)
    end
end

-- 设置点击开始按钮缩放
function Button:setTouchBeagnButtonScale()
	local scaleaction = cc.ScaleTo:create(self.jumptime, self.scalenum)
	if self.normalSprite then
	   self.normalSprite:runAction(scaleaction:clone())
	end
	if self.selectedSprite then
	   self.selectedSprite:runAction(scaleaction:clone())
	end
	if self.disabledSprite then
	   self.disabledSprite:runAction(scaleaction:clone())
	end
end

-- 设置点击结束结束按钮复原
function Button:setTouchEndedButtonScale()
	local scaleaction = cc.ScaleTo:create(self.jumptime, 1)
	
	if self.normalSprite then
	   self.normalSprite:stopAllActions()
	   self.normalSprite:runAction(scaleaction:clone())
	end

	if self.selectedSprite then
		self.selectedSprite:stopAllActions()
		self.selectedSprite:runAction(scaleaction:clone())
	end
	if self.disabledSprite then
		self.disabledSprite:stopAllActions()
		self.disabledSprite:runAction(scaleaction:clone())
	end

    local delayaction =	cc.DelayTime:create(self.jumptime)
	-- function jumpCallback()
	-- 	printError("按钮回调函数 = ")
	-- 	print(self.callback)
	-- 	if self.callback then
	-- 	   self.callback(self)
	-- 	   print("回调过吗")
	-- 	end
	-- end
	-- local callfunc = cc.CallFunc:create(jumpCallback)
	-- self:stopAllActions()
	-- self:runAction(cc.Sequence:create(delayaction, callfunc))
	if self.callback then
	   self.callback(self)
	   print("回调过吗")
    end
end

-- 得到当前是否还在按钮上面
function Button:getIsSelected()
	return self.isselected
end	

-- 触摸结束
function Button:onTouchEnded(touch, event)
	print("onTouchEnded")
	self:setselected(false)
	if not self:isVisible() then
       return
	end
	print("4545")
	if self.parentisscrollview then
		if self.parentscrollviewnode:isTouchMoved() then
			return
		end
	end
	print("6666")
	if self.isfocuscanced==false then
		if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
			if self.callback then
			   self.callback(self)
			end
		end
	end
end

--设置按钮是否可按
function Button:setTouchEnabled(enable)
    self.super.setTouchEnabled(self,enable)
    self:setbuttonbyselected()
end

function Button:isEnabled()
	return self.enableTouch
end

--设置按钮是否被按下
function Button:setselected(selected)
	if self.isselected == selected then
		return
	end
	self.isselected = selected
	self:setbuttonbyselected()
	if self.isselected then
		if self.selectedcallback then
		   self.selectedcallback(self)
		end
	else
		if self.unselectedcallback then
			self.unselectedcallback(self)
		end
	end
end

function Button:setbuttonbyselected()
	if self.enableTouch==false and self.normalSprite then
		self.selectedSprite:setVisible(false)
		if self.disabledSprite then
			self.normalSprite:setVisible(false)
			self.disabledSprite:setVisible(true)
			self:setScaleChild(self.disabledSprite:getScale())
		else
			self.normalSprite:setVisible(true)
			self:setScaleChild(self.normalSprite:getScale())
		end
	else
		if self.disabledSprite then
			self.disabledSprite:setVisible(false)
		end
		if self.isselected and self.normalSprite and self.selectedSprite then
			self.normalSprite:setVisible(false)
			self.selectedSprite:setVisible(true)
			self:setScaleChild(self.selectedSprite:getScale())
		elseif self.normalSprite then
			self.normalSprite:setVisible(true)
			self.selectedSprite:setVisible(false)
			self:setScaleChild(self.normalSprite:getScale())
		end
	end
end
function Button:setScaleChild(scalenum)
	for i=1,#self.scalechildtab do
		self.scalechildtab[i]:setScale(scalenum)
	end
end

function Button:setFlippedX(flippedX)
	if self.normalSprite then
	   self.normalSprite:setFlippedX(flippedX)
	end
	if self.selectedSprite then
	   self.selectedSprite:setFlippedX(flippedX)
	end
	if self.disabledSprite then
	   self.disabledSprite:setFlippedX(flippedX)
	end
end

-- 让按钮变灰
function Button:setGray()
	self.enableTouch = false
	print("ABC",self.enableTouch)
	if self.normalSprite then
		print("ABC12")
	   setGray(self.normalSprite)
	end
end


-- 返回正常状态下的按钮
function Button:getNormalButton()
	return self.normalSprite
end

-- 设置按钮的类型
function Button:setSizeType( st )
	self.st = st 
end

-- 给按钮添加 CD 时间
function Button:addCdTime()
	 
	 if not self.cdtime then
	 	local size = self.normalSprite:getBoundingBox()
	 	local spss = self.normalfile
	 	if self.st == 1 then 
	 	   spss = "skill_200804.png"
	 	end
	    local sprite = cc.Sprite:create(spss)
	    self.cdtime  = cc.ProgressTimer:create(sprite)
	    self.cdtime:setOpacity(125)
	    -- setGray(self.cdtime)
	    self.cdtime:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
	    self.cdtime:setPosition(cc.p(size.width / 2 + 10, size.height / 2 + 10))
	    self:addChild(self.cdtime)
     end
     -- self.cdtime:setPercentage(50)
     local to1  = cc.ProgressFromTo:create(0.5, 100,0)
     print("self.position = ",self:getPositionX(), self:getPositionY())
     self.cdtime:runAction(to1)
end


-- 恢复颜色
function Button:recoverNormal()
	printError("什么时候回复的 "..self.normalfile)
	if self.normalSprite then
		self.normalSprite:removeFromParent(true)
		self.normalSprite = cc.Sprite:create(self.normalfile)
		self.cdtime = nil
		local size = self.normalSprite:getContentSize() 
		if self.normalSprite then
           self.normalSprite:setPosition(size.width/2,size.height/2)
		   self:addChild(self.normalSprite)
		   self.enableTouch = true
	    end
	    if self.selectedSprite then
           self.selectedSprite:setPosition(size.width/2,size.height/2)
	    end
	    if self.disabledSprite then
           self.disabledSprite:setPosition(size.width/2,size.height/2)
		end
    end
end
-- 添加点击的播放特效
-- @effect: 播放的特效
function Button:addClickEffect( effect )
	   local size = self.normalSprite:getBoundingBox()
	   effect:setAnchorPoint(cc.p(0.5,0))
	   effect:setPosition(size.width/2,size.height/2)
	   self:addChild(effect,1200) 
	   if self.st == 1 then
	    
	   else
	   	  effect:setScale(0.7)
	   end
	   -- printError("设置技能的特效")
	   self:addCdTime()
end

-- 得到正常图片的尺寸
function Button:getNormalSize()
	return self.normalSprite:getBoundingBox()
end

-- 设置按钮的ID
-- @id: 按钮的ID
function Button:setID(id)
	self.id = id
end

-- 得到按钮的ID
function Button:getId()
	return self.id
end

return Button
