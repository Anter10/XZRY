--
-- Author: qian.when
-- Date: 2016-09-07 14:08:20
 
local DialogView = class("DialogView", RequireModel.CommonLayerView)
local textdata1 = {
    text = "文本内容",
    bottom = "diban32.png",
    func = nil
}
local textdata = {
    {
      bottom = "diban41.png",
      icon = "i400001.png",
      text = "文本内容1",
    },
    {
      bottom = "diban41.png",
      icon = "i400002.png",
      text = "文本内容2",
    },
    {
      bottom = "diban41.png",
      icon = "i400007.png",
      text = "文本内容3",
    },
    {
      bottom = "diban41.png",
      icon = "i400012.png",
      text = "文本内容4",
    },
}
function DialogView:ctor(id, cantrm)
  	self.super.ctor(self)
    self.size   = cc.size(420,60)

    self:OpenTouch()
    self:setSwallowTouches(true)
    self.selectedcallback = nil   -- 按下回调函数
    self.unselectedcallback = nil -- 不按回调函数
    
    self.fontsize = 24
    if tonumber(id) then
        self:addCcb()
       self.data   = getSystemData():getDialogViewDataById(id)
       if self.data:getSize() ~= 0 then
          self.size   = self.data:getSize()
       end
       self.showtype = self.data:getShowType()
       self.info     = self.data:getInfo()
       self.isaddbottom = self.data:getTypeNum()
      
        self:setContentSize(self.size)
        self:setPosition(cc.p(winsize.width / 2, winsize.height / 2 + 120))
        -- 记录对话框中的按钮
        self.buttons = {}
        self:initBtn(cantrm)
        self.fontsize = self.data:getFontSize()

        -- self:initCtor()
    else
        self.data = id
        self.showtype = self.data:getShowType()
        self:initCtor()
    end
end




function DialogView:initCtor()
    self:becomeBlackBackground()
    if self.showtype == 11 then
        self:addSureDialog(textdata1)
    elseif self.showtype == 12 then
      self:addInfomationDialog()
    elseif self.showtype == 13 then      
      self:addBubbleDialog()
    end
end

-- 添加ccb
function DialogView:addCcb()
    self.dialognode = nil
    self.dialogntab = {}

    ccb["OperationTipNode"]=self.dialogntab
    local proxy = cc.CCBProxy:create()
    self.dialognode = CCBReaderLoad("com_ui_qp_qp01.ccbi",proxy,self.dialogntab)
    -- self.dialognode:setPosition(winsize.width/2,winsize.height/2)
    self:addChild(self.dialognode)
end
 
--初始化对话框中的按钮节点
function DialogView:initBtn(cantrm)
    self.cantrm  =  cantrm
 

    print("self.showtype = ",self.cantrm)
    if self.showtype == ShowDialogType.SR then
        -- if tonumber(self.isaddbottom) == 2 then
        --     local sz = cc.c4f(0,0,0,146)
        --     self._layer = cc.LayerColor:create(sz)
        --     self._layer:setAnchorPoint(cc.p(1,0.5))
        --     self._layer:setContentSize(cc.size(100, 80))
        --     self._layer:setPosition(self.size.width / 2-210,self.size.height / 2-25)
        --     self:addChild(self._layer,-1)   
        -- end 
        -- self.showNearReleaseSkillMessage =  Font.getTextLabel(self.info,self.fontsize,cc.c4f(222,11,11,255),self.size,cc.TEXT_ALIGNMENT_LEFT,nil,cc.p(0.5,0.5),self,cc.p(self.size.width / 2,self.size.height / 2),32,false)
        self.textview =  Font.getTextById(self.info)
        if not self.textview then
           self.showNearReleaseSkillMessage =  Font.getTextLabel(self.info,self.fontsize,cc.c4f(222,11,11,255),nil,nil,nil,cc.p(0.5,0.5),self.dialogntab["tipinformation"]:getParent(),cc.p(self.dialogntab["tipinformation"]:getPositionX(),self.dialogntab["tipinformation"]:getPositionY()),32,false)
        else
           self:addChild(self.textview,10)
           self.textview:setPosition(cc.p(self.dialogntab["tipinformation"]:getPositionX(),self.dialogntab["tipinformation"]:getPositionY()))
        end
        self.dialogntab["tipinformation"]:removeFromParent()

        local function removeCall()
            if not self.cantrm then
               self:removeFromParent()
            end
            -- print("sdsds")
        end
    
        local moveTo   = cc.MoveBy:create(1, cc.p(0, 120))
        local callFunc = cc.CallFunc:create(removeCall)
        local seq      = cc.Sequence:create(moveTo, callFunc)
        if not self.cantrm then
           self:runAction(seq)
        end
     elseif self.showtype == ShowDialogType.TO then
        --                  
     elseif self.showtype == ShowDialogType.TB then
        local dialogBtn = nil
		    for i=1,tonumber(self.data:getTypeNum()) do
			      dialogBtn = RequireModel.Button:create(self.data:getButton1Text(),self.data:getButton2Text(),self.data:getButton3Text(),self.data:getInfo())
			      self.buttons[#self.buttons + 1] = dialogBtn
			      self:addChild(dialogBtn)
		    end
     end
	
end

-- 设置确认弹框
function DialogView:addSureDialog(data)
    self.background = createSprite(data.bottom)
    self.background:setPosition(winsize.width/2, winsize.height/2)
    self:addChild(self.background)
    self.layersize = self.background:getContentSize()

    local label = Font.getTextLabel("提示", 24,nil,nil,1,nil,cc.p(0.5, 0.5),self.background,cc.p(self.layersize.width/2,self.layersize.height-30),1,false)
    -- Font.getTextLabel("文本内容", 24,nil,nil,1,nil,cc.p(self.layersize.width/2, self.layersize.height/2),self,cc.p(0.5,0.5),1,false)
    -- print("label = ",label)
    Font.getTextLabel(data.text, 24,nil,nil,1,nil,cc.p(0.5, 0.5),self.background,cc.p(self.layersize.width/2,self.layersize.height/2),1,false)
    local function sureCallback()
      if data.func then
        data.func()
      end
      UIJump:backTo()
    end
    self.surebutton = RequireModel.Button.new("ui_bt_headdi_01.png","ui_bt_headdi_01.png",nil,"确定")
    self.surebutton:setPosition(self.layersize.width/2,80)
    self.background:addChild(self.surebutton)
    self.surebutton:setCallback(sureCallback) 

    self:setCloseButton()
end

-- 添加信息展示弹框
function DialogView:addInfomationDialog()
  self.models = {} 
  for index,data in pairs(textdata) do
      self.models[#self.models+1] = self:createInmationContent(data)
  end

  local listviewdata = {
        dir    = 2,                                             -- listview摆放方向
        size   = cc.size(200,480),        -- 视图大小
        models = self.models,             -- listview加载视图
        leftcall = nil,                   -- 滑动到最左边回调函数
        rightcall = nil,                  -- 滑动到最右边回调函数
        upcall =nil,                      -- 滑动到最上边回调函数
        bottomcall = nil,                 -- 滑动到最下面回调函数

        leftbuttoncall = func,             -- 上下按钮回调函数
  
        background = "UI_bottom/diban42.png",     -- listview背景图片
        MagneticType = 1,                  -- 视图放置类型
        bounce       = true,              -- 是否弹性回复
    }
    
    self.barlistviewnode = RequireModel.ListviewNode.new(listviewdata)
    self.barlistviewnode:setPosition(winsize.width/2, winsize.height/2)
    self.barlistviewnode:setAnchorPoint(cc.p(0.5,0.5))
    self:addChild(self.barlistviewnode)
end

-- 添加信息弹框层内容
function DialogView:createInmationContent(data)
    local itemlayer = cc.Layer:create()
    local bottom = createSprite(data.bottom)
    local size = bottom:getContentSize()
    bottom:setPosition(size.width/2, size.height/2)
    itemlayer:addChild(bottom)
    itemlayer:setContentSize(size)
    Font.getTextLabel(data.text, 24,nil,nil,1,nil,cc.p(0.5, 0.5),bottom,cc.p(size.width/2,size.height/2),1,false)
    local function iconCallback()
        
    end
    local icon = RequireModel.Button.new(data.icon,data.icon)
    local iconsize = icon:getContentSize()
    icon:setPosition(iconsize.width/2,size.height/2)
    bottom:addChild(icon)
    icon:setCallback(closeCallback) 
    return itemlayer
end

-- 添加信息气泡弹框
function DialogView:addBubbleDialog()
    local bottom = createSprite("diban41.png")
    local size = bottom:getContentSize()
    bottom:setAnchorPoint(cc.p(0,0))
    bottom:setPosition(winsize.width/2-size.width/2, winsize.height/2-size.height/2)
    self:addChild(bottom)
    self.touchrect = cc.rect(winsize.width/2-size.width/2, winsize.height/2-size.height/2, size.width, size.height)
    Font.getTextLabel("文本内容", 24,nil,nil,1,nil,cc.p(0.5, 0.5),bottom,cc.p(size.width/2,size.height/2),1,false)
end

-- 添加关闭按钮
function DialogView:setCloseButton()
  local function closeCallback()
      UIJump:backTo()
  end
  self.quitbutton = RequireModel.Button.new("ui_bt_headdi_01.png","ui_bt_headdi_01.png",nil,"退出")
  local size = self.quitbutton:getContentSize()
  self.quitbutton:setPosition(self.layersize.width-size.width/2,self.layersize.height-size.height/2)
  self.background:addChild(self.quitbutton)
  self.quitbutton:setCallback(closeCallback) 
end

-- 设置按钮状态
-- @index: 按钮数组下标
-- @statePng: 状态图片
function DialogView:setButtonByIndex(index, statePng)
	 local button = self.buttons[index]
	 if button then
      button.normalSprite:setVisible(statePng)
	 end
end

-- 显示对话框
-- @id:   对话框数据ID
-- @pos:  给定的坐标
-- @data: 展示的数据信息
function DialogView.show(id, pos, data, repeate, parent, cantrm)
    	   local dialog      = DialogView.new(id,cantrm)
         if getCurrentRunNode() then
            if pos then
               dialog:setPosition(pos) 
            end
            if parent then
               parent:addChild(dialog,99200000)
            else
               getCurrentRunNode():addChild(dialog,99200000)
            end
            return dialog
         end
end

-- data：包含对话框的信息(id, 类型, 数据)
-- @repeate: 是否重新创建
function DialogView.jumpDialog(data, repeate)
       UIJump:setToData(data)
       UIJump:jumpTo(data:getId(), repeate)
end

--设置按钮按下回调函数
function DialogView:setSelectedCallback(funcallback)
    self.selectedcallback=funcallback
end

--设置按钮未被按下回调函数
function DialogView:setunSelectedCallback(funcallback)
    self.unselectedcallback=funcallback
end


-- 触摸开始
function DialogView:onTouchBegan(touch, event)
    local point = touch:getLocation()
    return self:isTouchCurrentView(point)
end

-- 触摸移动
function DialogView:onTouchMoved(touch, event)
    local point = touch:getLocation()
    self:isTouchCurrentView(point)
end

-- 触摸结束
function DialogView:onTouchEnded(touch, event)
    local point = touch:getLocation()
     self:isTouchCurrentView(point) 
end

-- 是否点击到当前视图
function DialogView:isTouchCurrentView(point)
    if self.touchrect then
        if cc.rectContainsPoint(self.touchrect, point) then
            return true
        else
            UIJump:backTo()
        end
    else
        return false
    end
end

return DialogView





