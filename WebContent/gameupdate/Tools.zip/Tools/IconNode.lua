local IconNode = class("IconNode",RequireModel.CommonNode)

function IconNode:ctor(data,icontype)
	self.super.ctor(self)
	self:OpenTouch()
	self.data = data
	self:setSwallowTouches(true)
	self.ismove = false             -- iconnode是否移动
	self.clickenable = true         -- 默认能够点击
	self.clickbegancallback = nil   -- 点击开始回调函数
	self.clickmovecallback  = nil   -- 点击移动回调函数
	self.clickEndedcallback = nil   -- 点击结束回调函数
	self.id = nil        -- 若是静态数据，返回点击结束self.id
	self.onlyid = nil    -- 若是服务器返回数据，范湖点击结束self.onlyid
	self.datatype = nil  -- 若是静态数据类型为nil，服务器数据为1
	
	self.icontype = icontype
	if self.data then
	   self.datatype = self.data.__dtype
	end
	
	self.isselected = false
	self:setSwallowTouches(false)
    
	--iconnode数据分为服务器数据和本地数据，本地数据用id获取，服务器数据用onlyid获取，服务器数据类型为1  
	if self.data then
		self.id = self.data:getId()          
		if self.datatype == 1 then
			self.onlyid = self.data:getOnlyId()
		end
		self:getTypeId()
		self:getData()
	end
    
	self:addCcb()

end

-- 添加Ccb文件
function IconNode:addCcb()
	local iconnode = nil
	if self.icontype == IconType.HeroIcon then
		self.layersize = cc.size(134,116)
		self:setContentSize(self.layersize)
		self.heroiconnode = nil 
		self.heroiconnodetab = {}
		ccb["HeroIconNode"]=self.heroiconnodetab
    	local rightbproxy = cc.CCBProxy:create()
		self.heroiconnode = CCBReaderLoad("com_ui_yingxiongtou.ccbi",rightbproxy,self.heroiconnodetab)
		self.heroiconnode:setPosition(self.layersize.width/2,self.layersize.height/2)
    	self:addChild(self.heroiconnode)
    	
    	iconnode = self.heroiconnode
	elseif self.icontype == IconType.EquipIcon then
		self.layersize = cc.size(82,83)
		self:setContentSize(self.layersize)
		self.equipiconnode = nil 
		self.equipiconnodetab = {}
		ccb["EquipIconNode"]=self.equipiconnodetab
    	local rightbproxy = cc.CCBProxy:create()
		self.equipiconnode = CCBReaderLoad("com_ui_zhuangbei.ccbi",rightbproxy,self.equipiconnodetab)
    	self.equipiconnode:setPosition(self.layersize.width/2,self.layersize.height/2)
    	self:addChild(self.equipiconnode)
    	self.equipiconnodetab["lvlabel"]:setLocalZOrder(2)
 
    elseif self.icontype == IconType.HeroEquipIcon then
    	self.layersize = cc.size(82,83)
		self:setContentSize(self.layersize)
    	self.equipiconnode = nil 
		self.equipiconnodetab = {}
		ccb["EquipIconNode"]=self.equipiconnodetab
    	local rightbproxy = cc.CCBProxy:create()
		self.equipiconnode = CCBReaderLoad("hero_ui_zhuangbei01.ccbi",rightbproxy,self.equipiconnodetab)
		self.equipiconnode:setPosition(self.layersize.width/2,self.layersize.height/2)
    	self:addChild(self.equipiconnode)
    	
	elseif self.icontype == IconType.PropIcon then
		self.layersize = cc.size(82,84)
		self:setContentSize(self.layersize)
		self.propnode = nil
		self.propnodetab = {}
		ccb["PropIconNode"]=self.propnodetab
    	local rightbproxy = cc.CCBProxy:create()
		self.propnode = CCBReaderLoad("com_ui_daoju.ccbi",rightbproxy,self.propnodetab)
		self.propnode:setPosition(self.layersize.width/2,self.layersize.height/2)
   	 	self:addChild(self.propnode)
   	elseif self.icontype == IconType.SkillIcon then
   		self.layersize = cc.size(140,140)
		self:setContentSize(self.layersize)
   		self.skilliconnode = nil 
		self.skilliconnodetab = {}
		ccb["skilliconnode"]=self.skilliconnodetab
    	local rightbproxy = cc.CCBProxy:create()
		self.skilliconnode = CCBReaderLoad("hero_ui_jineng01.ccbi",rightbproxy,self.skilliconnodetab)
		self.skilliconnode:setPosition(self.layersize.width/2,self.layersize.height/2)
    	self:addChild(self.skilliconnode)        
    	self.skilliconnodetab["skilleffect"]:setLocalZOrder(2)
    	
    elseif self.icontype == IconType.MonsterIcon then
    	self.layersize = cc.size(132,114)
		self:setContentSize(self.layersize)
    	self.monstericonnode = nil 
		self.monstericonnodetab = {}
		ccb["monstericonnode"]=self.monstericonnodetab
    	local rightbproxy = cc.CCBProxy:create()
		self.monstericonnode = CCBReaderLoad("com_ui_guaitouxiang.ccbi",rightbproxy,self.monstericonnodetab)
		self.monstericonnode:setPosition(self.layersize.width/2,self.layersize.height/2)
    	self:addChild(self.monstericonnode)
        -- self:setContentSize(cc.size(132,114))
	end
    
	self:flushIconData()

end

-- 刷新数据
function IconNode:flushIconData()
	if self.icontype == IconType.HeroIcon then
 		self:flushHeroData()
	elseif self.icontype == IconType.EquipIcon then
		self:flushEquipData()
	elseif self.icontype == IconType.PropIcon then
		self:flushPropData()
	elseif self.icontype == IconType.SkillIcon then
		self:flushSkillData()
	elseif self.icontype == IconType.MonsterIcon then
		self:flushMonsterData()
	elseif self.icontype == IconType.HeroEquipIcon then
		self:flushEquipData()
	end
end
--刷新怪物头像数据
function IconNode:flushMonsterData()
	self:setMonsterIcon()
end
-- 刷新英雄头像数据
function IconNode:flushHeroData()
	self:setHeroIcon()
	self:setHeroQualityBottom()
	self:setHeroLevel()	
	self:setDragmentProgress()
end

-- 刷新技能数据
function IconNode:flushSkillData()
	self:setSkillBottom()
	self:setSkillQuality()
	self:setSkillIcon()
	self:setSkillLevel()
	self:setSkillIsGrade()
	self:setSkillEffectBar()
end

-- 刷新道具数据
function IconNode:flushPropData()
	self:setPropQualityBottom()
	self:setPropIcon()
	-- self:setPropNum()
end

-- 刷新装备数据
function IconNode:flushEquipData()
	self:setEquipQuality()
	self:setEquipIcon()
	self:setEquipLevel()
	self:setEquipStarLevel()
	self:setEquipProfesstion()
	self:setEquipDressed()
	self:setEquipGradeStar()
end
--设置怪物头像
function IconNode:setMonsterIcon()
	local imagename = self:getIconFileName()
    local clip = getClipNode("com_di_yxdi_mengban.png",imagename,0.7)
	clip:setPosition(cc.p(self.monstericonnodetab["headiconpos"]:getPositionX(), self.monstericonnodetab["headiconpos"]:getPositionY()))
	self.monstericonnodetab["headiconpos"]:getParent():addChild(clip)
	self.monstericonnodetab["headiconpos"]:removeFromParent()
	self.monstericonnodetab["monstericonframe"]:setLocalZOrder(1)
end
-- 设置英雄品质底框
function IconNode:setHeroQualityBottom()
	local worktype = tonumber(self.data:getWork()) 
	local colour_type = tonumber(self.data:getQuality()) 	
	local index = (worktype-1)*4+colour_type
	local imagename = "com_frame_hero"..index..".png"
	self.heroqualityicon = createSprite(imagename)
	self.heroqualityicon:setPosition(self.heroiconnodetab["qualityicon"]:getPositionX(), self.heroiconnodetab["qualityicon"]:getPositionY())
	self.heroiconnodetab["qualityicon"]:getParent():addChild(self.heroqualityicon)
	self.heroiconnodetab["qualityicon"]:removeFromParent()
end

-- 设置英雄头像
function IconNode:setHeroIcon()
	local imagename = self:getIconFileName()
    local clip = getClipNode("com_di_yxdi_mengban.png",imagename,0.6)
	clip:setPosition(cc.p(self.heroiconnodetab["heroicon"]:getPositionX(), self.heroiconnodetab["heroicon"]:getPositionY()))
	self.heroiconnodetab["heroicon"]:getParent():addChild(clip)
	if self.datatype == nil then
		local graybeforesp = createSprite(imagename)		
		setGray(graybeforesp)
		clip:addChild(graybeforesp)
	end
	self.heroiconnodetab["heroicon"]:removeFromParent()
end

-- 设置英雄是否升星
function IconNode:setHeroIsGradeStar(herostarlevel)
	local thingid = self.data:getSysitem():getFragmentId()
	local thingobj = getPlayerData():getMySelfData():getPropDataByPropId(thingid)
	if not thingobj then
		self.heroiconnodetab["starlabel"]:setString("")
		return
	end
	local thingdata = getSystemData():getpropDataById(thingid)
	local neednum = 0
	if herostarlevel == 1 then
		neednum = self.data:getSysitem():getStar1Num()
	elseif herostarlevel == 2 then
		neednum = self.data:getSysitem():getStar2Num()
	elseif herostarlevel == 3 then
		neednum = self.data:getSysitem():getStar3Num()
	elseif herostarlevel == 4 then
		neednum = self.data:getSysitem():getStar4Num()
	elseif herostarlevel == 5 then
		neednum = self.data:getSysitem():getStar5Num()
	end
	if tonumber(thingobj:getNum()) >= neednum then
		self.heroiconnodetab["starlabel"]:setString("可升级")
	end
end

-- 设置碎片数量
function IconNode:setDragmentProgress()
	if self.datatype == 1 then
		self.heroiconnodetab["progressbar"]:removeFromParent()
		self.heroiconnodetab["progressbottom"]:removeFromParent()
	else
		local thingid = self.data:getFragmentId()
		local neednum = self.data:getFragmentNum()
		local thingobj = getPlayerData():getMySelfData():getPropDataByPropId(thingid)
		
		local currentnum = 10 
		if thingobj then
			currentnum = thingobj:getNum()
		end
		local percentage 
		if currentnum > neednum then
			percentage = 100
		else
			percentage = currentnum/neednum*100
		end
		self.upbar =  cc.ProgressTimer:create(cc.Sprite:create("UI_com/com_di_yxdi_jingyantiao.png"))
        self.upbar:setPosition(self.heroiconnodetab["progressbar"]:getPositionX(), self.heroiconnodetab["progressbar"]:getPositionY())
        self.heroiconnodetab["progressbar"]:getParent():addChild(self.upbar,2)
        self.upbar:setType(cc.PROGRESS_TIMER_TYPE_BAR)
        self.upbar:setBarChangeRate(cc.p(1, 0))
        self.upbar:setMidpoint(cc.p(0, 0))
        self.upbar:setPercentage(percentage)
        -- barpos
        self.heroiconnodetab["progressbar"]:removeFromParent()
	end
end

-- 设置英雄星级
function IconNode:setHeroStar(starlevel)
	if self.datatype == 1 then
		if starlevel == 0 then
			for i=1,5 do
				local starname = "starpos"..i 
				local staricon = createSprite("com_ui_xing02.png")
				staricon:setPosition(self.heroiconnodetab[starname]:getPositionX(), self.heroiconnodetab[starname]:getPositionY())
				self.heroiconnodetab[starname]:getParent():addChild(staricon)
				self.heroiconnodetab[starname]:removeFromParent()
			end
		else
			for i=1,starlevel do
				local starname = "starpos"..i 
				self.heroiconnodetab[starname]:setLocalZOrder(2)
			end
			for i=starlevel+1,5 do
				local starname = "starpos"..i 
				local staricon = createSprite("com_ui_xing02.png")
				staricon:setPosition(self.heroiconnodetab[starname]:getPositionX(), self.heroiconnodetab[starname]:getPositionY())
				self.heroiconnodetab[starname]:getParent():addChild(staricon)
				self.heroiconnodetab[starname]:removeFromParent()
			end
		end
	else
		for i=1,5 do
			local starname = "starpos"..i 
			self.heroiconnodetab[starname]:removeFromParent()
		end
	end
end

-- 设置英雄等级
function IconNode:setHeroLevel()
	if self.datatype == 1 then
		local level = self.data:getHeroLevel()
		self.heroiconnodetab["herolevel"]:setString(level)
		-- if self.herolevellabel then
		-- 	self.herolevellabel:setString(level)
		-- else
		-- 	self.herolevellabel = createLabel(level, self.heroiconnodetab["herolevel"]:getParent(),self.heroiconnodetab["herolevel"]:getPositionX()+5,self.heroiconnodetab["herolevel"]:getPositionY()-2)
		-- 	self.heroiconnodetab["herolevel"]:removeFromParent()
		-- end
	else
		local thingid = self.data:getFragmentId()
		local neednum = self.data:getFragmentNum()
		local thingobj = getPlayerData():getMySelfData():getPropDataByPropId(thingid)
		local currentnum = 0 
		if thingobj then
			currentnum = thingobj:getNum()
		end
		self.heroiconnodetab["herolevel"]:setString(currentnum.."/"..neednum)
	end
	self.heroiconnodetab["herolevel"]:setLocalZOrder(2)
end


-- 设置英雄星级
function IconNode:setStarNum(herosatrnum)
	if herosatrnum < 5 then
		for i=1,5 do
			local starname = "starpos"..i
			if i <= herosatrnum then
				self.heroiconnodetab[starname]:setVisible(true)
			else
				self.heroiconnodetab[starname]:setVisible(false)
			end   
        end
	end
end

-- 设置装备职业
function IconNode:setHeroProfesstion()
	local m_type = self.sysdata:getWork()
	local iconname = "ty_tx_zhiye0"..m_type..".png"
	self.heroprofesstionicon = createSprite(iconname)
	self.heroprofesstionicon:setPosition(self.heroiconnodetab["state"]:getPositionX(),self.heroiconnodetab["state"]:getPositionY())
	self.heroiconnodetab["state"]:getParent():addChild(self.heroprofesstionicon)
	self.heroiconnodetab["state"]:removeFromParent()
end

-- 设置英雄上阵状态HeroEquipIcon
function IconNode:setBattleState()
	local onlyid = self.data:getOnlyId()
	local isbattle = getPlayerData():getMySelfData():isHeroBattleByOnlyId(onlyid)
	if isbattle then
		self.battlestate = ccui.ImageView:create()
    	self.battlestate:setScale9Enabled(true)
    	self.battlestate:loadTexture("ty_tx_chuzhanjiaobiao.png")
		self.battlestate:setPosition(self.heroiconnodetab["battleicon"]:getPositionX(), self.heroiconnodetab["battleicon"]:getPositionY())
		self.heroiconnodetab["battleicon"]:getParent():addChild(self.battlestate)
		self.heroiconnodetab["battleicon"]:removeFromParent()
	else
		self.heroiconnodetab["battleicon"]:setVisible(false)
	end
end

-- 设置道具品质框
function IconNode:setPropQualityBottom()
	local m_type
	if self.datatype == 1 then
		m_type = self.data:getSysitem():getQuality()
	else
		m_type = self.data:getQuality()
	end
	if tonumber(m_type) == 0 then
	   m_type = 1
	end
	local iconname = "com_di_daoju0"..m_type..".png"
	self.propbottomicon = createSprite(iconname)
	self.propbottomicon:setPosition(self.propnodetab["qualityicon"]:getPositionX(),self.propnodetab["qualityicon"]:getPositionY())
	self.propnodetab["qualityicon"]:getParent():addChild(self.propbottomicon)
	self.propnodetab["qualityicon"]:removeFromParent()

	if tonumber(self.data:getType()) == 7 then
		self.propnodetab["framenticon"]:setLocalZOrder(2)
	else
		self.propnodetab["framenticon"]:removeFromParent()
	end
end

-- 设置道具头像
function IconNode:setPropIcon()
	local imagename = self:getIconFileName()
	self.icon = ccui.ImageView:create()
    self.icon:setScale9Enabled(true)
    self.icon:loadTexture(imagename)
    self.icon:setPosition(self.propnodetab["propicon"]:getPositionX(),self.propnodetab["propicon"]:getPositionY())
    self.propnodetab["propicon"]:getParent():addChild(self.icon)
    self.propnodetab["propicon"]:removeFromParent()
end

-- 设置道具数量
function IconNode:setPropNum(neednum)
	local propnum = 0
	local str 
	if self.datatype == 1 then
		local onlyid = self.data:getOnlyId()
		local propobj = getPlayerData():getMySelfData():getPropByOnlyId(onlyid)
		if propobj then
			propnum = propobj:getNum()
		end
	end
	if neednum then
		str = propnum.."/"..neednum
	else
		str = propnum
	end
	if self.numlabel then
		self.numlabel:setString(str)
	else
		-- self.numlabel = Font.getTextById("LUIHERO030007")
		-- self.numlabel:setAnchorPoint(cc.p(0,0))
		-- self.numlabel:setPosition(self.propnodetab["propnum"]:getPositionX(),self.propnodetab["propnum"]:getPositionY())
		-- self.propnodetab["propnum"]:getParent():addChild(self.numlabel)
		self.numlabel = createLabel(str, self.propnodetab["propnum"]:getParent(),self.propnodetab["propnum"]:getPositionX(),self.propnodetab["propnum"]:getPositionY())
		self.numlabel:setAnchorPoint(cc.p(0,0))
		local labelsize = self.numlabel:getContentSize()
		self.numlabel:setPositionX(self.numlabel:getPositionX()-labelsize.width)
		self.propnodetab["propnum"]:removeFromParent()
	end
end
 
-- 设置数量
function IconNode:setNum(num)
	if self.numlabel then
		self.numlabel:setString(tostring(num))
	else
		self.numlabel = createLabel(tostring(num), self.propnodetab["propnum"]:getParent(),self.propnodetab["propnum"]:getPositionX(),self.propnodetab["propnum"]:getPositionY())
		self.numlabel:setAnchorPoint(cc.p(0,0))
		local labelsize = self.numlabel:getContentSize()
		self.numlabel:setPositionX(self.numlabel:getPositionX()-labelsize.width)
		self.propnodetab["propnum"]:removeFromParent()
	end
end
 
-- 设置装备品质
function IconNode:setEquipQuality()
	local colour_type = tonumber(self.data:getQuality()) 	
	local imagename = "com_di_daoju0"..colour_type..".png"
	self.qualityicon = createSprite(imagename)
	self.qualityicon:setPosition(self.equipiconnodetab["qualityicon"]:getPositionX(), self.equipiconnodetab["qualityicon"]:getPositionY())
	self.equipiconnodetab["qualityicon"]:getParent():addChild(self.qualityicon)
	if self.icontype == IconType.HeroEquipIcon then
		self.qualityicon:setScaleX(64/82)
		self.qualityicon:setScaleY(65/83)
	end
end

-- 设置装备头像
function IconNode:setEquipIcon()
	local imagename = self:getIconFileName()
	self.icon = ccui.ImageView:create()
	if self.icontype == IconType.HeroEquipIcon then
		self.icon:setScale(0.5)
	end
	
    self.icon:setScale9Enabled(true)
    self.icon:loadTexture(imagename)
    self.icon:setPosition(self.equipiconnodetab["equipicon"]:getPositionX(),self.equipiconnodetab["equipicon"]:getPositionY())
    self.equipiconnodetab["equipicon"]:getParent():addChild(self.icon)
end

-- 设置装备等级
function IconNode:setEquipLevel()
	local level = self.data:getLevel()
	self.equipiconnodetab["level"]:setString(level)

	self.equipiconnodetab["level"]:setLocalZOrder(2)
	self.equipiconnodetab["lvlabel"]:setLocalZOrder(2)
	-- if self.equiplevel then
	-- 	self.equiplevel:setString(level)
	-- else
	-- 	self.equiplevel = createLabel(level, self.equipiconnodetab["level"]:getParent(),self.equipiconnodetab["level"]:getPositionX(),self.equipiconnodetab["level"]:getPositionY())
	-- 	self.equipiconnodetab["level"]:removeFromParent()
	-- end
end

-- 设置装备职业
function IconNode:setEquipProfesstion()
	local m_type = self.data:getWork()
	local iconname = "tjp_zbjb_0"..m_type..".png"
	self.professtionicon = createSprite(iconname)
	self.professtionicon:setPosition(self.equipiconnodetab["profressionicon"]:getPositionX(),self.equipiconnodetab["profressionicon"]:getPositionY())
	self.equipiconnodetab["profressionicon"]:getParent():addChild(self.professtionicon)
	self.equipiconnodetab["profressionicon"]:removeFromParent()
end

-- 设置装备星级
function IconNode:setEquipStarLevel()
	self.equipstaricontab = {}
	local starlevel = tonumber(self.data:getStrengLevel()) 
	starlevel = starlevel + 1
	for i=1,5 do
		local starname = "star"..i
		if i >= starlevel then
			local staricon = createSprite("com_ui_xing02.png")
			if self.icontype == IconType.HeroEquipIcon then
				staricon:setScale(0.5)
			else
				staricon:setScale(0.8)
			end
			staricon:setPosition(self.equipiconnodetab[starname]:getPositionX(),self.equipiconnodetab[starname]:getPositionY())
			self.equipiconnodetab[starname]:getParent():addChild(staricon)
			self.equipiconnodetab[starname]:setVisible(false)
			self.equipstaricontab[#self.equipstaricontab+1] = staricon
		else
			self.equipiconnodetab[starname]:setLocalZOrder(2)
		end
	end
end

-- 设置装备升星后星级
function IconNode:setGradeStarNum()
	if self.equipstaricontab[1] then
		local staricon =  createSprite("com_ui_xing01.png")
		staricon:setScale(0.8)
		staricon:setPosition(self.equipstaricontab[1]:getPositionX(),self.equipstaricontab[1]:getPositionY())
		self.equipstaricontab[1]:getParent():addChild(staricon)
		self.equipstaricontab[1]:removeFromParent()
	end
end

-- 设置装备是否穿戴
function IconNode:setEquipDressed()
	if self.icontype == IconType.EquipIcon then
		if self.data:getEquipHeroOnlyid() ~= 0 then
			self.dressedlabel = Font.getTextById("LUICOMMXX0007")
			self.dressedlabel:setPosition(self.equipiconnodetab["isgrade"]:getPositionX(),self.equipiconnodetab["isgrade"]:getPositionY())
			self.equipiconnodetab["isgrade"]:getParent():addChild(self.dressedlabel)
			self.equipiconnodetab["isgrade"]:removeFromParent()
		else
			self.equipiconnodetab["isgrade"]:removeFromParent()
		end
	end
end

-- 移除装备标签
function IconNode:removeEquipLabel()
	if self.equipiconnodetab["isgrade"] then
		self.equipiconnodetab["isgrade"]:removeFromParent()
		self.equipiconnodetab["isgrade"] = nil
	end
	if self.dressedlabel then
		self.dressedlabel:removeFromParent()
		self.dressedlabel = nil
	end
end

-- 设置装备是否可升星
function IconNode:setEquipGradeStar()

end

-- 设置技能头像
function IconNode:setSkillIcon()
	local imagename = self:getIconFileName()
	-- imagename ="daodan.png"
	self.skillicon = ccui.ImageView:create()
	-- self.skillicon:setScale(0.55)
    self.skillicon:setScale9Enabled(true)
    self.skillicon:loadTexture(imagename)
    self.skillicon:setPosition(self.skilliconnodetab["skillicon"]:getPositionX(), self.skilliconnodetab["skillicon"]:getPositionY())
	self.skilliconnodetab["skillicon"]:getParent():addChild(self.skillicon)
	self.skilliconnodetab["skillicon"]:setVisible(false)
end

-- 设置技能底框
function IconNode:setSkillBottom()
	local skilltype = tonumber(self.data:getType())
	local bottomname 
	if skilltype < 5 then
		bottomname = "UI_battle/battle_ui_jinengframe1.png"
	elseif skilltype == 5 then
		bottomname = "UI_battle/battle_ui_jinengframe2.png"
	end
	self.skillbottom = createSprite(bottomname)
	-- self.skillbottom:setScale(0.55)
	self.skillbottom:setPosition(self.skilliconnodetab["skillicon"]:getPositionX(),self.skilliconnodetab["skillicon"]:getPositionY())
	self.skilliconnodetab["skillicon"]:getParent():addChild(self.skillbottom)
	self.skilliconnodetab["bottomicon"]:setVisible(false)
end

-- 设置技能品质
function IconNode:setSkillQuality()
	local qualitytype 
	if self.m_type == 1 then
		qualitytype = self.data:getSysitem():getUseOf()
	else
		qualitytype = self.data:getUseOf()
	end
	local imagename = "com_ui_jinengdi0"..qualitytype..".png"
	local qualityicon = createSprite(imagename)
	-- qualityicon:setScale(0.55)
	qualityicon:setPosition(self.skilliconnodetab["skillicon"]:getPositionX(), self.skilliconnodetab["skillicon"]:getPositionY())
	self.skilliconnodetab["skillicon"]:getParent():addChild(qualityicon)
	self.skilliconnodetab["qualityicon"]:setVisible(false)
end

-- 技能条
function IconNode:setSkillEffectBar()
	local skilltype
	if self.datatype == 1 then
		skilltype = self.data:getSysitem():getType()
	else
		skilltype = self.data:getType()
	end
	local imagename
	if skilltype == 2 or skilltype == 3 then
		imagename = "com_ui_jinengbiao02.png"
	elseif skilltype == 4 or skilltype == 5 then
		imagename = "com_ui_jinengbiao01.png"
	end
	local effecticon = createSprite(imagename)
	effecticon:setPosition(self.skilliconnodetab["skilleffect"]:getPositionX(),self.skilliconnodetab["skilleffect"]:getPositionY())
	self.skilliconnodetab["skilleffect"]:getParent():addChild(effecticon)
	self.skilliconnodetab["skilleffect"]:removeFromParent()
end

-- 设置技能等级
function IconNode:setSkillLevel()
	local level = 1
	if self.m_type == 1 then
		level = self.data:getLevel()
	else
		level = 1
	end
	self.skilliconnodetab["skiillevel"]:setString(level)
	self.skilliconnodetab["skiillevel"]:setLocalZOrder(2) 
	
	-- if self.skilllevellabel then
	-- 	self.skilllevellabel:setString(level)
	-- else
	-- 	self.skilllevellabel = createLabel(level, self.skilliconnodetab["skiillevel"]:getParent(),self.skilliconnodetab["skiillevel"]:getPositionX(),self.skilliconnodetab["skiillevel"]:getPositionY())
	-- 	self.skilllevellabel:setAnchorPoint(cc.p(0.5,0.5))
	-- 	self.skilliconnodetab["skiillevel"]:removeFromParent()
	-- end	
end

-- 设置技能是否可升级
function IconNode:setSkillIsGrade()
	self.skilliconnodetab["isgrade"]:setVisible(false)
	-- local gradename = ""
	-- if self:getSkillIsLock() then
	-- 	gradename = "可升级"
	-- end
	-- if self.gradelabel then
	-- 	self.gradelabel:setString(gradename)
	-- else
	-- 	self.gradelabel = createLabel(gradename, self.skilliconnodetab["isgrade"]:getParent(),self.skilliconnodetab["isgrade"]:getPositionX(),self.skilliconnodetab["isgrade"]:getPositionY())
	-- 	self.skilliconnodetab["isgrade"]:removeFromParent()
	-- end
end

-- 获取英雄技能是否解锁
function IconNode:getSkillIsLock()
	local itemdata = {}
	-- if not self.skilldata then
	-- 	self.skilldata = getSystemData():getSpecialSkillData(self.selectitemid)
	-- end
	local data = getSystemData():getSkillDataById(self.data:getId())
	-- print("self.data =")
	self.needitemdata = data:getUpLevelData(tostring(self.data:getLevel()))
	self.openleveldata = data:getOpenLevels(tostring(self.data:getLevel()))
	
	local moneytype
	local needmoneynum
	for index,data in pairs(self.needitemdata) do
		if index == 1 then
			moneytype = tonumber(data.id) 
			needmoneynum = tonumber(data.num) 
		else
			itemdata[#itemdata+1] = data
		end
	end

	if moneytype == 1 then
		if tonumber(getPlayerData():getMySelfData():getPlayerGoldNum()) < needmoneynum then
			return false
		end
	elseif moneytype == 2 then
		if tonumber(getPlayerData():getMySelfData():getPlayerDiamondsNum()) < needmoneynum then
			return false
		end
	end

	for index,data in pairs(itemdata) do
		local propobj = getPlayerData():getMySelfData():getPropDataByPropId(data.id)
		if propobj then
			if tonumber(propobj:getNum()) < tonumber(data.num) then
				return false
			end
		else
			return false
		end
	end
	return true
end

-- 设置技能是否解锁
function IconNode:setSkillLock(skilllevel, herolevel)
	local herolocklevel = self.data:getOpenLevels(tostring(skilllevel)).pl
	self.skilliconnodetab["lockicon"]:setVisible(false)
	-- if  tonumber(herolevel) < tonumber(herolocklevel) then
		-- local locksp = createSprite("ty_skillsuo.png")
		-- locksp:setPosition(self.skilliconnodetab["lockicon"]:getPositionX(), self.skilliconnodetab["lockicon"]:getPositionY())
		-- self.skilliconnodetab["lockicon"]:getParent():addChild(locksp)
	-- end
end

-- 设置技能效果
function IconNode:setSkillEffect()
	-- local effecticon = self.data:getIcon1()
	local skillicon = createSprite(effecticon)
	skillicon:setPosition(self.skilliconnodetab["skilleffect"]:getPositionX(),self.skilliconnodetab["skilleffect"]:getPositionY())
	self.skilliconnodetab["skilleffect"]:getParent():addChild(skillicon)
	self.skilliconnodetab["skilleffect"]:removeFromParent()
end

-- 设置图片显示大小
-- @size: 图标显示大小
-- @bsize: 底框的尺寸
function IconNode:setShowSize( size , bsize)
	self.icon:setContentSize(size)
	self:setNodeSize(size)
	if bsize then
	   self.background:setContentSize(bsize)
	end
	-- self.iconlabel:setPosition(cc.p(self.iconlabel))
end

function IconNode:setShowScale(scale)
	self.icon:setScale(scale) 
end
-- 设置显示的尺寸
-- @image: 显示的图片名称
function IconNode:setShowImage( image )
	self.icon:loadTexture(image)
end

-- 设置线
function IconNode:setLines(rect)
	self.icon:setCapInsets(rect)
end

-- 设置容器大小
function IconNode:setNodeSize(size)
	self.layersize = size
	self:setContentSize(self.layersize)
end

-- 设置是否可点击
function IconNode:setClickEnable(flag)
	self.clickenable = flag
end

-- 刷新数据
function IconNode:flushData(data)
	self.data = data
	if self.data then
	   self.datatype = self.data.__dtype 
	else
	   self.datatype = nil
	end
end

-- 获取id
function IconNode:getId()
	if self.datatype == 1 then
	   return self.onlyid
	else
	   return self.id
	end
end

-- 获取数据
function IconNode:getData()
	-- 1代表英雄数据 2：代表技能数据 3：代表 4：代表 5：代表道具数据 
	if tonumber(self.proptype) == 1 then
		self.sysdata = getSystemData():getBattleUnitDataById(self.id)
	elseif tonumber(self.proptype) == 2 then
		self.sysdata = getSystemData():getSkillDataById(self.id)
	elseif tonumber(self.proptype) == 5 or tonumber(self.proptype) == 6 then
		self.sysdata = getSystemData():getpropDataById(self.id)
	elseif tonumber(self.proptype) == 4 then
		self.sysdata = getSystemData():getSkillDataById(self.id)
	else
		 
	end
end

-- 获取icon类型id
function IconNode:getTypeId()
	self.proptype = tonumber(string.sub(tostring(self.id),0,1))
end

-- 获取icon图标
function IconNode:getIconName()
	if self.proptype == 1 then
		if self.datatype == 1 then
			if self.sysdata then
				return self.sysdata:getIcon() 
			else
				return 
			end
		else
			return self.data:getIcon()
		end
	elseif tonumber(self.proptype) == 2 then
		return self.sysdata:getIcon()
	elseif self.proptype == 5 or self.proptype == 6 then
		return self.sysdata:getIcon()
	elseif self.proptype == 4 then
		return self.sysdata:getIcon()
	else
		return "diban7.png"
	end
end

function IconNode:setBackground( background )
	self.background:loadTexture(background)
end
-- 设置底框
function IconNode:setBottom(imagename)
	 if not self.background then
		self.background = ccui.ImageView:create()
	    self.background:setScale9Enabled(true)
	    self.background:loadTexture(imagename)
	    self.background:setPosition(cc.p(self.layersize.width/2, self.layersize.height/2))
		self:addChild(self.background,-1)
	 end
end

-- 获取容器大小
function IconNode:getNodeSize()
	return self.layersize
end

-- 获取icon图标名称
function IconNode:getIconFileName()
	local imagename = self:getIconName()
    if self.proptype == 1 then
    	if RequireModel.fileManager.isExistFile("yingxiong/"..imagename) == false then
        	-- imagename = "ui_bt_head_100101.png"
    	end
    elseif self.proptype == 2 then
    	if RequireModel.fileManager.isExistFile("Skill_icon/"..imagename) == false then
        	imagename = "skill_200101_02.png"
    	end 
    elseif self.proptype == 5 then
    	if RequireModel.fileManager.isExistFile("equip_icon/"..imagename) == false then
        	imagename = "equip_512001.png"
    	end 
    elseif self.proptype == 6 then
    	if RequireModel.fileManager.isExistFile("equip_icon/"..imagename) == false then
        	imagename = "tjp_sc_01.png"
    	end 
    end
    return imagename
end


-- 移除图标icon
function IconNode:removeIcon()
	if self.icon then
		self.icon:removeFromParent(true)
		self.icon = nil
	end
end

--更换icon图片，iconname图片名
function IconNode:setIcon(iconname)
	self.icon:loadTexture(iconname)
end

-- 设置标签 
-- @labelname:标签名 flag:1左下角 2:右下角 3:左上角 4:右上角 5:中间
function IconNode:setIconLabel(labelname, flag, color)
	if not self.icon then
		return
	end
	self.iconlabel = cc.LabelTTF:create(labelname ,"Arial", 16)
	self.iconlabel:setFontFillColor(cc.c3b(0,0,255))
	self:setObjPos(flag, self.iconlabel, color)
	self.icon:addChild(self.iconlabel)
end

-- 设置位置
function IconNode:setObjPos(index, obj, color)
	local iconsize = self.icon:getContentSize()
	local m_size = obj:getContentSize()
	if index == 1 then
		obj:setPosition(m_size.width/2,m_size.height/2)
	elseif index == 2 then
		obj:setPosition(iconsize.width-m_size.width/2,m_size.height/2)
	elseif index == 3 then
		obj:setPosition(m_size.width/2,iconsize.height-m_size.height/2)
	elseif index == 4 then
		obj:setPosition(iconsize.width-m_size.width/2,iconsize.height-m_size.height/2)
	elseif index == 5 then
		obj:setPosition(iconsize.width/2,iconsize.height/2)
	end
end

-- 设置标签颜色
function IconNode:setLabelColor(color)
	if self.iconlabel then
		self.iconlabel:setFontFillColor(color)
	end
end

-- 设置职业图标
function IconNode:setdProfesstionIcon(iconname)
	self.professtionicon = ccui.ImageView:create(iconname)
	self.professtionicon:setPosition(self.professtionicon:getContentSize().width/2, self.professtionicon:getContentSize().height/2)
	self:addChild(self.professtionicon)
end



-- 设置强化等级
function IconNode:setStrengthLevel()
	self.isequipicon = ccui.ImageView:create("")
	self.isequipicon:setPosition(0,0)
	self:addChild(self.isequipicon)
end

-- 点击开始回调事件
function IconNode:clcikBeganCallback(clickbegancallback)
	self.clickbegancallback = clickbegancallback
end

-- 点击移动回调事件
function IconNode:clickMoveCallback(clickmovecallback)
	self.clickmovecallback = clickmovecallback
end

-- 点击结束回调事件
function IconNode:clcikEndedCallback(clickEndedcallback)
	self.clickEndedcallback = clickEndedcallback
end

-- 触摸开始
function IconNode:onTouchBegan(touch, event)
	self.beginPoint = touch:getLocation()
	if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
		self.isselected = true
	end
	if self.clickbegancallback then

	end
	return true
end

-- 触摸移动
function IconNode:onTouchMoved(touch, event)
	if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
		self.isselected = true
	else
		self.isselected = false
    end
    local m_id 
	if self.datatype == 1 then
		m_id = self.onlyid
	else
		m_id = self.id 
	end	

	if self.clickmovecallback then
		self.clickmovecallback({onlyid = m_id})
	end
end

-- 触摸结束
function IconNode:onTouchEnded(touch, event)
	self.endPoint = touch:getLocation()
	if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
		if twoPointDistance(self.endPoint.x,self.endPoint.y, self.beginPoint.x,self.beginPoint.y) > 10 then
        	self.ismove = true	
    	end
    else
    	return
	end
	local m_id 
	if self.datatype == 1 then
		m_id = self.onlyid
	else
		m_id = self.id 
	end	   
	if self.ismove then
		self.ismove = false
	else
		if self.clickEndedcallback then
			self:clickEndedcallback({onlyid = m_id})
		end
	end
	self.isselected = false
end

return IconNode
