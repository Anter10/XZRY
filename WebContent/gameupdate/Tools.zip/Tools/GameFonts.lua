-- 游戏的相关字体 Font
local GameFonts = {}

-- 字体具柄
cc.exports.Font = GameFonts

local AllFontType = {
    sys = "0",  -- 系统字格式
    fnt = "1",  -- fnt格式
    ttf = "2"   -- ttf格式
}


-- config:{text = tagName, font = "res/fonts/DFYUANW7-GB2312.ttf", color = cc.c3b(255, 255, 255), size = 20, align = cc.TEXT_ALIGNMENT_CENTER}
function GameFonts.newTTFLabel(config)
    local myLable = nil
    if config then
        if config.font then
            local mytext = ""
            local color = cc.c3b(255, 255, 255)
            local size = 22
            local align = cc.TEXT_ALIGNMENT_CENTER
            local vertical = cc.VERTICAL_TEXT_ALIGNMENT_CENTER
            if config.text then 
                mytext = config.text
            end
            if config.color then 
                color = config.color
            end
            if config.size then 
                size = config.size
            end
            if config.vertical then
                vertical = config.vertical
            end
            if not config.font then
               config.font = "arial.ttf"
            end
            myLable = cc.LabelTTF:create(mytext, config.font,size)
            -- myLable = cc.Label:createWithTTF(mytext,config.font,size )
            if config.hAlignment == 0 then
                myLable:setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
            end
            if config.DimensionsSize then
                myLable:setDimensions(config.DimensionsSize)
            end
        end
    end
    return myLable
end


-- 游戏中相关字体描边设置和获取  .ttf 格式
function GameFonts.getTextLabel(text,fontsize,color,dimensions,hAlignment,vAlignment,anchor,fnode,pos,order,mb, fontfile)
    local ttfConfig = {}
    ttfConfig.fontFilePath = fontfile or "UI_fonts/fzyt.TTF"
    ttfConfig.fontSize     = fontsize
    ttfConfig.glyphs       = cc.GLYPHCOLLECTION_DYNAMIC
    ttfConfig.customGlyphs = true
    ttfConfig.distanceFieldEnabled = false 
    
    local textLabel = cc.Label:createWithTTF(ttfConfig,text)
    textLabel:setLineBreakWithoutSpace(true) 
    if color then textLabel:setTextColor(color) end 
    if dimensions then textLabel:setDimensions(dimensions.width,dimensions.height) end
    if hAlignment then textLabel:setAlignment(hAlignment) end
    if vAlignment then textLabel:setVerticalAlignment(vAlignment) end
    -- 描边颜色为黑色 描边大小为2 
    local mbline = cc.c4b(0,0,0,255)
    
    if not mb then textLabel:enableOutline(mbline,2) end
    if anchor then if type(anchor) == "table" then textLabel:setAnchorPoint(anchor) end end 
    if fnode then fnode:addChild(textLabel) end
    if pos then textLabel:setPosition(pos) end
    if type(order) == "string" or not order then
        order = 0
    end
    if order then textLabel:setLocalZOrder(order) end
    return textLabel 
end



-- 根据FNT文件得到FNT字体
-- @fontFile: 字体文件
function GameFonts.getBMFont(fontFile, text, setName)
    local tbfont = ccui.TextBMFont:create() 
    tbfont:setFntFile(fontFile)
    if text then tbfont:setString(text) end
    if setName then tbfont:setName(name) end
    return tbfont
end

function GameFonts.createBMFont(bmfontFilePath, text ,hAlignment, maxLineWidth, offset, anchor, fnode, pos, order, mb)
 
    local textLabel = cc.Label:createWithBMFont(bmfontFilePath, text ,hAlignment,maxLineWidth, offset)
    textLabel:setLineBreakWithoutSpace(true) 
    if color then textLabel:setTextColor(color) end 
    if dimensions then textLabel:setDimensions(dimensions.width,dimensions.height) end
    if hAlignment then textLabel:setAlignment(hAlignment) end
    if vAlignment then textLabel:setVerticalAlignment(vAlignment) end
    -- 描边颜色为黑色 描边大小为2 
    local mbline = cc.c4b(0,0,0,255)
    if anchor then if type(anchor) == "table" then textLabel:setAnchorPoint(anchor) end end 
      if anchor then
       textLabel:setAnchorPoint(anchor)
    end
    if textLabel then
       fnode:addChild(textLabel)
    end
    if pos then
      textLabel:setPosition(pos)
    end
    if order then
       textLabel:setLocalZOrder(order)
    end
    if color then
       textLabel:setColor(color)
    end
    if order then textLabel:setLocalZOrder(order) end
    return textLabel 
end

-- 创建系统字体
function GameFonts.getSystemFont(text,font, fontSize,dimensions, hAlignment,  vAlignment, color,anchor, fnode, pos, order, mb )
    local dimensions = dimensions or {}
    -- print("fonts   = ",text,font, fontSize,dimensions, hAlignment,  vAlignment,json.encode(color), json.encode(anchor), fnode, pos, order, mb )
    local label = cc.Label:createWithSystemFont(text,font, fontSize,dimensions, hAlignment,  vAlignment)
    if anchor then
       label:setAnchorPoint(anchor)
    end
    if fnode then
       fnode:addChild(label)
    end
    if pos then
      label:setPosition(pos)
    end
    if order then
       label:setLocalZOrder(order)
    end
    if color then
       label:setColor(color)
    end
    return label
end


-- 根据具体的文本ID得到具体的文本显示数据
-- @textmessageid: 显示的文本信息ID require 
-- @repleasepos: 替换#P#的位置 option
-- @dimensions: 显示的宽和高  cc.size(400,400) option
-- @onlytext:   true 只得到制定的字体 option
function GameFonts.getTextById(textmessageid, repleasepos, dimensions, onlytext)
    if textmessageid then
       local tdata = nil
       
       -- 得到文本格式 是图片还是 字体
       local tmsgt       = getStringArray(textmessageid, "_") 
       local tmsigid     = nil
       local isimagefont = false
       if tmsgt and type(tmsgt) == "table" and #tmsgt > 1 and tonumber(tmsgt[2]) == 0 then
          isimagefont = true
          tmsigid = textmessageid
       else
          tmsigid = textmessageid
       end
       -- 得到当前显示的文本信息
       -- 得到文本数据
       local findit     = string.find(tmsigid, "L")
       
       -- print(" = 当前文本ID = "..textmessageid)
      
       if findit then
          tdata = getSystemData():getSystemShowWorldData(textmessageid)
       elseif not findit then
          tdata = getSystemData():getDialogData(textmessageid)
       end

       if not tdata then
          printError("没有你要的文本ID")
          return nil
       end
       -- if string.len(textmessageid) == 9 then
       --    tdata = getSystemData():getDialogData(textmessageid)
       -- elseif string.len(textmessageid) == 7 then
       --    tdata = getSystemData():getSystemShowWorldData(textmessageid)
       -- end
       
       -- 如果是图片文本 则返回图片格式的精灵格式的文本
       if isimagefont then
          local sprite = cc.Sprite:create(tdata:getWords())
          return sprite
       end
       -- 得到当前的显示格式
       local showtype    = tdata:getShowType()
 
       -- 得到表头信息
       local headmessage = getStringArray(showtype,"#F#")

       -- 得到对齐方式
       local aligns      = getStringArray(headmessage[1],"#")[3]
     
       -- 水平方向上的对齐
       local ha          = string.sub(aligns,1,1)
         -- 垂直方向上的对齐
       local va          = string.sub(aligns,2,2)

       -- 得到文本头使用的字体
       local headmsg     = getStringArray(headmessage[2],"##")

       -- 得到文本显示的ID 
       local headfontid  = headmsg[1]
       -- 得到文本ID
       local wordid      = headmsg[2]
       local worlddata  = tdata
  
     
       if worlddata then
          -- 得到显示的文本 以后在这里进行复文本扩展
          local text        = worlddata:getWords()
          local aastring    =  text
          repleasepos = repleasepos or {}
          -- print(text, "vvv", json.encode(repleasepos))
          for i,v in ipairs(repleasepos) do
              aastring = string.gsub(text, "#P#", v)
          end
          
         
          text = aastring
          if onlytext then
             return text
          end


          -- 得到字体数据
          local fontdata    = getSystemData():getSystemTextFontDataById(headfontid)
           if fontdata then
             -- 字号
             local fontsize  = fontdata:getFontSize()
             -- 字体颜色ID 
             local colorid   = fontdata:getFontColor()
             -- 得到字体颜色
             local fontcolor = getSystemData():getSystemColorById(colorid):getColor()
             -- 字号ID
             local fontid    = fontdata:getFontId()
             -- 得到字库数据
             local fontd      = getSystemData():getSystemFontDataById(fontid)
             if fontd then
                local ftype    = fontd:getType()
                local fontfile = fontd:getLanFontFile()
                -- 得到的现实字体ID
                local fontNode     = nil  
                if ftype == AllFontType.sys then
                   -- print("ha,  va = ",ha,  va)
                   fontNode = GameFonts.getSystemFont(text,fontfile, fontsize,dimensions, ha,  va, fontcolor,anchor, fnode, pos, order, mb )
                elseif ftype == AllFontType.fnt then
                   fontNode = Font.createBMFont("UI_fonts/"..fontfile, text ,ha,2 ,cc.p(0,0),anchor,fnode,pos,order,mb, fontfile)
                elseif ftype == AllFontType.ttf then
                   fontNode = GameFonts.getTextLabel(text,fontsize,fontcolor,dimensions,ha,va,anchor,fnode,pos,order,mb, fontfile)
                end
                -- print(ftype,fontfile, fontsize,json.encode(fontcolor), fontid, "当前需要显示的文本  = ",text)
                return fontNode
             end
          end
       end
    end
end

-- 得到制定字体显示规则的label
-- @ftype: 字体格式
-- @fontfile: 显示的字体
-- @fontsize: 显示的字号
-- @dimensions: 显示的区域
-- @ha: 水平方向上的对齐方式 0 1 2 左中右
-- @va: 垂直方向上的对齐方式
-- @fontcolor: 字体颜色
-- @anchor: 给定字体的锚点
-- @fnode:  给定字体的父节点
-- ...
function GameFonts.getSTLabel(ftype,text,fontfile,fontsize,dimensions, ha, va, fontcolor, anchor, fnode, pos, order, mb)
      -- print(" ", ftype,text,fontfile,fontsize,dimensions, ha, va, fontcolor, anchor, fnode, pos, order, mb)
      local fontNode     = nil  
      if ftype == AllFontType.sys then
         fontNode = GameFonts.getSystemFont(text,fontfile, fontsize,dimensions, ha,  va,fontcolor, anchor,fnode, pos,order,mb)
      elseif ftype == AllFontType.fnt then
         fontNode = Font.createBMFont("UI_fonts/"..fontfile, text ,ha,dimensions.width,cc.p(0,0),anchor,fnode,pos,order,mb, fontfile)
      elseif ftype == AllFontType.ttf then
         fontNode = GameFonts.getTextLabel(text,fontsize,fontcolor,dimensions,ha,va,anchor,fnode,pos,order,mb, fontfile)
      end
      -- print(ftype,fontfile, fontsize,json.encode(fontcolor), fontid, "当前需要显示的文本  = ",text)
       return fontNode
end






return  GameFonts


