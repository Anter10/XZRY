local CommonSpineLayer= class("CommonSpineLayer",RequireModel.CommonNode)
-- {
-- 	herodata = "", -- 英雄数据
-- 	size = cc.size(0,0), -- 节点大小
-- 	layertype = 1, -- 层级类型	
-- }
function CommonSpineLayer:ctor(data)
	self.super.ctor(self)
	self.layersize = data["size"]
	self.data = data["herodata"]
	self.layertype = data["layertype"] 
	self.state=BATTLEENUM.BattleRoleUnitStatue.STATUE999
	self.m_type = 1
	self.playanimationflag = false
    self.actionname = ""

	-- self:setContentSize(self.layersize)
    self:setContentSize(cc.size(0,0))
	-- self:addSpine()
end
-- 添加动画
function CommonSpineLayer:addSpine()
    local cgspinefilename = self.data:getSysitem():getSpineName()
    -- if RequireModel.fileManager.isExistFile("Hero_cg/"..cgspinefilename..".png") == false then
    --     cgspinefilename = "ui_cg_spine_100101"
    -- end 
    
    if self.spine then
        self.spine:removeFromParent()
        self.spine = nil
    end
    self.spine=sp.SkeletonAnimation:create(cgspinefilename[1]..".skel" ,cgspinefilename[2]..".atlas")
    self.spine:setScale(0.63)
    self:addChild(self.spine)

    local function animationstart(event)
		
    end

    local function animationend(event)
    	print("animationend")
    end

    local function animationcomplete(event)
        local dongzuoshifoubowan=false
        if event.loopCount==1 then
            self.m_yiwandongzuoshu=self.m_yiwandongzuoshu+1
            if self.m_yiwandongzuoshu>self.m_dongzuozongshu then
                printLog("QQ","动作计数错误")
            end
            if self.m_yiwandongzuoshu==self.m_dongzuozongshu then
                dongzuoshifoubowan=true
            end
        end

        if self.state==BATTLEENUM.BattleRoleUnitStatue.admission_unfencedSTATUE and dongzuoshifoubowan then
            self:bofangdongzuo(getRoleStatueConverAnimationArray(self.state,BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE),true)
            self.state=BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE
        elseif self.state==BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE then
            local pos = string.find(event.animation, "2")
            if (not pos) then
                if event.loopCount%3==0 then
                    if math.random(1,3)==1 then
                        self:bofangdongzuo(event.animation.."2",false)
                    end
                end
            else
                self:bofangdongzuo(string.gsub(event.animation,"2",""),true)
            end
        end

        if self.actionidtab and #self.actionidtab > 0 then
        	self.playanimationflag = true
        	table.remove(self.actionidtab,1)
        	if #self.actionidtab == 0 then
        		self.playanimationflag = false
        	end
        end
        
        local actionname = event.animation
        if self.allactionnum then
            self.allactionnum = self.allactionnum - 1
        end
        
        if self.allactionnum == 0 then
            self:setState(BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE)
        end
       
    end
    
    local function animationevent(event)
    	local name       =  event.eventData.name
        -- 事件前缀名称
        local eventPre   =  event.eventData.stringValue
        -- 事件其它值
        local floatvalue =  event.eventData.floatValue
        -- 事件ID
        local intvalue   =  event.eventData.intValue
        
        self.actionname = event.animation
        local eventId    =  self.data:getId()..self.actionname
        local actionData = getSystemData():getRoleSpecialDataById(eventId)
        
        if eventPre ==  BATTLEENUM.EventPreName.fallsmoke then
            local resname = getSystemData():getEffectsDataById(70):getL_resname()
            if resname then
                self.specialEffect = sp.SkeletonAnimation:create(resname[1]..".skel",resname[2]..".atlas",1)
                self.specialEffect:setPosition(90,40)
                self.specialEffect:setAnimation(0,"a1",false)
            end
        elseif eventPre   == BATTLEENUM.EventPreName.efx and actionData then
           print("actionData == ",json.encode(actionData.data))
           -- 获得当前事件引发的特效数据
           if actionData then
              self:releaseSpecialEfftctCall(actionData, intvalue,BATTLEENUM.EventPreName.efx)
           end
        end
    end
   
	self.spine:registerSpineEventHandler(animationstart, sp.EventType.ANIMATION_START)
    self.spine:registerSpineEventHandler(animationend, sp.EventType.ANIMATION_END)
    self.spine:registerSpineEventHandler(animationcomplete, sp.EventType.ANIMATION_COMPLETE)
    self.spine:registerSpineEventHandler(animationevent, sp.EventType.ANIMATION_EVENT)
    -- 播放当前的动画
    if self.m_type == 1 then
        self:bofangdongzuo(getRoleStatueConverAnimationArray(self.state,BATTLEENUM.BattleRoleUnitStatue.admission_unfencedSTATUE),false)
        self.state=BATTLEENUM.BattleRoleUnitStatue.admission_unfencedSTATUE
    elseif self.m_type == 2 then
        self:bofangdongzuo(getRoleStatueConverAnimationArray(self.state,BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE),false)
        self.state=BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE
    end
end


-- 设置状态
function CommonSpineLayer:setState(state)
    local isloop = false
    if state==BATTLEENUM.BattleRoleUnitStatue.admission_unfencedSTATUE then
        isloop=false
    elseif state==BATTLEENUM.BattleRoleUnitStatue.unfencedSTATUE then
        isloop=true
    end
    local dongzuoname = getRoleStatueConverAnimationArray(self.state,state)
    if type(dongzuoname) ~= "table" then
        self.allactionnum = 1
    else
        self.allactionnum = #dongzuoname
    end

    self:bofangdongzuo(dongzuoname,isloop)
    self.state=state
end

-- 播放动作
function CommonSpineLayer:bofangdongzuo(dongzuoname,shifouxunhuan)
    if dongzuoname==nil then
        printLog("QQ","没动作播啊")
        return
    end
    self.m_yiwandongzuoshu=0
    if type(dongzuoname) ~= "table" then
        shifouxunhuan=shifouxunhuan or false
        self.m_dongzuozongshu=1
        self.spine:setAnimation(0,dongzuoname,shifouxunhuan)
    else
        for i,v in ipairs(dongzuoname) do
            if i==1 then
                self.m_dongzuozongshu=1
                if type(shifouxunhuan)~="table" then
                    shifouxunhuan=shifouxunhuan or false
                    local xunhuanfou=shifouxunhuan
                    if xunhuanfou then
                        if i<table.maxn(dongzuoname) then
                            xunhuanfou=false
                        end
                    end
                    -- if self.actionidtab and #self.actionidtab == 0 then
                    -- 	getRoleStatueConverAnimationArray(BATTLEENUM.BattleRoleUnitStatue.STATUE999,BATTLEENUM.BattleRoleUnitStatue.admission_unfencedSTATUE)
                    -- 	self.state = BATTLEENUM.BattleRoleUnitStatue.admission_unfencedSTATUE
                    -- else
                    	self.spine:setAnimation(0,dongzuoname[i],xunhuanfou)
                    -- end
                    
                else
                    dongzuoname[i]=dongzuoname[i] or false
                    self.spine:setAnimation(0,dongzuoname[i],shifouxunhuan[i])
                end
            else
                self.m_dongzuozongshu=self.m_dongzuozongshu+1
                if type(shifouxunhuan)~="table" then
                    shifouxunhuan=shifouxunhuan or false
                    local xunhuanfou=shifouxunhuan
                    if xunhuanfou then
                        if i<table.maxn(dongzuoname) then
                            xunhuanfou=false
                        end
                    end
                    self.spine:addAnimation(0,dongzuoname[i],xunhuanfou)
                else
                    dongzuoname[i]=dongzuoname[i] or false
                    self.spine:addAnimation(0,dongzuoname[i],shifouxunhuan[i])
                end
            end
        end
    end

end

-- 随机播放动作
function CommonSpineLayer:setRandomAction()
    if self.playanimationflag then
        self.spine:clearTracks()
    end
	self.actionidtab = {}

    local randomanimationdata = getSystemData():getSystemHeroRandomActionsData(0)
    local actionname = getStringArray(randomanimationdata:getActionName(),",")
	local randomindex = math.random(1,2)
	local animationname
	if randomindex == 1 then
		animationname = actionname[1]
        -- RandomAnimationData.RandomData1
	elseif randomindex == 2 then
		animationname = actionname[2]
        -- RandomAnimationData.RandomData2
	end
    print("animationname = ",animationname)
    local randomanimationdata = getSystemData():getSystemHeroRandomActionsData(animationname)
	self.actionstab = randomanimationdata:getActions()
	for index,actionid in pairs(self.actionstab) do
        print("actionid = ",actionid,type(actionid))
		local herostatueconvertdata = getSystemData():getHeroStatueById(actionid)
		local initanimation = herostatueconvertdata:getStatueName()
		self.actionidtab[#self.actionidtab+1] = initanimation
	end
	
	self.allactionnum = #self.actionidtab
    -- self.actionidtab[#self.actionidtab+1] = {"z_ready","z_ready"}
    local allanimations = self.actionidtab

    print("allanimations = ",json.encode(allanimations))
    for i,v in ipairs(allanimations) do
    	if i == 1 then
           self.spine:setAnimation(0,v,false)
        else
           if i < #allanimations then
              self.spine:addAnimation(0,v,false)
           else
              self.spine:addAnimation(0,v,true)
           end
    	end
    end
end

-- 设置播放动画
function CommonSpineLayer:setPlaySpine(allanimations)
    self.actionidtab = allanimations
    if self.playanimationflag then
        self.spine:clearTracks()
    end
    -- print("allanimations = ",json.encode(allanimations))
    for i,v in ipairs(allanimations) do
        if i == 1 then
            self.spine:setAnimation(0,v,false)
        else
            if i < #allanimations then
                self.spine:addAnimation(0,v,false)
            else
                self.spine:addAnimation(0,v,true)
            end
        end
    end
end

-- 释放随身特效
function CommonSpineLayer:releaseSpecialEfftctCall(actionData, intvalue,eventtype)
    -- 现在改成了特效组合释放 2017 1月 6号
    local groupdata = actionData:getEfx()[speicalId]
    local bones     = actionData:getEfxNodes()
    --print("当前的特效组合的数据   = ",json.encode(groupdata))
    if groupdata and type(groupdata) == "table" then
        for groupidIndex,groupid in ipairs(groupdata) do
            local releaseGroupData   = {}
            releaseGroupData.groupid = groupid
            releaseGroupData.single  = true
            local row, column        = self:getRowAndColumn()
            releaseGroupData.row     = row
            releaseGroupData.column  = column 
            local currentRoleDir     = self:getDirection() 
            local bone               = nil

            if bones and type(bones) == "table" then
               if bones[speicalId] then
                  bone = bones[speicalId]
               end
            end
            
            local bonepos = cc.p(0,0)
            local nodeName = nil
            if bone then
               nodeName =  SystemDataManager:getSoltNameDataById(bone[groupidIndex]):getSoltName()
               bonepos        =  self:getRoleNodePosition(nodeName)
               -- print(nodeName,"附加的位置21   = ",json.encode(bonepos))
            end
            print(nodeName,"附加的位置22  = ",json.encode(bonepos))
            if currentRoleDir == BATTLEENUM.SetRoleDirection.left then
               releaseGroupData.column  = column
            elseif currentRoleDir == BATTLEENUM.SetRoleDirection.right then
               releaseGroupData.column  = column + 1 
            end
            releaseGroupData.addonroleid = self:getRoleData():getRoleUniqueId()
            releaseGroupData.addpos      = bonepos
            releaseGroupData.addonbone   = nodeName
            local effectGronup         = GroupEffect.new(releaseGroupData, roleid, BATTLEENUM.GroupEffectType.useatk)
            for i,special in ipairs(effectGronup:getSpecials()) do
                 self:addNodeOnSpine(nodeName,special,10)
            end
            print("efx事件产生的播放的特效组合   =     ",json.encode(releaseGroupData))
            -- BATTLEENUM.getCurrentBattleLayer():releaseEffectGroup(releaseGroupData) 
        end
    end
end

---添加特效
-- 再当前战斗单位的Spine上面添加节点
function CommonSpineLayer:addNodeOnSpine(nodename, node , zorder)
   zorder = zorder or 0
   self.m_spine:tianjiagengugedeNode(nodename, node,zorder)
end


return CommonSpineLayer