-- 游戏发布的语言
cc.exports.ALlLanguageType = {
    ch = 1, -- 中文
    en = 2, -- 英文
    ru = 3, -- 俄罗斯
}
cc.exports.mainlevel = -1--主界面等级

cc.exports.getTCNum = function(nNum, n)
    local tnum = "0."
    local lj   = "0"

    for i = 1, n - 2 do
       if i == n - 2 then
          lj = "1"
       end
       tnum = tnum..lj
    end

    local preNum = string.sub(tostring(nNum),1,n)
    local anum   = string.sub(tostring(nNum),n+1,n+1)
    if tonumber(anum) > 5 then
       preNum = tonumber(preNum) + tonumber(tnum)
    end
    print(tnum, " anum = ",anum)
    return preNum 
end

-- 游戏中用到的数据配置信息
cc.exports.GMMESSAGE = {
     version   = '0_0_1',            --     游戏发布版本(游戏的基础版本)
     name      = '血之荣耀',          --     游戏名称
     company   = '艾斯米乐',          --     开发商名称
     url       = '公司官网',          --     公司网址
     address   = '公司地址',          --     公司地址
     email     = '公司邮箱',          --     公司邮箱
     phone     = '公司服务电话',       --     公司服务电话 
     chanel    = '渠道号/名称',        --     渠道号/名称
     loginurl  = "登陆服务器",          --     登陆服务器
     gameurl   = "游戏服务器",
     updateurl = "192.168.1.25:9080",
     language  = ALlLanguageType.ch, --     语言 默认中文   
}


-- 关于游戏中的时间ID
cc.exports.AboutGameTimes = {
    skillbuttonshoworhide = 17, -- 技能按钮 消失后 显示的时间  
    openchestitemtime     = 18, -- 战斗结算后 打开宝箱中物品的移动速度
}

-- 比较两个相同格式 相同分隔符号的字符串的大小 
-- @注意:   是第一个是否比第二个大
-- @str1:  第一个字符串
-- @str2:  第二个字符串
-- @party: 分隔符
-- 返回1 等于 返回true 大于
cc.exports.CTString = function( str1, str2, party )
     local sa1 = getStringArray(str1, party)
     local sa2 = getStringArray(str2, party)
     
     local mt    = false
     local equal = true
     -- print("sa2[num1Index] = ",json.encode(sa1) , json.encode(sa2))
     for num1Index,num1 in ipairs(sa1) do
         
         if sa2[num1Index] then 
            if tonumber(num1) > tonumber(sa2[num1Index]) then
               mt = true
            elseif tonumber(num1) ~= tonumber(sa2[num1Index]) then
               equal = false
            end  
         end   
     end

     -- print("str1, str2, party = ",str1, str2, party)
     if equal and not mt then
        mt = 0
     end

     return mt
end

-- 当前平台名称
cc.exports.targetplatform   =  cc.Application:getInstance():getTargetPlatform()

-- 当前屏幕尺寸
cc.exports.winsize          =  cc.Director:getInstance():getWinSize()
-- print("屏幕尺寸 = ",json.encode(winsize))
cc.exports.GameFile  = RequireModel.fileManager


cc.exports.setGray = function(sprite)
    local program
    if not program then
        local vsh = "attribute vec4 a_position;"..
            "attribute vec2 a_texCoord;"..
            "attribute vec4 a_color;".. 
            "varying vec4 v_fragmentColor;"..
            "varying vec2 v_texCoord;"..
            "void main()"..
            "{"..
            "gl_Position =  CC_PMatrix * a_position;"..
            "v_fragmentColor = a_color;"..
            "v_texCoord = a_texCoord;"..
            "}";

        local fsh = "varying vec4 v_fragmentColor;"..
            "varying vec2 v_texCoord;"..
            "void main()"..
            "{"..
            "vec4 v_orColor = v_fragmentColor * texture2D(CC_Texture0, v_texCoord);"..
            "float gray = dot(v_orColor.rgb, vec3(0.299, 0.587, 0.114));"..
            "gl_FragColor = vec4(gray, gray, gray, v_orColor.a);"..
            "}";
        --            "float gray = dot(v_orColor.rgb, vec3(0.299, 0.587, 0.114));"..
        local program = cc.GLProgram:createWithByteArrays(vsh, fsh)
        program:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION,cc.VERTEX_ATTRIB_POSITION)
        program:bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR,cc.VERTEX_ATTRIB_COLOR)
        program:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD,cc.VERTEX_ATTRIB_FLAG_TEX_COORDS)
        program:link()
        program:updateUniforms()
        local yuanprogram=sprite:getGLProgram()
        sprite:setGLProgram(program)
        return yuanprogram
    end
end

-- 随机动画数据
cc.exports.RandomAnimationData = {
    RandomData1 = "AC01",
    RandomData2 = "AC02",
    RandomData3 = "AC03",
}

-- 通用按钮音效类型
cc.exports.UIButtonAudios = {
    clickbtn         = "EUI1001", -- 点选音效
    closebtn         = "EUI1002", -- 关闭类型音效
    backbtn          = "EUI1003", -- 返回音效音效
    swithbtn         = "EUI1004", -- 切换音效
    okbtn            = "EUI1005", -- 确定音效
    cancelbtn        = "EUI1006", -- 取消音效
    equipbtn         = "EUI1022", -- 装备按钮音效
    unequipbtn       = "EUI1023", -- 卸下按钮音效
    strongbtn        = "EUI1024", -- 强化按钮音效
    partybtn         = "EUI1025",-- 分解按钮音效
    intomapbtn       = "EUI1026", -- 进入副本按钮音效
    errorresult      = "EUI1009", --  错误/无效音效
    buygoldss        = "EUI1010", -- 金币出售购买成功音效
    sealbuygetgold   = "EUI1020", --出售/购买获取金币音效
    buydiamondss     = "EUI1011", -- 钻石购买成功音效
    getdiamond       = "EUI1021",-- 获取钻石音效
    playeruplevel    = "EUI1012", -- 升级（玩家）音效
    herouplevel      = "EUI1013", -- 升级（英雄）音效
    heroupstar       = "EUI1014", -- 升星（英雄）音效
    heroskillup      = "EUI1015", -- 技能升级（英雄）音效
    strongfailuer    = "EUI1016", -- 强化失败音效
    strongsuccess    = "EUI1017", -- 强化成功音效
    eatexpbook       = "EUI1018", -- 吃经验书音效
    quickresult      = "EUI1019", -- 快速结算弹窗音效

    boomout          = 23, -- 弹出
    fallin           = "EUI1007", -- 落下（锁链）音效
    fallinpar        = "EUI1008", -- 落下（旗帜）音效
    moveed           = "EUI1031", -- 滑动    音效
    showbuild        = "EUI1032", -- 出现_建筑音效
    gettencard       = "EUI1035", -- 十连抽卡片出现声音
    cardrotate       = "EUI1037", -- 卡片翻卡声音
    battlestart      = "EUI1038", -- 战斗开始（人声）
    energynoenough   = "EUI1039", -- 能量不足（人声）
    bigmapboundenemy = "EUI1040", -- 大地图遇敌（角色）
    bigmapchessmove  = "EUI1041", -- 大地图移动(棋子）
    bigmapplayershow = "EUI1042", -- 大地图（玩家）出现
    bigmapenemyshow  = "EUI1043", -- 大地图（敌人）出现
    bigmapitemshow   = "EUI1044", -- 大地图（道具）出现   
}

-- 游戏播放音效
-- audioid   音效ID
-- audiotype 音效类型
cc.exports.playUIAudio = function( audioid , audiotype)
    local audiodata   =   getSystemData():getUiAudioEffectById(audioid)
    if audiodata then
       local musiclfile = "UI_music/"..audiodata:getFileName()
       GameMusic.playSound(musiclfile, false)
    end
end


-- 通过sender的tag参数对声音进行处理
-- tag: 设置音效的标签
cc.exports.PlayAudioEffectbyTag = function(tag)
   
end

-- 道具类型分类
cc.exports.AllItemType = {
    weapon   = 1,    -- 武器
    armor    = 2,    -- 护甲
    helmet   = 3,    -- 头盔
    shop     = 4,    -- 鞋子
    ring     = 5,    -- 戒指
    necklace = 6,    -- 项链
    fragment = 7,    -- 角色碎片
    rune     = 8,    -- 符文
    ohter    = 9,    -- 暂无
    clothes  = 10,   -- 衣服
    taskprop = 11,   -- 任务道具
    consumables = 12,-- 消耗品
    equipstrength = 13, -- 装备强化材料
    skillstrength = 14, -- 技能强化材料
    materialdata = 15,  -- 装备技能数据
    equipdata = 16,     -- 所有装备数据
}

-- 清理游戏资源
cc.exports.clearMemory = function()
    cc.AnimationCache:destroyInstance()
    cc.SpriteFrameCache:getInstance():removeSpriteFrames()
    cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    cc.Director:getInstance():getTextureCache():removeAllTextures()
    cc.Director:getInstance():purgeCachedData()
end

cc.exports.ViewIntroduceType = {
    teamview = 1,  -- 队伍弹框视图
    heropropertyview = 2, -- 英雄弹框视图
    skillview = 3, -- 技能弹框视图
    strengthview = 4, -- 强化弹框视图
    decomposeview = 5, --分解弹框视图
}

-- 对现有道具进行排序的类型
cc.exports.SortEquipsItemType = {
    attack = 1,  -- 攻击
    def    = 2,  -- 防御
    ptwo   = 3,  -- 均衡
    other  = 4   -- 其它
}

-- 道具基础属性类型
cc.exports.AdditionPropType = {
   zero = 0,     -- 无
   patk = 1,     -- 物理攻击
   matk = 2,     -- 魔法攻击
   pdef = 3,     -- 物理防御
   mdef = 4,     -- 魔法防御
   boomatk  = 5, -- 暴击率
   boomhurt = 6, -- 暴击伤害
   speed    = 7, -- 速度
   action   = 8, -- 行动量
   hp       = 9, -- 生命力
 }

-- 特殊界面跳转的中间界面涉及
cc.exports.specialUi = {
    itemfromwhere    = {},  -- 从章节列表里面弹入具体副本地图
}


-- 添加自动模式下播放的特效
-- prename 前缀名称 
-- num     图片数量
cc.exports.createAnimate = function(prename, num, ra)
        local animation = cc.Animation:create()
        local number, name
        for i = 1, num do
            if i < 10 then
              number = "0"..i
            else
              number = i
            end
            name = "tx_button_auto/"..prename..number..".png"
            animation:addSpriteFrameWithFile(name)
        end

        -- should last 2.8 seconds. And there are 14 frames
        local everytime = 1 / num
        animation:setDelayPerUnit(everytime)
        alltime =  everytime * num
        animation:setRestoreOriginalFrame(true)
        local action  = cc.Animate:create(animation)
        local rf      = cc.RepeatForever:create(action)
        local actions = action
        if not ra then
           actions = rf
        end
        return actions
end


-- 发送相关的GM命令
cc.exports.GMData = {
   -- 获得新英雄
   getHero = function(heroid)
      -- print("想要获得的新英雄 = ",heroid)
      sendMessageToServer(SENDMESSAGEIDS.PlayerGMData,"#gethero "..tostring(heroid))
   end,
   -- 获得新物品
   getItem = function(itemid,num)
      -- print("想要获得的新物品 = ",itemid)
      sendMessageToServer(SENDMESSAGEIDS.PlayerGMData,"#getItem "..tostring(itemid).." "..num)
   end,

   getGold = function(num)
      sendMessageToServer(SENDMESSAGEIDS.PlayerGMData,"#金币 "..tostring(num))
   end,
   
   getDiamound = function(num)
      sendMessageToServer(SENDMESSAGEIDS.PlayerGMData,"#钻石 "..tostring(num))
   end,

   getUplevel = function(onlyid,level)
      sendMessageToServer(SENDMESSAGEIDS.PlayerGMData,"#uplevel "..tostring(onlyid).." "..tostring(level))
   end
}



-- 游戏中所有的特殊技能
cc.exports.AllSpecialSkill  = {
     ss200201 =  200201,    -- 奥尔良少女  胜利旗帜
     ss201201 =  201201,    -- 黑骑士  天谴
     ss293001 =  293001,    -- 防御水晶
}

-- 游戏中的 代币/消费 类型
cc.exports.AllCustomeType  = {
    g   = 1,  --  金币
    d   = 2,  --  钻石
    p   = 3   --  体力
}

 
-- 所有请求消息号
cc.exports.SENDMESSAGEIDS  = {
	  PostLoginId            =  10001,   -- 请求登录
	  PostPlayerMessageId    =  10003,   -- 请求玩家信息
  	MatchingPlayer         =  10005,   -- 匹配玩家信息
  	PostHeroMoveId         =  10007,   -- 发送英雄移动信息
    PostClientHasReady     =  10009,   -- 客户端已经准备好
    PostHasEndShow         =  10011,   -- 英雄展示完成
    PostRoleDirection      =  10013,   -- 英雄转向
    PostRoleReleaseSkill   =  10015,   -- 使用技能
    PostRoleEndRound       =  10017,   -- 结束回合
    PostSelectTeamID       =  10019,   -- 选择出战队伍
    PostBackMovePre        =  10021,   -- 返回到移动前
    DealPropData           =  40001,   -- 处理道具编号
    TeamAddHero            =  10023,   -- 队伍里添加英雄
    TeamReplaceHero        =  10025,   -- 队伍里替换英雄
    TeamHeroSetPosition    =  10027,   -- 队伍里英雄更新位置
    TeamDeleteHero         =  10029,   -- 队伍里删除英雄
    BatlleSceneModel       =  10031,   -- 镜头拉近
    TeamAddThings          =  10039,   -- 队伍功能物件添加、替换
    TeamDeleteThings       =  10041,   -- 队伍功能物件移除
    TeamreSet              =  10043,   -- 队伍位置重置，自动布阵
    PostBattleResultData   =  14001,   -- 发送战斗结算的数据
    EquipStrengthLevel     =  10103,   -- 装备强化
    EquipSpliteData        =  10105,   -- 装备分解
    HeroGradeStar          =  12001,   -- 英雄升星
    RequestChapter         =  16001,   -- 请求章节数据
    ChapterMissionCompleted=  16003,   -- 告诉服务器章节通关
    PlayerPropSale         =  10107,   -- 物品出售
    PropSingleSale         =  10109,   -- 出售单个物品
    PropCombine            =  10111,   -- 物品合成
    SetTeamLeaderData      =  10045,   -- 设置队长
    RequestDrawPrise       =  15001,   -- 请求抽奖信息
    StartDrawPrise         =  15003,   -- 抽奖


	  PostLoginErrorOrSuccessId =  10002,   -- 登录成功失败
	  PostInitUserData          =  10004,   -- 初始化玩家信息
  	MatchingPlayerData        =  10006,   -- 匹配数据
  	MoveRoleUnitData          =  10008,   -- 玩家操作结果反馈信息
	  PostReadyCallBack         =  10010,   -- 本场战斗已经结束的数据
	  MovePriorityData          =  10012,   -- 行动优先级的判断
    TeamLeaderSkillFinish     =  10014,
    BattleRoleBackPre         =  10022,   -- 英雄返回到上一次操作的位置
    BattleCanBack             =  10024,   -- 战斗是否可以返回
    TeamSetHeroisSuccess      =  10026,   -- 队伍设置是否成功
    BattleResult              =  10028,   -- 战斗结果
    ChapterInformation        =  16002,   -- 获得章节信息
    

    BatlleSceneModelData      =  10032,   -- 技能镜头拉伸
    PlayerAddHero             =  10034,   -- 获得新英雄
    PlayerNewEquipData        =  10036,   -- 获得新物品
    PlayerIsDressedEquipData  =  10037,   -- 是否穿戴装备
    PlayerDressedResultData   =  10038,   -- 英雄穿戴装备结果反馈
    PlayerDeleteAndUpdataEquip =  10102,   -- 删除更新物品g183

    RequestHeroEvaluateList   =  19001,   -- 请求英雄评价列表
    HeroEvaluateList          =  19002,   -- 英雄评价列表
    PraiseHeroEvaluate        =  19003,   -- 点赞英雄评价
    PublishEvaluate           =  19005,   -- 发表评论
    PlayerGMData              =  20000,   -- 玩家发送新英雄数据
    SkillUpLevel              =  11001,   -- 升级技能
    SkillUpLevelResult        =  11002,   -- 技能升级结果
    UpdataMoneyData           =  20002,   -- 更新钱币信息
    HeroUpgrade               =  12000,   -- 英雄升级

    
    EquipStrengResult         =  10104,   -- 装备强化结果
    EquipSpliteResult         =  10106,   -- 装备分解结果
    ReceiveBattleResult       =  14002,   -- 收到战斗结算的数据
    PropCombineResult         =  10112,   -- 物品合成结果
    InitDrawPrise             =  15000,   -- 抽奖初始化消息
    DrawPriseResult           =  15004,   -- 抽奖结果
    ErrorResult               =  15006,   -- 错误编号
    SaleMateral               =  10110,   -- 出售材料
    SaleMateralResult         =  10114,   -- 禁止出售结果
} 


-- 剧情对话条件
cc.exports.ShowRoleDialogCondition = {
   intopve         = 1, -- 进入副本
   pvesenemy       = 2, -- 副本遇到敌人
   movemaptocell   = 3, -- 移动到地图的某个地块
   vicbattle       = 4, -- 战斗胜利的数据
}

-- 显示对话框
-- @showid: 对话框的ID
cc.exports.showDialog = function(showid,pos, data, repeate, parent, cantrm)
    local dialog = RequireModel.DialogView
    return dialog.show(showid,pos, data, repeate, parent, cantrm)
end

cc.exports.jumpDialog = function(data, repeate)
    local dialog = RequireModel.DialogView
    dialog.jumpDialog(data, repeate)
end



-- 创建精灵
-- @filename：精灵名称 isplist是否为plist文件
cc.exports.createSprite = function(filename, isplist)
    if GameFile.isExistFile(filename) then
        if isplist then
          return cc.Sprite:createWithSpriteFrameName(filename)
      else
          return cc.Sprite:create(filename)
        end 
    else
        printError("没有图片资源："..filename)
    end
end

-- 创建按钮
-- @normalImage,selectedImage,,disabledImage正常选择消失图片资源 isplist(1: 为PLIST)：是否为plist文件
-- @startcallback, movecallback, endedcallback, audioname 开始点击回调，移动回调
-- @isscale按钮起始放大倍数
cc.exports.createButton = function(normalImage,selectedImage,disabledImage,isplist, startcallback, movecallback, endedcallback,scalex,scaley,audioname)
    local function setCallback(sender, eventType)
        if sender.notebletouch then
            return false
        end
        if eventType==0 then
            -- 开始音效
            if sender:getStartAudio() and sender:getStartAudio() ~= "" then
               playUIAudio(sender:getStartAudio())
            end
            sender:setScaleX(scalex*1.1)
            sender:setScaleY(scaley*1.1)

            if startcallback then
                startcallback(sender)
            end
        elseif eventType==1 then
            if sender:getMoveAudio() and sender:getMoveAudio() ~= "" then
               playUIAudio(sender:getMoveAudio())
            end
            if movecallback then
                movecallback(sender)
            end
        elseif eventType==2 then
            -- GameMusic.stopSound(audioname)
            if endedcallback then
                endedcallback(sender)
            end
            if sender:getErrorAudio() and sender:getErrorAudio() ~= "" then
               playUIAudio(sender:getErrorAudio())
            end
            if sender:getSuccessAudio() and sender:getSuccessAudio() ~= "" then
               playUIAudio(sender:getSuccessAudio())
            end
            sender:setScaleX(scalex)
            sender:setScaleY(scaley)
        else
            sender:setScaleX(scalex)
            sender:setScaleY(scaley)
        end
    end
    -- if GameFile.isExistFile(filename) then
        scalex = scalex or 1
        scaley = scaley or 1

        isplist = isplist or 0
        local button = ccui.Button:create(normalImage,selectedImage,disabledImage, isplist)
        button:setScale(scalex,scaley)
        button:addTouchEventListener(setCallback)
        return button
    -- else
    --     printError("没有图片资源："..filename)
    -- end
end

-- 对包含有特殊字符的字符串进行分割 返回分割后的数组
-- @str:         被分割的数组
-- @split_char:  特殊字符
cc.exports.getStringArray = function(str , split_char)
   local sub_str_tab = {};
    local len = string.len(split_char)
    while (true) do
        local pos = string.find(str, split_char);
        if (not pos) then
            sub_str_tab[#sub_str_tab + 1] = str;
            break;
        end
        local sub_str = string.sub(str, 1, pos - 1);
        sub_str_tab[#sub_str_tab + 1] = sub_str;
        str = string.sub(str, pos + len, #str);
    end
    return sub_str_tab
end

-- 寻找行列数组中是否包含某个行列数据
cc.exports.ContainCellData = function(datas, data)
    if datas and data then
       local hasit  =  false
       for dataIndex , tdata in pairs(datas) do
           if data.row == tdata.row and data.column == tdata.column then
              hasit   =  true
              break
           end
       end
       return hasit
    end
end

cc.exports.GameBarType ={
      chp       = 1,       -- 中间的血条
      movevalue = 2,       -- 行动力槽
      hhp       = 3        -- 人物头顶的血条
}


-- 是 与 否 无效
cc.exports.YES       =  1
cc.exports.NO        =  0
cc.exports.NE        =  -1


 

-- 技能的攻击类型
cc.exports.SkillAttackType = {
    none   =  -1, -- 没有
    map    =  1,  -- 地板
    enemy  =  2    -- 人
}



-- 点击释放技能的类型
cc.exports.ReleaseSkillClickType = {
    role     = 1,-- 点击战斗单位
    map      = 2,-- 点击地图
    additem  = 3 -- 放置物品
}

-- 护盾类型
cc.exports.ProtectedType = {
       P   = 1, -- 物理防御
       M   = 2  -- 魔法防御
}

-- 护盾等级
cc.exports.ProtectedLevel = {
       l1  = 1,    -- 护盾等级1
       l2  = 2,    -- 护盾等级2
       l3  = 3,    -- 护盾等级3
       l4  = 4,    -- 护盾等级4
       l5  = 5     -- 护盾等级5
}

-- 相关攻击暴击类型
cc.exports.AttackBoomType = {
    pcb = 1,   -- 物理普攻暴击
    psb = 2,   -- 物理技能暴击
    mcb = 3,   -- 魔法普攻暴击
    msb = 4    -- 魔法技能暴击
}

-- 得到当前是战场中的战斗单位管理对象
local battlemanagers = nil
local BattleRoleUnitsManager = nil
cc.exports.getBattleManager = function()
     if not BattleRoleUnitsManager then
        BattleRoleUnitsManager = RequireModel.BattleRoleUnitsManager
     end
     if not battlemanagers then
        -- 战斗单位管理模版
        battlemanagers = BattleRoleUnitsManager:create()
     end

     return battlemanagers
end

-- 清空战斗数据管理
cc.exports.clearBattleManager = function( ... )
    battlemanagers = nil
end





-- 两点之间的距离
cc.exports.twoPointDistance   = function(pointOnex,pointOney, pointTwox,pointTwoy)
	local xDistance = math.abs(pointOnex  -  pointTwox) 
	local yDistance = math.abs(pointOney  -  pointTwoy)
	return math.sqrt(xDistance * xDistance +  yDistance * yDistance)
end

-- 两点之间的偏移度
function cc.exports.pointToPointOfAngle(x1,y1,x2,y2)
    return c_liangdianlianxianpianyijiaodu(x1, y1, x2, y2)
end


-- 游戏的相关配置参数信息
cc.exports.GameParam = {

}

--蓝条类型
cc.exports.BluebarType = {
	MPType = 1,--魔法
	EPType = 2,--能量
	AMType = 3,--弹药
}

-- 战斗单位左边状态
cc.exports.RoleLeftStatues = {
    noStatue       = 0,   -- 无状态
	  defence        = 1,   -- 防御状态
	  gatherStrength = 2,   -- 蓄力状态
    repair         = 3    -- 修复状态
}

-- 战斗单位buff状态
cc.exports.RoleBuffStatue  = {
	atkUp    =  1,        
	atkRed   =  2,
	defUp    =  3,
	defRed   =  4
}


--货币类型
cc.exports.CurrencyType = {
    gold     = 1,--金币
    diamonds = 2,--钻石
    strength = 3,--体力
}

-- 英雄两个状态转换的动作序列
-- @currentstateID: 当前的状态
-- @convertstateID: 需要转换的状态
-- @role: 当前设置状态的战斗单位
local allconvertdata  = {}

cc.exports.getRoleStatueConverAnimationArray = function(currentstateID,convertstateID, role)
    local convert    =   getSystemData():getPlayerRoleStatueConverAnimationArray(tostring(currentstateID),tostring(convertstateID))
    
    
    local allactions = {}
    local fstatuedata = getSystemData():getHeroStatueById(convertstateID * 10)
    if role and role.getRoleData then
       role:getRoleData():setStatueData(fstatuedata)
    end
    ---- print("转换数据12=  ",currentstateID, convertstateID,json.encode(allactions))
    -- 获得动作序列列表
    if currentstateID == BATTLEENUM.RoleSpecialStatue.TeammberInto then
       -- allactions[#allactions + 1] = 310
    elseif currentstateID == BATTLEENUM.RoleSpecialStatue.Teamleader  then
       -- allactions[#allactions + 1] = 300
    elseif currentstateID == BATTLEENUM.RoleSpecialStatue.ReleaseSkill then
       
    else
        if convert then
           allactions =  getActionsByAction(convert:getAnimationArray())
           if allactions then
              local targetaction = getSystemData():getHeroStatueById(convertstateID * 10)
              allactions[#allactions + 1]  =  targetaction
           end
        end
    end
   
    ---- print("最后播放的动作12=  ",json.encode(allactions))
    -- 将动作id转换成动作名称
    local actionnames = {}

    for actionIndex , actionId in ipairs(allactions) do
        statuedata = getSystemData():getHeroStatueById(actionId)
        if statuedata then
            local animationname = statuedata:getStatueName()
            actionnames[#actionnames + 1] = animationname
        end
    end

    if fstatuedata then
       actionnames[#actionnames + 1] = fstatuedata:getStatueName()
    end
    
    -- printError("最后播放的动作=  "..json.encode(actionnames))
   -- print("currentstateID,convertstateID = ",currentstateID,convertstateID)
   
	  return actionnames
end

-- 英雄的朝向
 cc.exports.RoleDirection  = {
    left  = 0,
    right = 1,
    up    = 2,
    down  = 3,
 }

-- 得到战斗场景数据
cc.exports.getSystemSceneData  =  function(id) 
   return RequireModel.SystemDataManager.getSytemDataManager():getSystemSceneParamDataByID(id)
end
 

cc.exports.renwuOriginalState={
    aggressiveStance=1,
    nonDefensiveStance=2,
    defensiveStance=3,
}

cc.exports.UIID={
    TeamSetUpLayer=205,--队伍设置
    MainLayer=213,--游戏主界面
    BagLayer=2,--背包
    BattleRoleUnitAttributesLayer=4,--属性界面
    WorldMapLayer=5,--世界地图界面
    TerritoryMapLayer=205,--地盘界面
    FormationLayer=210,--阵型设置界面
    AllHeroView = 9, -- 所有英雄展示层
    HeroViewLayer = 10, -- 英雄属性层
    EquipPropertyView = 11, -- 装备层
    MailLayer = 12, -- 邮箱界面
    ChapterList = 206, -- 章节列表界面
    TerritoryMapSettlementLayer = 208,--探索地图结算界面
    EquipStrengthView = 20,   -- 装备强化界面
    EquipDecomposeView = 21,  -- 装备分解界面
    EquipCompareView = 22, -- 装备对比界面
    StoreHouseMainView = 23, -- 仓库主界面
    HeroSetLayer = 24, -- 英雄设置层
    ShopLayer = 211, -- 商店界面
    BuyResultLayer = 212,--抽奖结算界面
    TeamHeroView = 26, -- 队伍英雄界面
    TaskPanelLayer = 207,--副本任务界面
}
cc.exports.chessmanState={
  StandState=1,--站立
  JumpState=2,--跳跃
  StandbyState=3,--待机
  BornState=4,--出生
  DieState=5,--死亡
}
cc.exports.BattleMap={
   TerritoryMap=1,--探索地图
}
cc.exports.IconType = {
    HeroIcon = 1,  -- 英雄头像节点
    EquipIcon = 2, -- 装备头像节点
    PropIcon = 3,  -- 道具头像节点
    SkillIcon = 4, -- 技能头像节点
    MonsterIcon = 5, -- 怪头像节点
    HeroEquipIcon = 6, -- 英雄装备节点
}

cc.exports.CurrentRunNode=nil--当前场景的根节点
function setCurrentRunNode(node)--设置当前场景的根节点
    CurrentRunNode=node
end
function getCurrentRunNode()--获得当前场景的根节点
    return CurrentRunNode
end

-- 查找字符创是否包含某个子字符串
-- @str     被查找的字符串
-- @findstr 查找的字符串
cc.exports.findStringInString = function(str, findstr)
   local startPos , endPos = string.find(str,findstr)
   if startPos and endPos then
      return true
   end
end

-- 所有结算的类型
cc.exports.GetItemType = {
    chapter     = 1, -- 章节结算类型
    battle      = 2, -- 战斗结算类型
    quickbattle = 3, -- 快速战斗类型
}

local cursetgetitemtype = nil
-- 设置当前的结算类型
cc.exports.setGetItemType = function(gtt)
    cursetgetitemtype    = gtt
end

-- 得到当前的结算类型
cc.exports.getGetItemType = function()
   return cursetgetitemtype
end


-- 得到静态数据
cc.exports.getSystemData = function()
	return RequireModel.SystemDataManager.getSytemDataManager()
end 

-- 得到玩家数据管理
cc.exports.getPlayerData = function()
   return RequireModel.PlayerDataManager.getPlayerDataManager()
end

-- 发送数据给服务器端
function cc.exports.sendMessageToServer(...)
	local sendData       =  {...}
 	local sendBinary     =  cc.CMessage:create()
 	local messageId      =  sendData[1]
    -- 消息屏蔽层
    cc.exports.messageshelterlayer = RequireModel.MessageShelterLayer.new()
    getCurrentRunNode():addChild(messageshelterlayer,9999)
    print("当前发送给服务器端的消息  = ",json.encode(sendData)) 

 	sendBinary:setInt(messageId)
  
    if not messageId then
       return
    end
  
 	if messageId == SENDMESSAGEIDS.PostLoginId then             --请求登录
 		sendBinary:setString(sendData[2])
 		sendBinary:setString(sendData[3])
  elseif messageId == SENDMESSAGEIDS.PostClientHasReady         then   -- 进入回合
    getCurrentRunNode():addBattleLayer()
 	elseif messageId == SENDMESSAGEIDS.PostPlayerMessageId then --请求玩家信息
        
 	elseif messageId == SENDMESSAGEIDS.PostHeroMoveId then      --发送移动信息
        sendBinary:setChar(sendData[2])
        local postPathMoveId = sendBinary:getCharByWy(sendData[3],sendData[4])
        ---- print("postPathMoveId =  ",postPathMoveId)
 		    print(postPathMoveId,"发送的移动路径 =- ",json.encode(sendData))
 		    sendBinary:setChar(postPathMoveId)
  elseif messageId == SENDMESSAGEIDS.PostRoleDirection then   -- 英雄转向
        sendBinary:setChar(sendData[2])
        sendBinary:setChar(sendData[3])
  elseif messageId == SENDMESSAGEIDS.PostRoleEndRound  then   -- 结束当前战斗单位的回合
        sendBinary:setChar(sendData[2]) 
  elseif messageId == SENDMESSAGEIDS.PostBackMovePre   then   -- 返回的时候调用
        sendBinary:setChar(sendData[2])
  elseif messageId == SENDMESSAGEIDS.PostRoleReleaseSkill then -- 使用技能发送的数据
        sendBinary:setChar(sendData[2])
        sendBinary:setInt(sendData[3]) 
        sendBinary:setChar(sendData[4])
        sendBinary:setChar(sendData[5])
        sendBinary:setChar(sendData[6])
  elseif messageId==SENDMESSAGEIDS.TeamAddHero then -- 队伍里添加英雄
        sendBinary:setChar(sendData[2])
        sendBinary:setLong(sendData[3])
        sendBinary:setChar(sendData[4])
        sendBinary:setChar(sendData[5])
  elseif messageId==SENDMESSAGEIDS.TeamReplaceHero then -- 队伍里替换英雄
        sendBinary:setLong(sendData[2])
        sendBinary:setLong(sendData[3])
  elseif messageId==SENDMESSAGEIDS.TeamHeroSetPosition then -- 队伍里英雄更新位置
        sendBinary:setChar(sendData[2])
        for index,data in ipairs(sendData[3]) do
            sendBinary:setChar(data.changtype)
            if data.changtype==1 then
              sendBinary:setLong(data.changeid)
            elseif data.changtype==2 then
              sendBinary:setInt(data.changeid)
            end
            sendBinary:setChar(data.row)
            sendBinary:setChar(data.column)
        end
  elseif messageId==SENDMESSAGEIDS.TeamDeleteHero then -- 队伍里删除英雄
        sendBinary:setLong(sendData[2])
  elseif messageId==SENDMESSAGEIDS.TeamAddThings then --队伍添加功能物品
        sendBinary:setChar(sendData[2])
        sendBinary:setChar(1)
        sendBinary:setInt(sendData[3])
        sendBinary:setChar(sendData[4])
        sendBinary:setChar(sendData[5])
  elseif messageId==SENDMESSAGEIDS.TeamDeleteThings then--队伍删除功能物品
        sendBinary:setChar(sendData[2])
        sendBinary:setChar(sendData[3])
        sendBinary:setChar(sendData[4])
  elseif messageId==SENDMESSAGEIDS.TeamreSet then--队伍位置重置，自动布阵
        sendBinary:setChar(sendData[2])
        sendBinary:setChar(#sendData[3])
        for i=1,#sendData[3] do
            sendBinary:setChar(sendData[3][i].type)
            if sendData[3][i].type==1 then
              sendBinary:setLong(sendData[3][i].id)
            elseif sendData[3][i].type==2 then
              sendBinary:setInt(sendData[3][i].id)
            end
            sendBinary:setChar(sendData[3][i].row)
            sendBinary:setChar(sendData[3][i].column)
        end
  elseif messageId == SENDMESSAGEIDS.BatlleSceneModel then -- 战场中镜头变化
        -- print("发送尽头变化")
        sendBinary:setChar(sendData[2])
        sendBinary:setInt(sendData[3])
  elseif messageId == SENDMESSAGEIDS.PlayerGMData then -- 获取装备
        sendBinary:setString(sendData[2])
  elseif messageId == SENDMESSAGEIDS.PlayerIsDressedEquipData then -- 是否穿戴装备
        sendBinary:setChar(sendData[2])
        sendBinary:setLong(sendData[3])
        sendBinary:setLong(sendData[4])  
  elseif messageId == SENDMESSAGEIDS.RequestHeroEvaluateList then -- 请求英雄评价
        sendBinary:setInt(sendData[2])
        sendBinary:setShort(sendData[3])
  elseif messageId == SENDMESSAGEIDS.PraiseHeroEvaluate then -- 英雄点赞
        sendBinary:setLong(sendData[2])
        sendBinary:setInt(sendData[3])
  elseif messageId == SENDMESSAGEIDS.PublishEvaluate then -- 请求英雄评价
        sendBinary:setInt(sendData[2])
        sendBinary:setString(sendData[3])
  elseif messageId == SENDMESSAGEIDS.SkillUpLevel then -- 技能升级
        sendBinary:setLong(sendData[2])
        sendBinary:setInt(sendData[3])
  elseif messageId == SENDMESSAGEIDS.EquipStrengthLevel then -- 装备强化
        sendBinary:setLong(sendData[2])
        sendBinary:setLong(sendData[3])
  elseif messageId == SENDMESSAGEIDS.EquipSpliteData then -- 装备分解
        sendBinary:setChar(sendData[2])
        for index,data in pairs(sendData[3]) do
            sendBinary:setLong(data)
        end
  elseif messageId == SENDMESSAGEIDS.PostBattleResultData then -- PVE战斗开始/结算
        sendBinary:setInt(sendData[2])  -- 副本ID
        sendBinary:setInt(sendData[3])  -- 棋子ID
        sendBinary:setChar(sendData[4]) -- 战斗状态
  elseif messageId == SENDMESSAGEIDS.HeroGradeStar then -- 英雄升星
        sendBinary:setLong(sendData[2])
  elseif messageId == SENDMESSAGEIDS.RequestChapter then --请求章节数据

  elseif messageId == SENDMESSAGEIDS.ChapterMissionCompleted then-- 告诉服务器章节通关
        sendBinary:setInt(sendData[2])
  elseif messageId == SENDMESSAGEIDS.PlayerPropSale then -- 物品出售
        sendBinary:setChar(sendData[2])
        for index,data in pairs(sendData[3]) do
            sendBinary:setLong(data)
        end
  elseif messageId == SENDMESSAGEIDS.PropSingleSale then -- 单个物品出售
        sendBinary:setLong(sendData[2])
        sendBinary:setShort(sendData[3])
  elseif messageId == SENDMESSAGEIDS.PropCombine then -- 物品合成
        sendBinary:setInt(sendData[2])
        sendBinary:setInt(sendData[3])
  elseif messageId == SENDMESSAGEIDS.RequestDrawPrise then -- 请求抽奖信息

  elseif messageId == SENDMESSAGEIDS.StartDrawPrise   then -- 抽奖
        sendBinary:setChar(sendData[2])
  elseif messageId == SENDMESSAGEIDS.SetTeamLeaderData then -- 设置队长
        sendBinary:setLong(sendData[2])
  elseif messageId == SENDMESSAGEIDS.SaleMateral then -- 售卖材料
        sendBinary:setLong(sendData[2])
        sendBinary:setLong(sendData[3])
  end

  --发送数据给服务器端
 	sendmessage(sendBinary)
end


-- 提示框消失类型
cc.exports.ShowDialogType = {
     SR      = 0,     -- 自动消失
     TO      = 1,     -- 点击外部消失
     TB      = 2      -- 点击按钮消失
}

function cc.exports.qingchutabsuoyouyuansu(tab)
    while tab[1] do
        table.remove(tab,1)
    end
end

-- 抛物线运动动作
-- @time:抛物线运动时间
-- @startPoint: 抛物线起始位置
-- @endPoint:结束位置
-- @height: 抛物线高度
-- @angle: 抛物线角度
-- @bezierTime: bezier时间
function cc.exports.ParabolaTo(time, startPoint, endPoint, height, angle, bezierTime)
    local radian  = 3.1415926 / 180 * angle
    local q1x     = startPoint.x     + (endPoint.x   - startPoint.x)    / 4.0;
    local q1      = cc.p(q1x, height + startPoint.y  + math.cos(radian) * q1x);
    local q2x     = startPoint.x     + (endPoint.x   - startPoint.x)    / 2.0;
    local q2      = cc.p(q2x, height + startPoint.y  + math.cos(radian) * q2x);
    local cfg     = {}
    local bezier2 = {q1,q2,endPoint}
    local besizer = cc.BezierTo:create(time,bezier2)
    local eio     = cc.EaseInOut:create(besizer,bezierTime) 
    return eio 
end


-- 判断两个颜色值是否相等
cc.exports.isSameColor = function( ca, cb)
    if ca[1] == cb[1] and ca[2] == cb[2] and ca[3] == cb[3] then
       return true
    else
       return false
    end
end


-- 截屏
-- fileName:截图保存的图片名称  
-- @fileName     保存图片名称
-- @successcall
cc.exports.CAPScreen = function(fileName, successcall)
       local function afterCaptured(succeed, outputFile)
          successcall(succeed, outputFile)
       end
       cc.utils:captureScreen(afterCaptured, fileName)
end
 
-- 得到技能动作, 状态转换的播放序列
-- @role 当前播放动作战斗单位
function cc.exports.getActionsByAction(actions, role)
    local allactions = {}
    for actionIndex, action in pairs(actions) do
       if tonumber(action) then
           allactions[#allactions + 1] = action
        else
           local tactions1 = getStringArray(action,"_")
           local tactions2 = getStringArray(action,"#")
           if #tactions1 == 3 then
                  local fanimation  =  tonumber(tactions1[1])
                  local conditionid =  tactions1[2]
                  local canimation  =  tonumber(tactions1[3])
                  -- 对一个动作满足条件
                  if fanimation then
                     allactions[#allactions + 1] = fanimation
                     if canimation and conditionid then
                         allactions[#allactions + 1] = canimation
                     elseif not canimation and conditionid then
                         -- 对一个动作序列满足条件
                         local actionarray =  json.decode(fanimation) 
                         for k,taction in pairs(actionarray) do
                             allactions[#allactions + 1] = taction
                         end
                     end
                  elseif not fanimation then
                      local fanimationarray = json.decode(fanimation)
                      for findex, faction in pairs(fanimationarray) do
                          allactions[#allactions + 1] = faction 
                      end
               
                      if canimation and conditionid then
                         allactions[#allactions + 1] = canimation
                      elseif not canimation and conditionid then
                         -- 对一个动作序列满足条件
                          local actionarray =  json.decode(tactions1[1]) 
                          for k,taction in pairs(actionarray) do
                             allactions[#allactions + 1] = taction
                          end
                      end
                  end
           end

           if #tactions2 == 2 then
              -- 对一组随机的某个动作满足条件
              local actionarray =  json.decode(tactions2[1]) 
              local conditionid =  tactions2[2]
              if conditionid then
                 -- for k,taction in pairs(actionarray) do
                     allactions[#allactions + 1] = actionarray[1]
                 -- end
              end
           end
        end
     end
    return allactions
end

function filter_spec_chars(s)  
    local ss = {}  
    for k = 1, #s do  
        local c = string.byte(s,k)  
        if not c then break end  
        if (c>=48 and c<=57) or (c>= 65 and c<=90) or (c>=97 and c<=122) then  
            table.insert(ss, string.char(c))  
        elseif c>=228 and c<=233 then  
            local c1 = string.byte(s,k+1)  
            local c2 = string.byte(s,k+2)  
            if c1 and c2 then  
                local a1,a2,a3,a4 = 128,191,128,191  
                if c == 228 then a1 = 184  
                
                elseif c == 233 then 
                    a2,a4 = 190,c1 ~= 190 and 191 or 165  
                end  
                if c1>=a1 and c1<=a2 and c2>=a3 and c2<=a4 then  
                    k = k + 2  
                    table.insert(ss, string.char(c,c1,c2))  
                end  
            end 
        end  
    end  
    return table.concat(ss)  
end 


-- 将一个包含中文符号的字符串解析成相应格式的字符串
cc.exports.getStringByString = function( str )
     local strlen = string.utf8len(str)
     for i=1,strlen do
      
          local c = string.byte(str,i)  
             print(c,"getStringByString = ",i)
     end

end

-- 得到字符串的长度

-- 逐字显示一个字符串
-- @size      给定显示区域大小
-- @showtime  显示完字符串的时间
-- @str       给定的字符串
-- @startpos  开始的位置cc.p()
-- @width     每个字的宽
-- @height    每个字的高
-- @halign    水平方向上的间距
-- @valign    垂直方向上的间距
-- @twidth    总宽度
-- @fontmsg:  字体显示信息
cc.exports.showStringInView = function(size, showtime , str, startpos, width, height, halign, valign, twidth, tnode, fontmsg)
    
    -- 总字数
    local allcount   = string.utf8len(str)
    -- 累计宽度
    local totalwidht = 0
    -- 此时的位置 
    local st = 1
    -- 显示每一个字的时间
    local time = 0.05
 
    print(str, "显示一个的停留时间",allcount)
    local tpos = clone(startpos)
    local tstartpos  = startpos
    local strIndex = 1
    local rowindex = 0
    local wordindex = 1
    local node       = tnode or cc.Node:create()
    local allshowms  = getStringArray(str, " ")
    local startwidth = twidth
    local firstfind  = true
    
    -- 显示每个字的方法

    local function showEveryCall()
    
        local curByte = string.byte(str, strIndex)

        -- print(strIndex,"当前所占自己数 = ",curByte)
        local byteCount = 1;
        if not curByte then
           return
        end
        if curByte >0 and curByte<=127 then
           byteCount = 1
        elseif curByte>=192 and curByte<223 then
           byteCount = 2
        elseif curByte>=224 and curByte<=239 then
           byteCount = 3
        elseif curByte>239 and curByte<=247 then
           byteCount = 4
        end
        
        tstrIndex   = strIndex + byteCount - 1

        local tstr = string.sub(str, strIndex, tstrIndex)
        if firstfind then
           -- strIndex  = 0
        end
        strIndex = tstrIndex
        
        -- print(wordindex.." "..curByte.." "..strIndex.."  byteCountbyteCount "..byteCount)
        local pos  = cc.p(tstartpos.x, tstartpos.y)

        -- print(totalwidht, startwidth, tstr)
        if tstartpos.x - 10 >= startwidth then
           tstartpos.x = tpos.x
           tstartpos.y = tstartpos.y - height - valign
           rowindex    = 0
        end

          -- getTextLabel(tstr,31,cc.c4f(222,11,11,255),cc.size(width, height),cc.TEXT_ALIGNMENT_LEFT,nil,cc.p(0.5,0.5),node,tstartpos,32,false)
        local tfont = Font.getSTLabel(fontmsg.ftype,tstr, fontmsg.fontfile,fontmsg.fontsize,fontmsg.dimensions, fontmsg.ha, fontmsg.va, fontmsg.fontcolor, cc.p(0,0), node, pos, order, mb)
        local width       = tfont:getContentSize().width
        tstartpos.x= tstartpos.x + width
        -- print("width = ",width)
        rowindex  = rowindex + 1
        if firstfind then
           strIndex  = strIndex + 1
           -- firstfind = false
        end

        wordindex = wordindex + 1
    end

    local delay = cc.DelayTime:create(time)
    local calls = cc.CallFunc:create(showEveryCall)
    local seq   = cc.Sequence:create(calls,delay)
    
    -- 显示的回调
    local repeate    = cc.Repeat:create(seq,allcount)
    
    if not tnode then
       node:setAnchorPoint(cc.p(0,0))
       node:setContentSize(size)
    end

    node:runAction(repeate)

    return node
end 


-- 规定时间 通过回调方法 将一个点移动到某个固定的点
-- @movetime       -- 移动时间
-- @totallength    -- 位移前的总长度 
-- @movelength     -- 此次位移多少
-- @setcall        -- 位移回调函数
-- @maxcall        -- 移动完此次的回调
cc.exports.MoveAPointToPoint = function(movetime, totallength, movelength , setcall, maxcall)
     local movespeed = 0.01
     movetime = 0.1
     -- 速度多长时间调一次
     local speed     =  math.abs(math.abs(movelength) / (movetime / movespeed))
     local allength  = totallength
     --print("多长时间调用一次啦  = ",movetime,speed,totallength, movelength)
     
     local movenodeschedule = cc.Director:getInstance():getScheduler()
     local scheduleid       = nil
     local startlength      = 0
     local function movecall()
         if math.abs(startlength) > math.abs(movelength) or not BATTLEENUM.getCurrentBattleLayer() then
            if scheduleid then
               cc.Director:getInstance():getScheduler():unscheduleScriptEntry(scheduleid)
               movenodeschedule = nil
               if maxcall then
                  maxcall()
               end
            end
         else
             
             if movelength < 0 then
                startlength = -startlength
             end
             setcall(allength + startlength)
             -- print("设置的长度 = ",startlength)
             startlength = math.abs(startlength) + 40
             
         end 
     end
     scheduleid = movenodeschedule:scheduleScriptFunc(movecall, movespeed, false)

end


-- 返回时分秒  格式如:00:00:00  Tools.getTimestring(3600) = 01:00:00
cc.exports.getTimeString = function(ddtime) 
     if ddtime <= 0 then
        return "00:00:00" 
     else
        if ddtime < 3600 and ddtime >= 60 then
            return string.format("%02d:%02d:%02d",0,math.floor((ddtime/60)%60), ddtime%60)
        elseif ddtime >= 3600 then
            return string.format("%02d:%02d:%02d", math.floor(ddtime/(60*60)), math.floor((ddtime/60)%60), ddtime%60)
        elseif ddtime < 60 then
            return string.format("%02d:%02d:%02d",0,0,ddtime%60)
        end 
     end
     
end

-- 得到当前的时间和服务器的时间差
cc.exports.getTimecha = function(st)
  local servertime = nil
    if not servertime and st then
       servertime = st - os.time()
    end
    return servertime
end

-- 根据数据释放特效组合
cc.exports.releaseGroupEffectByData = function( effectdata )
    local inspireeffect    = RequireModel.GroupEffect.new(effectdata,nil,BATTLEENUM.GroupEffectType.useatk)
    if effectdata.anch then
       inspireeffect:setAnchorPoint(effectdata.anch)
    end
    inspireeffect:setPosition(effectdata.pos)
    effectdata.fnode:addChild(inspireeffect,effectdata.order)
    return inspireeffect
end

cc.exports.createLabel = function(name, obj, posx, posy, size)
    local label = cc.LabelTTF:create(name, "Arial", 16)
    -- label:setAnchorPoint(cc.p(0,0.5))
    if size then
       label:setFontSize(size)
    end
    label:setPosition(posx, posy)
    obj:addChild(label)
    return label
    -- return Font.getTextLabel(name, 16,nil,nil,1,nil,cc.p(0.5, 0.5),obj,cc.p(posx,posy),1,false)
end

-- 得到给定的一个数字范围内的所有随机点 直到随机完
cc.exports.getDotArrayByNumber = function(dotnumber)
    local finaldots = {}

    local function finddot( id )
         for i,tid in ipairs(finaldots) do
             if tid == id then
                return tid + 1
             end  
         end
         return false
    end
    local number = dotnumber
    local function getdots()
        local id = math.random(number)
        math.newrandomseed()
        if not finddot( id )  and #finaldots < number then
           finaldots[#finaldots + 1] =  id
           getdots()
        end
    end
    
    -- 随机产生随机数
    while(#finaldots < number) do
       getdots()
    end
    -- print("最后得到的点数据   = ",json.encode(finaldots))
    return finaldots
end

-- 获取不同属性对象的属性icon
cc.exports.getPropertyIcon = function(basetype)
    local imagename
    if basetype == 1 then
      imagename = "UI_hero/icon_attribute1.png"
    elseif basetype == 2 then
      imagename = "UI_hero/icon_attribute2.png"
    elseif basetype == 3 then
      imagename = "UI_hero/icon_attribute3.png"
    elseif basetype == 4 then
      imagename = "UI_hero/icon_attribute4.png"
    elseif basetype == 5 then
      imagename = "UI_hero/icon_attribute5.png"
    elseif basetype == 6 then
      imagename = "UI_hero/icon_attribute6.png"
    elseif basetype == 7 then
      imagename = "UI_hero/icon_attribute7.png"
    elseif basetype == 8 then
      imagename = "UI_hero/icon_attribute8.png"
    elseif basetype == 9 then
      imagename = "UI_hero/icon_attribute9.png"
    end
    return imagename
end


-- 游戏中的字体大小
cc.exports.GameFontSize = {
    f18 = 18, -- 普通字体
    f22 = 22, -- 特写字体
    f26 = 26, -- 标题字体
}



-- 获得一个裁剪图片
-- mask: 蒙版图片
-- icon: 需要显示的图片
-- iconscale: 需要显示的图片的大小
cc.exports.getClipNode = function(mask,icon, iconscale, maskscale)
    local sten= createSprite(mask)
    if maskscale then
       sten:setScale(maskscale)
    end
    local stensize = sten:getContentSize()
    local clip     = cc.ClippingNode:create()
    clip:setStencil(sten)
    clip:setAlphaThreshold(0)
    clip:setInverted(false)
    print("iconiconicon = ",iconwxw)
    local icon     = createSprite(icon)
    local iconsize = sten:getContentSize()
    local scalex   = stensize.width  / iconsize.width
    local scaley   = stensize.height / iconsize.height
    icon:setScale(iconscale)
    -- icon:setScaleY(scaley)

    icon:setName("clipicon")
    clip:addChild(icon)
    return clip
end

-- 创建文本标签
cc.exports.createTextLabel = function(textid,repleasepos,size,posx,posy,parent,anchorpoint)
    local textlabel = Font.getTextById(textid,repleasepos,size)
    if anchorpoint then
        textlabel:setAnchorPoint(anchorpoint)
    end
    textlabel:setPosition(posx,posy)
    parent:addChild(textlabel)
    return textlabel
end

-- cc.exports.print = function(msg)
--     -- print(msg)
-- end













