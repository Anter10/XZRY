-- 展示对话框的内容数据
local ShowRolesDialogLayer = class("ShowRolesDialogLayer", RequireModel.CommonLayerView)


-- 对话框的对话人物
local ShowDialogRole = class("ShowDialogRole",RequireModel.CommonNode)

local DialogRoleStatues = {
	  into = 1,  -- 加入
	  keep = 0,  -- 不变
	  out  = -1, -- 离开
}


-- 剧情对话的相关参数
RoleDialogEnum = {
    TwoPosX = {
       lrp   =  250,
       lra   =  350,
       lap   =  100,
    },

    ForuPosId = {
       first  =  1,
       second =  2,
       third  =  3,
       fourth =  4,
    }
}

function ShowDialogRole:ctor(data, parent)
	  self.super.ctor(self)
    self.data     = data
    
    self.tpx      = 0
    self.parent   = parent
    self.id       = data.id
   
    self.dir     = tonumber(data.dir)
    if self.dir  == RoleDialogEnum.ForuPosId.first or self.dir == RoleDialogEnum.ForuPosId.second then
       self.tpx     =  RoleDialogEnum.TwoPosX.lrp
       if self.dir == RoleDialogEnum.ForuPosId.second then
          self.tpx = -self.tpx
       end
    elseif self.dir  == RoleDialogEnum.ForuPosId.third or self.dir == RoleDialogEnum.ForuPosId.fourth then
       self.tpx     =  RoleDialogEnum.TwoPosX.lra
       if self.dir == RoleDialogEnum.ForuPosId.fourth then
          self.tpx = -self.tpx
       end
    end

   
    
  
    -- self.dir = 0

   
    
    local cg_spine = getSystemData():getBattleUnitDataById(data.id):getCGSpine()
    self.rolecgdir = getSystemData():getBattleUnitDataById(data.id):getRolecgdir()
    self.normalscale = getSystemData():getBattleUnitDataById(data.id):getCGDScale()
    self.tfpy      = getSystemData():getBattleUnitDataById(data.id):getTfpy()
    print(self.id,"Y当前方向上的偏移 = ",self.tfpy)
    self.smallscale = self.normalscale * 0.9
    self.bigscale   = self.normalscale
    self.cgspine = sp.SkeletonAnimation:create(cg_spine..".skel",cg_spine..".atlas",self.normalscale)
    print(self.bigscale, "dddddd2 = ",json.encode(data))
    self.cgspine:setAnimation(0,"a3",true)
    self.size    = cc.size(300,winsize.height)
    self:setContentSize(self.size)
    

    if tostring(self.id) == tostring(self.parent.firstid) then
       if -self.tpx <= 0 then
          self.tpx  = -RoleDialogEnum.TwoPosX.lrp
       else
          self.tpx  = RoleDialogEnum.TwoPosX.lrp
       end
       -- self:becomeBig()
       self:becomeCurDia()
    else
       -- self:becomeSmall()
       self:becomeNoCurDia()
    end

    -- local layer = cc.LayerColor:create(cc.c4f(222,122,33,255))
    -- layer:setContentSize(self.size)
    -- self:addChild(layer,-1)

    self:addChild(self.cgspine, 10)
    
    self:setAnchorPoint(cc.p(0, 0))
    self.pianyi  = 0
    -- self.padding = 0
    if self.dir == 2 or self.dir == 4 then
       self.padding   = winsize.width + self.pianyi
       self:setAnchorPoint(-0.5,0)
    elseif self.dir == 1 or self.dir == 3 then
       self.padding   = -self.pianyi
       self:setAnchorPoint(0,0)
    end
    self.pyxy = getSystemData():getBattleUnitDataById(data.id):getRolecgpyy()
    print("self.paddingself.padding = ",self.dir, type(self.dir))
    self:setDir(self.dir)
    -- 角色CG 在剧情中的x, y  方向上的偏移
    self.cgpy  = self.pyxy.y
    self.cgpx  = self.pyxy.x
    self:setPosition(cc.p(self.padding + self.cgpx, self.cgpy))
    -- self:setOrgY(self.pyxy.y)
end

-- 把当前人物设置成当前说话的角色
function ShowDialogRole:becomeCurDia()
    self.iscurdia = true
end

-- 变成不是当前的角色
function ShowDialogRole:becomeNoCurDia()
    self.iscurdia = false
end

-- 得到当前是否为当前说话的角色
function ShowDialogRole:isCurDiaRole()
   return self.iscurdia
end

-- 角色变大
function ShowDialogRole:becomeBig()
   -- self.cgspine:stopAllActions()
   local tscale = self:getBScale(true)
   print("当前的tscaletscale",tscale)
   --  local room = cc.ScaleTo:create(0.2,tscale)
   -- self.cgspine:runAction(room)
   -- self.cgspine:setScale(tscale)
   self:becomeWhite()
   self:setDir(self.dir)
   
end

-- 角色变小
function ShowDialogRole:becomeSmall()
   -- self.cgspine:stopAllActions()
   local tscale = self:getBScale()
   -- local bigscale = cc.ScaleTo:create(0.2, tscale)
   -- self.cgspine:runAction(bigscale)
   self:becomeBlack()
   -- self.cgspine:setScale(tscale)
   self:setDir(self.dir)
end


function ShowDialogRole:getBScale( big )
       local scale = math.abs(self.normalscale)
       if big then
          print(self.normalscale,"变大尺寸=  ",self.bigscale)
          scale = math.abs(self.bigscale)
       end

       return scale
end



function ShowDialogRole:becomeWhite()
   self.cgspine:setaddcolor(40,40,40,0)
end

function ShowDialogRole:becomeBlack()
   self.cgspine:setaddcolor(-160,-160,-160,0)
end

function ShowDialogRole:becomeCenterBlack()
   self.cgspine:setaddcolor(-80,-80,-80,0)
end

-- 得到角色的ID
function ShowDialogRole:getId()
	return self.id
end

-- 设置原本的Y坐标
function ShowDialogRole:setOrgY(orgy)
	self.orgy = orgy
end

function ShowDialogRole:getOrgy()
	 return self.orgy
end

-- 设置原本的Y坐标
function ShowDialogRole:setOrgx(orgy)
   self.orgx = orgy
end

function ShowDialogRole:getOrgx()
   return self.orgx
end


-- 得到人物方向
function ShowDialogRole:getDir()
	return self.dir
end

-- 形象进入的时候
function ShowDialogRole:into(addx)
  	local moveby = nil
  	-- printError(self.id.."self.diddr"..self.dir)
    local movety = math.abs(self.tpx)
  	if self.dir == 2 or self.dir == 4 then
       movety = -math.abs(self.tpx)
    end
    print(movety,"进入的ID =  ",self.id)
    self.moviax = self:getPositionX() + movety
    local addtx = addx or 0
    moveby = cc.MoveBy:create(0.5, cc.p(movety + addtx, 0))
    -- self.cgspine:setPosition(cc.p(0,22))
  	self:runAction(moveby)
end

-- 形象出去的时候
function ShowDialogRole:Out()
        	local moveby = nil
        	self.dir = tonumber(self.dir)
        	print(self.id,self.dir," = 离开时的数据 = ",self.dir)
          local movebyx = math.abs(self.tpx)
        	if self.dir == 1 or self.dir == 3  then
             moveby = -math.abs(self.tpx)
        	end
          moveby = cc.MoveBy:create(1, cc.p(moveby , 0))
          self.movoax = self:getPositionX() + movety
        	self:runAction(moveby)
end



-- 设置CG的方向
function ShowDialogRole:setDir(dir)
	     self.dir = dir
        -- 得到当前角色的默认CG方向
       if self.dir == 1 or self.dir == 3 then 
           print(self.rolecgdir,"得到当前角色的默认CG方向得到当前角色的默认CG方向 = ",self.dir , self.id)
           if self.rolecgdir == 1 then
              self.cgspine:setScaleX(-self:getScaleX())
           end
        elseif self.dir == 2 or self.dir == 4 then
           if self.rolecgdir == 0 then
              self.cgspine:setScaleX(-self:getScaleX())
           end
        end
end

-- 交换CG的位置
function ShowRolesDialogLayer:changeDiaRolePos( r1, r2 )
    local r1dir = r1:getDir()
    local r2dir = r2:getDir()
    r1.dir = r2dir
    r2.dir = r1dir
    
    -- local pos1x,pos1y = r1:getPosition()
    -- local pos2x,pos2y = r2:getPosition()
    -- r1:setPosition(cc.p(pos2x,pos2y))
    -- r2:setPosition(cc.p(pos1x,pos1y))
end

-- 展示剧情对话内容的层
-- @dialogid: 剧情ID 
-- @uiid:     所在界面的ID
function ShowRolesDialogLayer:ctor(dialogid, uiid)
	  self.super.ctor(self)
	  print("dialogid = ",dialogid)
   	-- 
	  self:OpenTouch() 
	  -- 得到当前的对话数据
    self.dialog      = getSystemData():getRolesDialogById(dialogid)
    self.firstid     = self.dialog:getFDiaId()
    self.firstdir    = self.dialog
    print( "当前对话的所有内容 = ",json.encode(self.dialog:getDialogByIndex( 1 )))
    -- 当前对话内容的总条数
    self.totalNumber = self.dialog:getDialogNumber()
    -- 开始的对话下标 默认显示第一句
    self.dialogIndex = 1
    self.padding     = 60
    -- 展示对话的层
    self.showsize = cc.size(winsize.width, 220)
    self.showDialogLayer = cc.Sprite:create("ui_duihua_di.png")--cc.LayerColor:create(cc.c4f(233,122,255,255))
    -- self.showDialogLayer:setContentSize(self.showsize)
    self.showsize  =  self.showDialogLayer:getContentSize()
    self.showDialogLayer:setPosition(568,129)
    self:addChild(self.showDialogLayer,11)
    -- 展示角色层
    self.showRoleLayer = cc.LayerColor:create(cc.c4f(0,0,0,150))
    self.showRoleLayer:setContentSize(cc.size(winsize.width, winsize.height))
    self:addChild(self.showRoleLayer,-1)
    self.showRoleLayer:setPosition(cc.p(0, 0))
    -- 对话记录层
 
    -- self.dialogViews:setAnchorPoint(cc.p(0.5,0.5))
    -- self.dialogViews:setPosition(cc.p(0, 0))

    -- 对话记录的数据
    self.haddialogs = {}
    -- 初始化入场人物
    self:initRolePoss()
    -- 显示当前对话
    self:showNextDialog()
    local delay = cc.DelayTime:create(0.6)
    local function call()
       self:changeDialogRole( )
    end
    local callf = cc.CallFunc:create(call)
    local seq = cc.Sequence:create(delay, callf)
    self:runAction(seq)
    -- 初始化按钮
    self:initButtons()
    -- 对话包含的事件表
    self.curevents       = {}
    -- 当前的对话产生的事件数
    self.cureventcount   = 0
    -- 事件处理完成后的回调方法
    self.eventfinishcall = function() end
end

-- 刷新初始位置的坐标
function ShowRolesDialogLayer:initAllRolePos()
   
end

-- 触摸结束
function ShowRolesDialogLayer:onTouchEnded(touch, event)
    print("当前的剩余事件数 = ",#self.curevents)
    if self.curevents and #self.curevents >= 0 then
       self:showNextDialog()
       if self.changeDialogRole then
          self:changeDialogRole()
       end
       print("open 投产纯纯粹粹")
    end
end


-- 设置事件处理完成后的回调方法
function ShowRolesDialogLayer:setEventFinishCall( efc )
    self.eventfinishcall = efc
end

--  事件方法
--  @eventfunction: 添加的事件  最先添加的事件最先处理
function ShowRolesDialogLayer:addEvent( eventfunction )
    self.curevents[#self.curevents + 1] = eventfunction
end

-- 调用事件对应的方法
function ShowRolesDialogLayer:callEvent()
      if self.cureventcount and self.cureventcount > 0 then
         self.curevents[1]()
         self:removeEvent( )
         self.cureventcount = self.cureventcount - 1
         if self.cureventcount <= 0 and self.eventfinishcall then
            self.nextshowdata.hasfinish = true
            self.cureventcount = 0
         end
     else
         print("此次事件没有事件对应的  方法产生")
     end
end

-- 在此基础上面添加事件次数
function ShowRolesDialogLayer:addEvnum(addnum)
     self.cureventcount = self.cureventcount + addnum
end


-- 默认移除第一个事件
function ShowRolesDialogLayer:removeEvent( )
    if #self.curevents > 0 then
       table.remove(self.curevents, 1)
    end
end

-- 清空当前对话的所有事件
function ShowRolesDialogLayer:clearEvent()
    self.events = {}
end

-- 添加 自动 跳过按钮
function ShowRolesDialogLayer:initButtons()

	  self.autoButton =  RequireModel.Button.new("ui_anniu_auto.png","ui_anniu_auto.png", "ui_anniu_auto.png")
    self.showDialogLayer:addChild(self.autoButton, 220)
    self.autoButton:setPosition(cc.p(1068, 137.5))
    self.autoButton:setCallback(function()
    	 self:Auto()
    end)
    self.autoButtonSprite = cc.Sprite:create("ui_anniu_auto.png")
    self.autoButton:addChild(self.autoButtonSprite,3)
    local addsize = self.autoButton:getContentSize()
    self.autoButtonSprite:setPosition(addsize.width / 2, addsize.height / 2 + 5)

    self.jumpButton =  RequireModel.Button.new("ui_anniu_skip.png","ui_anniu_skip.png", "ui_anniu_skip.png")
    self.showDialogLayer:addChild(self.jumpButton, 220)
    self.jumpButton:setPosition(cc.p(1068 , 194.5))
    self.jumpButton:setCallback(function()
    	self:DialogEndRemove()
    end)

    self.nextButton =  RequireModel.Button.new("ui_duihua_anniu_next.png","ui_duihua_anniu_next.png", "ui_duihua_anniu_next.png")
    self.showDialogLayer:addChild(self.nextButton, 220)
    self.nextButton:setPosition(cc.p(1004.5, 43))
    self.nextButton:setCallback(
    function()
         self:showNextDialog()
         if self.changeDialogRole then
            self:changeDialogRole()
         end
    end)

    self.dialogsButton =  RequireModel.Button.new("ui_dialogue_all_button.png","ui_dialogue_all_button.png", "ui_dialogue_all_button.png")
    self:addChild(self.dialogsButton, 320)
    self.dialogsButton:setPosition(cc.p(winsize.width - 120, winsize.height - 80))
    self.dialogsButton:setCallback(function()
    	  self:showHadDialogs()
    end)
end

-- 有没有创建过当前的CG
function ShowRolesDialogLayer:cgHasRoleIt( id )
	for roleIndex,role in ipairs(self.allcg) do
		  if role:getId() == tonumber(id) then
         return role
		  end
	end
end

-- 判断给定的两个id是否在同一个方向
function ShowRolesDialogLayer:isSameDir( role1, role2 )
    local m1, m2  = math.modf(role1:getDir()/2)
    local m3, m4  = math.modf(role2:getDir()/2)
    if m2 == m4 then
       return true
    else
       return false
    end
end

-- 将两边非当前对话的形象上移 并且将其Zorder设置比当前对话的层级小
-- @trole: 最新出现的人
function ShowRolesDialogLayer:updatePos(trole)
    print(trole:getPositionX(),trole.id, "当前更新位置  = ",#self.allcg)
    -- trole:setPositionX(250)
	  for roleIndex,role in ipairs(self.allcg) do
        local tsmdir = self:isSameDir( trole, role )
        local tsmid  = tonumber(role:getId()) == tonumber(trole:getId())
        if not tsmid then
           role:becomeNoCurDia()
        end
        if tsmdir and not tsmid then
           local zorder  = trole:getLocalZOrder() 
           -- self:changeDiaRolePos( trole, role )
           role:setLocalZOrder(zorder-1)
           role:becomeSmall()
           if not role:getOrgy() then
              role:setOrgY(role:getPositionY())
           end
           if not role:getOrgx() then
              local txx = role:getPositionX()
              role:setOrgx(role:getPositionX())
              local tx    = 0
              if role.dir == 1 or role.dir == 3 then
                 tx =  RoleDialogEnum.TwoPosX.lap
              elseif role.dir == 2 or role.dir == 4 then
                 tx = -RoleDialogEnum.TwoPosX.lap
              end
              -- if txx < role.moviax then
              --    txx = role.moviax
              -- end
              print(role.hasadd, role.id,role.dir, "当前的新坐标 ", txx + tx)
              
              if not role.hasadd then
                 role:setPositionX(txx + tx)
                 role:setPositionY(role:getPositionY() + role.tfpy)
              end
              role.hasadd = true
           end
        elseif tsmid then
           role:becomeBig()   
           if role:getOrgy() then
              role:setPositionY(role:getOrgy())
              role:setOrgY(nil)
           end
           role.hasadd = false
           
           if role:getOrgx() then
              tx = 0
              if role.dir == 3 or role.dir == 1 then
                 tx = -RoleDialogEnum.TwoPosX.lap
              elseif role.dir == 4 or role.dir == 2 then
                 tx =  RoleDialogEnum.TwoPosX.lap
              end
              print(role.dir, "当前更新的ID = ",role.id, role:getOrgx())
              role:setPositionX(role:getPositionX() + tx)
              role:setOrgx(nil)
           end
        elseif not tsmdir and not tsmid then
           if role.dir == 1 or role.dir == 2 then
              role:becomeCenterBlack()
           end
	   	  end
	   end
end

-- 显示下下一条数据的界面变化
function ShowRolesDialogLayer:changeDialogRole( )
	   local statue = self.nextshowdata.statue
     
     print("下一条的状态 = ",statue,json.encode(DialogRoleStatues))
	   -- 判断有没有创建过当前的人物
     if statue == DialogRoleStatues.keep then
        local role = self:cgHasRoleIt( self.nextshowdata.id )
        if role then
           self:updatePos(role)
        end
	   elseif statue == DialogRoleStatues.into then
        local role = self:cgHasRoleIt( self.nextshowdata.id )
        if role then
           self:updatePos(role)
        else
        	 local cgrole = ShowDialogRole.new(self.nextshowdata, self)
           self.allcg[#self.allcg + 1] = cgrole
	         self.showRoleLayer:addChild(cgrole,1000 - cgrole.dir * 10)
           local movetx = 0
           if cgrole.dir == 3 then
              movetx = -RoleDialogEnum.TwoPosX.lap
           elseif cgrole.dir == 4 then
              movetx =  RoleDialogEnum.TwoPosX.lap
           end
	         cgrole:into(movetx)
           self:updatePos(cgrole)
        end
	   elseif statue == DialogRoleStatues.out then
	 	    local cgrole = self:cgHasRoleIt( self.nextshowdata.id )
        if cgrole then
	         local function out()
	        	  cgrole:Out()
	         end
	         local callOut = cc.CallFunc:create(out)
	         local delay   = cc.DelayTime:create(2)
	         local seq     = cc.Sequence:create(delay, callOut)
	         cgrole:runAction(seq)
	      end
	   end
end
 
-- 初始话第一句话
function ShowRolesDialogLayer:showDialog(data)
	  local tdata = self:initShowDialog(data)
    if self.shownode then
       self.shownode:stopAllActions()
       self.shownode:removeFromParent(true)
       self.shownode = nil
    end
    data.id = tdata.roleid
    self.nextshowdata = data
    
      
  	local tsr     = tdata.dialog
  	
    local twidth,theight  = 30, 33

    if GMMESSAGE.language  == ALlLanguageType.en then
       twidth  = 24
       theight = 40
    end
    self.shownode = showStringInView(self.showsize, 2 , tsr, cc.p(self.padding, self.showsize.height - 80), twidth, theight , 10, 10, winsize.width - 240, nil,tdata.fontmsg)
    self.showDialogLayer:addChild(self.shownode, 120)
end


-- 显示聊天记录
function ShowRolesDialogLayer:showHadDialogs()
       if not self.dialogListView then
           self.haddialogsize = cc.size(380, 560)
            local touchlayer = class("DialogLayers",RequireModel.CommonFullSceneUI)
            self.dialogViews = touchlayer.new()
            self.dialogViews.touchCloseCallback = function()
                  if self.dialogListView then
                      self.dialogListView:removeFromParent(true)
                      self.dialogListView = nil
                      self.dialogViews:removeFromParent(true)
                      self.dialogViews = nil
                  end
            end
            self.dialogViews:setTouchRect(cc.rect(winsize.width / 4, 190, 380, 560))
            -- self.dialogViews:setContentSize(self.haddialogsize)
            self.dialogViews:setTouchClose(true)
            self:addChild(self.dialogViews,15)
            
            self.dialogViews:becomeBlackBackground()
 
    	     self.dialogViews:setVisible(true)
    	     local dialogs             = {}
    	     local listviewdata        = {}
           listviewdata.dir          = 2
           self.editNodeData = {}
           ccb["editbutton"]         = self.editNodeData
           local proxy               = cc.CCBProxy:create()
           self.editNode             = CCBReaderLoad("com_ui_dialoge_view.ccbi",proxy,self.editNodeData)
           
           listviewdata.size         = cc.size(self.editNodeData["bottom"]:getContentSize().width,self.editNodeData["bottom"]:getContentSize().height - 60)
           listviewdata.MagneticType = 2
           local tmodels   = {}
           for dialogIndex,dialog in ipairs(self.haddialogs) do
               local hight = ((string.utf8len(dialog.dialog) * 33) / (listviewdata.size.width - 40)) * 40
    		       if hight < 50 then
                  hight = 50
               end
               local node  = Font.getSTLabel(dialog.fontmsg.ftype,dialog.dialog, dialog.fontmsg.fontfile,dialog.fontmsg.fontsize,cc.size(listviewdata.size.width - 40, hight), dialog.fontmsg.ha, dialog.fontmsg.va, dialog.fontmsg.fontcolor, nil, nil, nil, nil, nil)
               -- Font.getTextLabel(dialog.dialog,31,cc.c4f(222,11,11,255),cc.size(listviewdata.size.width - 40, hight + 40),cc.TEXT_ALIGNMENT_LEFT,nil,cc.p(0.5,0.5),nil,cc.p(20, 0),32,false)
              
               node:setContentSize(cc.size(listviewdata.size.width,hight))
               node:setAnchorPoint(cc.p(0,0))
               node:setPositionX(20)
               tmodels[#tmodels + 1] = node
    	     end

           listviewdata.models  = tmodels
           listviewdata.bounce  = true
           
           -- self.editNode:setVisible(false)
           self.dialogViews:addChild(self.editNode,120)
           self.editNode:setPosition(cc.p(winsize.width / 2,winsize.height/2))

           if not self.dialogListView then
    	        self.dialogListView = RequireModel.ListviewNode.new(listviewdata)
              self.dialogListView:setAnchorPoint(cc.p(0.5,0.5))
              self.editNodeData["node"]:getParent():addChild(self.dialogListView, -1)
              local tposx, tposy = self.editNodeData["node"]:getPositionX(), self.editNodeData["node"]:getPositionY()
              self.dialogListView:setPosition(cc.p(tposx, tposy))
           else
           	  self.dialogListView:restartView(listviewdata)
           end
           -- -- 给当前的剧情添加事件
           -- local function hideDiaView()
           --    self.dialogListView:removeFromParent(true)
           --    self.dialogListView = nil
           --    self.dialogViews:setVisible(false)
           -- end
           -- self.nextshowdata.hasfinish = true
           -- self:addEvent(hideDiaView)
           -- self:addEvnum(1)
           self:exitAutoStatue()
        end
end


-- 添加自动模式下播放的特效
function ShowRolesDialogLayer:addFrameAnimation()
        local rf = createAnimate("tx_button_auto_", 20)
        self.autoButtonSprite:runAction(rf)
end

-- 停止动画
function ShowRolesDialogLayer:exitAutoStatue()
     self.autoButtonSprite:stopAllActions()
     self:stopAllActions()
     self.autoButtonSprite:setVisible(false)
     self.isautostatue = false
end

-- 自动模式下
function ShowRolesDialogLayer:Auto()
     if not self.isautostatue then
        self.isautostatue = true
     else
        self:exitAutoStatue()
        return
     end
     self.autoButtonSprite:setVisible(true) 
     if self.nextshowdata and not self.nextshowdata.hasfinish then
        self.cureventcount = self.nextshowdata.evn
     else
        self.cureventcount = 0
     end
     self:addFrameAnimation()
     print("点击自动 上次对话剩下的事件次数 ", self.cureventcount,"当前是第几条对话类容   = ",self.dialogIndex, json.encode(self.nextshowdata))
     if self.cureventcount > 0 then
        self:callEvent()
     else
      	local function autoCall()
             self:showNextDialog()
             self:changeDialogRole( )
      	end

        local delay = cc.DelayTime:create(2)

        local calls = cc.CallFunc:create(autoCall)

        local seq   = cc.Sequence:create(calls,delay)

        local repeateCount = self.totalNumber - self.dialogIndex + 2
        -- 显示的回调
        local repeate    = cc.Repeat:create(seq,repeateCount)
        
        self:stopAllActions()
    	  self:runAction(repeate)
     end
    
end


-- 初始化开始的时候对话的英雄
function ShowRolesDialogLayer:initRolePoss()
	  -- 首先把当前战斗中的所欲CG 都加载进来
	  self.allcg = {} 
    local rolesdata   = self.dialog:getInitRoles()
    print("初始位置信息 = ",json.encode(rolesdata))
	  self.initroledata = {}
   
    for dataIndex,data in ipairs(rolesdata) do
    	  local tdata = {}
    	  tdata.id  = self.dialog:getRoleIdByIndex( data.index )
        tdata.dir = data.dir
        self.initroledata[#self.initroledata + 1] = tdata
    end

    print("self.initroledata ",json.encode(self.initroledata))

    for dataIndex, data in ipairs(self.initroledata) do
    	  local cgrole = ShowDialogRole.new(data, self)
        self.allcg[#self.allcg + 1] = cgrole
        self.showRoleLayer:addChild(cgrole,1000 - cgrole.dir * 10)
        if cgrole.dir == 3 or cgrole.dir == 4 then
           cgrole:becomeSmall()
           cgrole.hasadd = true
        end
        cgrole:into()
    end


    return self.initroledata
end

-- 设置人物的位置
function ShowRolesDialogLayer:setRoleAndPos(roleid , dir, index )
	
end


-- 展示对话数据
-- @dialogdata: 对话数据
function ShowRolesDialogLayer:initShowDialog(dialogdata)
	  -- 角色配置ID
	  local roleid   = self.dialog:getRoleIdByIndex( dialogdata.index )
    -- 对话ID
    local dilogid  = dialogdata.logid
    print("当前对话的ID = ",dilogid)
     -- 角色名称
    local rolename = "旁白"
    if roleid      == 0 then
       rolename  = "旁白"
    else
       local roleunit = getSystemData():getBattleUnitDataById(roleid)
       rolename = Font.getTextById(roleunit:getName(), nil, nil, true) 
    end
	  
	  -- 对话内容
  
    local dialog   = nil
    local findit     = string.find(dilogid, "L")
    print(findit, "当前文本ID = ", dilogid)
    if findit then
       dialog = getSystemData():getSystemShowWorldData(dilogid)
    elseif not findit then
       dialog = getSystemData():getDialogData(dilogid)
    end

    local text       = dialog:getWords()
 
    -- 解析当前对话类容的字体信息
   
    -- 得到当前的显示格式
    local showtype    = dialog:getShowType()
    -- 得到表头信息
    local headmessage = getStringArray(showtype,"#F#")
    -- 得到对齐方式
    local aligns      = getStringArray(headmessage[1],"#")[3]
    -- 水平方向上的对齐
    local ha          = string.sub(aligns,1,1)
    -- 垂直方向上的对齐
    local va          = string.sub(aligns,2,2)
    -- 得到文本头使用的字体
    local headmsg     = getStringArray(headmessage[2],"##")
    -- 得到具体显示的字体
    local fontid      = headmsg[1]
    -- 得到文本显示的字体信息 
    local fontdata    = getSystemData():getSystemTextFontDataById(fontid)
    -- 得到文本显示的字体 字号颜色
    -- 字号
    local fontsize  = fontdata:getFontSize()
    -- 字体颜色ID
    local colorid   = fontdata:getFontColor()
    -- 得到字体颜色
    local fontcolor = getSystemData():getSystemColorById(colorid):getColor()
    -- 字号ID
    local fontid    = fontdata:getFontId()
    -- 得到字库数据
    local fontd      = getSystemData():getSystemFontDataById(fontid)
    local ftype      = fontd:getType()
    local fontfile   = fontd:getLanFontFile()    
    
   
    
    print("")
    local tdata    = {}
    tdata.dialog   = rolename..":"..text
    tdata.roleid   = roleid  
    tdata.fontmsg  = {}
    tdata.fontmsg.fontfile  = fontfile
    tdata.fontmsg.fontsize  = fontsize
    tdata.fontmsg.fontcolor = fontcolor 
    tdata.fontmsg.ha        = ha 
    tdata.fontmsg.va        = va 
    tdata.fontmsg.ftype     = ftype
    self.haddialogs[#self.haddialogs + 1] = clone(tdata)
    -- printError(rolename.."当前的显示格式信息  = "..json.encode(tdata))
    return tdata
end


-- 得到上一条对话内容
function ShowRolesDialogLayer:getUpDialog()
  	self.dialogIndex = self.dialogIndex - 1
  	if self.dialogIndex > 0 then
  	   local dialogdata = self.dialog:getDialogByIndex( self.dialogIndex )
  	   self:showDialog(dialogdata)
  	else
   
    end
end

-- 得到下一条数据内容
function ShowRolesDialogLayer:showNextDialog()
    print("剩余的事件数1  = ", self.cureventcount, json.encode(self.nextshowdata)) 
    
    if self.nextshowdata  and not self.nextshowdata.hasfinish then
       self.cureventcount = self.nextshowdata.evn
       self.nextshowdata.hasfinish = true
    elseif not self.cureventcount or self.cureventcount <= 0 then
       self.cureventcount = 0
    end
    
    print("剩余的事件数2  = ", self.cureventcount)
    if self.cureventcount > 0 then
       self:callEvent()
    else
        if self.dialogIndex > 0 and self.dialogIndex <= self.totalNumber then
           local dialogdata = self.dialog:getDialogByIndex( self.dialogIndex )
           self.dialogIndex = self.dialogIndex + 1
           self:showDialog(dialogdata)
        else
           self:DialogEndRemove()
        end
    end
end



-- 对话结束删除
function ShowRolesDialogLayer:DialogEndRemove()
    if self.nextshowdata  and not self.nextshowdata.hasfinish then
       self.cureventcount = self.nextshowdata.evn
    else
       self.cureventcount = 0
    end
    
    print("点击跳过  上次对话剩下的事件次数 ", self.cureventcount,"当前是第几条对话类容   = ",self.dialogIndex, json.encode(self.nextshowdata))
    if self.cureventcount > 0 then
       self:callEvent()
    else
        local remove = self:isRemoveSelf()
        print("removeremove ",remove)
        if self.removecall then
           self:removecall() 
        end
        if remove then 
           self:removeSelf()
        end
    end
end


-- 设置删除后的回调函数
function ShowRolesDialogLayer:setRemoveCall( removecall )
	   self.removecall = removecall
end

-- 展示对话框
-- @dialogid: 剧情ID 
-- @uiid:     所在界面的ID
-- @removecallback: 移除的时候的回调
-- @parentnode    : 手动添加父节点
function ShowRolesDialogLayer.Show(dialogid, uiid,removecallback,parentnode)
      print("当前剧情对话的ID = ",dialogid, uiid,removecallback,parentnode)
    	local dialogView = ShowRolesDialogLayer.new(dialogid, uiid)
      dialogView:setRemoveCall(function()
         print("对话完成回调函数")
         if removecallback then
            removecallback()
         end
         RequireModel.CommonLayerView.clearGrayNumber()
      end)
      parentnode = parentnode or UIJump:getRunNode() or getCurrentRunNode()
      parentnode:addChild(dialogView, 1200)

      return dialogView
end


return ShowRolesDialogLayer

