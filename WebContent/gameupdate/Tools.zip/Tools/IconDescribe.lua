local IconDescribe = class("IconDescribe",RequireModel.CommonLayerView)
function IconDescribe:ctor(data,icontype)
	self.super.ctor(self)
	self:OpenTouch()
	self.data = data
	self.icontype = icontype

	self:addCcb()
	self:addHead()
	self:setName()
	self:setDescribe()
end
--添加ccb
function IconDescribe:addCcb()
	self.ccbnode = nil 
	self.ccbtab = {}
	ccb["IconDescribe"]=self.ccbtab
    local roxy = cc.CCBProxy:create()
	self.ccbnode = CCBReaderLoad("com_ui_qp_wupinxinxi.ccbi",roxy,self.ccbtab)
	self.ccbnode:setPosition(winsize.width/2,winsize.height/2)
    self:addChild(self.ccbnode)

    self:initTypeId()
end
-- 获取icon类型id
function IconDescribe:initTypeId()
	self.id = self.data:getId()
	self.proptype = tonumber(string.sub(tostring(self.id),0,1))
end
--添加头像
function IconDescribe:addHead()
	local head = RequireModel.IconNode:create(self.data,self.icontype)
	head:setScale(0.7)
	head:setPosition(-head:getContentSize().width/2*head:getScale(),-head:getContentSize().height/2*head:getScale())
	self.ccbtab["headicon"]:addChild(head)
end
--设置名称
function IconDescribe:setName()
	local name = nil
	-- 1代表英雄数据 2：代表技能数据 3：代表 4：代表 5：代表道具数据 
	if self.proptype == 1 then
		name = getSystemData():getBattleUnitDataById(self.id):getL_name()
	elseif self.proptype == 2 then
		name = getSystemData():getSkillDataById(self.id):getL_name()
	elseif self.proptype == 5 or self.proptype == 6 then
		name = getSystemData():getpropDataById(self.id):getL_name()
	elseif self.proptype == 4 then
		name = getSystemData():getSkillDataById(self.id):getL_name()
	end

	print("self.id",self.id,"self.proptype",self.proptype,"name",name)
	
	local font = Font.getTextById(name,nil,nil,false)
	font:setPosition(self.ccbtab["namelabel"]:getPositionX(),self.ccbtab["namelabel"]:getPositionY())
	font:setAnchorPoint(self.ccbtab["namelabel"]:getAnchorPoint().x,self.ccbtab["namelabel"]:getAnchorPoint().y)
	self.ccbtab["namelabel"]:getParent():addChild(font)
	self.ccbtab["namelabel"]:getParent():removeChild(self.ccbtab["namelabel"])


	-- self.ccbtab["namelabel"]:setString(name)
end
--设置描述
function IconDescribe:setDescribe()
	local describe = nil
	-- 1代表英雄数据 2：代表技能数据 3：代表 4：代表 5：代表道具数据
	if self.proptype == 1 then
		describe = getSystemData():getBattleUnitDataById(self.id):getL_info()
	elseif self.proptype == 2 then
		describe = getSystemData():getSkillDataById(self.id):getL_info()
	elseif self.proptype == 5 or self.proptype == 6 then
		describe = getSystemData():getpropDataById(self.id):getL_info()
	elseif self.proptype == 4 then
		describe = getSystemData():getSkillDataById(self.id):getL_info()
	end
	print("self.id",self.id,"self.proptype",self.proptype,"describe",describe)

	local font = Font.getTextById(describe,nil,cc.size(300,0),false)
	font:setPosition(self.ccbtab["describelabel"]:getPositionX(),self.ccbtab["describelabel"]:getPositionY())
	font:setAnchorPoint(self.ccbtab["describelabel"]:getAnchorPoint().x,self.ccbtab["describelabel"]:getAnchorPoint().y)
	self.ccbtab["describelabel"]:getParent():addChild(font)
	self.ccbtab["describelabel"]:getParent():removeChild(self.ccbtab["describelabel"])

	-- self.ccbtab["describelabel"]:setString(describe)
end
-- 触摸开始
function IconDescribe:onTouchBegan(touch, event)
	return true
end
-- 触摸移动
function IconDescribe:onTouchMoved(touch, event)
	
end
-- 触摸结束
function IconDescribe:onTouchEnded(touch, event)
	self:removeFromParent(true)
end
return IconDescribe