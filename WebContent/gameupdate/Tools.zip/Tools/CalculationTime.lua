local CalculationTime = class("Calculation", RequireModel.CommonNode)

function CalculationTime:ctor(timenum)
	self.super.ctor(self)
	self.timenum = tonumber(timenum)
	self.starttime = true

	self.timeendCallback = nil --时间结束回调方法
	self.timelabel = Font.getTextLabel(getTimeString(self.timenum).." 免费", 24,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(0,0),1,false)
end

-- 开始计算  
function CalculationTime:startSchedule()
	local function updata(delta)
		self:flushTime()
	end
	self.m_updataID=cc.Director:getInstance():getScheduler():scheduleScriptFunc(updata,1,false)
end

-- 暂停计时器
function CalculationTime:pauseSchedule()
	self.starttime = false
end
-- 设置时间值
function CalculationTime:setTime(time)
	self.timenum = time
end
-- 开始计时
function CalculationTime:restartSchedule()
	self.starttime = true
end

-- 刷新时间
function CalculationTime:flushTime()
	if not self.starttime then
		return
	end
	if self.timenum > 0 then
		self.timenum = self.timenum - 1
		self.timelabel:setString(getTimeString(self.timenum).." 免费")
		local timenum = math.floor(self.timenum) 
	else
		if self.timeendCallback then
			self.timeendCallback()
		end
		self.timenum = 0
		self:closeSchedule()
	end
end

-- 获取当前时间
function CalculationTime:getCurrentTime()
	return self.timenum
end

-- 设置时间正在进行回调事件
function CalculationTime:setTimeingCallback(callback)
	self.timeingcallback = callback
end

-- 设置时间结束回调事件
function CalculationTime:setTimeEndCallback(callback)
	self.timeendCallback = callback
end

-- 关闭计数
function CalculationTime:closeSchedule()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.m_updataID)
end

function CalculationTime:onExit()
	self:closeSchedule()
end

return CalculationTime