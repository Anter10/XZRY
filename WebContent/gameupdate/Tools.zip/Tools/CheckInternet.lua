-- 游戏的网络检测包括IOS(Lua 调用用OC的类函数) 和 android(Lua 调用用java的类函数)



local CheckInternet = class("CheckInternet")
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

function CheckInternet:ctor()
    -- body
end

-- 检测Android是否有网络连接
-- @返回 true: 有网络连接  false:没有网络连接
function CheckInternet.isAndroidConnectInternet()
	return CheckInternet.callAndroidMethod("isInternetConnectionAvailable")
end


-- 检测IOS是否有网络连接
-- @返回 true: 有网络连接  false:没有网络连接
function CheckInternet.isIOSConnectInternet()
	return CheckInternet.callIOSMethod("reachabilityForInternetConnection")
end


-- 检查android环境是否连接WI-FI
-- @返回 true: 是WIFI  false:不是WIFI
CheckInternet.checkAndroidWifi = function()
 	return CheckInternet.callAndroidMethod("isLocalWiFiAvailable")
end


-- 检查android环境是否连接WI-FI
-- @返回 true: 是WIFI  false:不是WIFI
CheckInternet.checkIOSWifi = function()
    return CheckInternet.callIOSMethod("reachabilityForLocalWiFi") 
end


-- 调用安卓环境中的方法
function CheckInternet.callAndroidMethod(funName)
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        local args = { 2 , 3}
            local sigs = "(II)I"
            local luaj = require "cocos.cocos2d.luaj"
            local className = "org/cocos2dx/lua/PSNetwork"
            local ok,ret  = luaj.callStaticMethod(className, funName,args,sigs)
            if not ok then
                ---- print("luaj error:", ret)
            else
                ---- print("The ret is:", ret)
            end
        return ok
    else
        return false
    end
end

-- 调用ios环境下的方法
function CheckInternet.callIOSMethod(funcName)
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) or (cc.PLATFORM_OS_MAC == targetPlatform) then
            local args = {}
            local luaoc = require "cocos.cocos2d.luaoc"
            local className = "Reachability"
            local ok, ret = luaoc.callStaticMethod(className,funcName)
            if not ok then
               ---- print("luaj error:", ret)
            else
                ---- print("The ret is:", ret)
            end
        return ok
    else
        return false
    end
end


return CheckInternet






