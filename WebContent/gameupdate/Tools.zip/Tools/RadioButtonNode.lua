local RadioButtonNode = class("RadioButtonNode", RequireModel.CommonNode)
-- {dir == 2, num = 5, rect = cc.rect(0,215,47,35), callback = callbuttonback}
-- @dir：横着还是竖直方向 @num：RadioButton数量 @rect：RadioButton的位置和宽高，@callback：点击button回调方法
function RadioButtonNode:ctor(parma)
	self.super.ctor(self)
	self.data = parma

	self.num_of_button = self.data.num         -- button数量
	self.button_width  = self.data.rect.width  -- button宽度
	self.button_height = self.data.rect.height -- button高度
	self.startPosX     = self.data.rect.x      -- 开始buttonX坐标
	self.startPosY     = self.data.rect.y      -- 开始buttonY坐标
    self.labelnametab  = self.data.labelname   -- 标签名
    self.radioButtontab = {}                   -- RadioButton表

	
	self.selectedid    = 0 -- 选择的按钮id

	-- self:initButton()
end

-- 初始化RadioButton
-- @normalimage：正常图片名称 @selectedimage：选择图片名称 @isaddlabel：是否添加标签

function RadioButtonNode:initButton(normalimage,selectedimage, isaddlabel)
	self.radioButtonGroup = ccui.RadioButtonGroup:create()
    self.radioButtonGroup:addEventListener(function(radioButton, index, type)
        print("RadioButton" .. index .. "Clicked")
    end)

    self:addChild(self.radioButtonGroup)

    for i=1,self.num_of_button do
    	local radioButton = ccui.RadioButton:create(normalimage, selectedimage)
        local posY = self.startPosY - (10*i + self.button_height * (i+1))
        local posX = self.startPosX + (10*i + self.button_width * (i+1))
        if self.data.dir == 1 then
           radioButton:setPosition(cc.p(posX, 0))
        else
           radioButton:setPosition(cc.p(0, posY))
        end
        
        radioButton:setName(tostring(i))
        radioButton:addEventListener(function(RadioButton, eventtype)
            if eventtype == ccui.RadioButtonEventType.selected then
               self.selectedid = tonumber(RadioButton:getName())
               self.data.callback(self.selectedid)
               -- print("self.selectedid = ",self.selectedid)
            elseif eventtype == ccui.RadioButtonEventType.unselected then
               print("name: = " .. radioButton:getName() .. " unselected")
            end
        end)
        
        self.radioButtonGroup:addRadioButton(radioButton)
        self:addChild(radioButton)
        self.radioButtontab[#self.radioButtontab+1] = radioButton
        if self.labelnametab[i] ~= "" then
            radioButton:addChild(self:addButtonLabel(self.labelnametab[i]))
        end
        
    end

end

-- 特定指定下标的button
function RadioButtonNode:setButtonState(index)
    if self.radioButtontab[index] then
        self.radioButtonGroup:setSelectedButton(self.radioButtontab[index])
    end
end

function RadioButtonNode:addButtonLabel(labelname)
        local label = cc.LabelTTF:create(labelname, "Arial", 16)
        label:setPosition(self.button_width/2,self.button_height/2)
        return label   
end

return RadioButtonNode