-- 公共的场景用于管理某些通用的UI
local CommonSceneView = class("CommonSceneView",cc.load("mvc").ViewBase)
-- 界面的UIID
CommonSceneView.__uiid = "该场景还没有设置界面ID"

-- 界面类型
CommonSceneView.__type = 2

local CheckInternet   = nil
-- 创建场景
function CommonSceneView:onCreate()	
  	self:enableNodeEvents()
  	setCurrentRunNode(self)
    if not CheckInternet then
       CheckInternet = RequireModel.CheckInternet
  	end
    print("annnnn ")
end

function CommonSceneView:initMusic()
    print("当前播放的场景音乐 =  ",self.__cname)
   local uilayer = getSystemData():getGameViewsDataByClassName(self.__cname)
    if uilayer then
       local musics  =  nil
       -- 副本地图每个副本的音乐文件可能不一样
       if self.__cname == "TerritoryMapScene" then
          local data   = getPlayerData():getExploremapData()
          if data then
            local mapid   = data.id
            local mapdata = getSystemData():getMapChapterData(mapid)
            if mapdata then
               musics   = mapdata:getMapMusic()
            end
          end
       end
     
       if not musics or tonumber(musics) then
          musics = uilayer:getMusic()
       end
 
       self.musics = getStringArray(musics, ",")
       print(self.__cname,"当前场景的音乐 —————————————————————— ",json.encode(self.musics))
    end
end

function CommonSceneView:playMusic()
       print("场景播放盈余达到滴滴答答",self.musics, #self.musics)
       if self.musics and #self.musics > 0 and tonumber(self.musics[1]) ~= 0 then
          -- 判断时播放音乐 还是  播放效果
          local ismusic = false
          if #self.musics == 1 then
             ismusic = true
          end
          print("播放音乐嘛 - ",json.encode(self.musics))
          for audoIndex,audioid in ipairs(self.musics) do
               local data = getSystemData():getGameMusicById(audioid)
               if data then
                  print("aaaaaa",json.encode(self.musics))
                  local musiclfile = "UI_music/"..data:getFileName()
                  local loop       = data:getLoop()
                 RequireModel.GameMusic.playMusic(musiclfile, loop, ismusic)
               end
           end
       end
end
 
function CommonSceneView:stopEffect()
    if self.musics and #self.musics > 0 and RequireModel.GameMusic.musicName and tonumber(self.musics[1]) ~= 0 then
       print("2停止音乐1")
       RequireModel.GameMusic.stopAllEffects(function() self:playMusic() end)
    else
       print("2停止音乐1")
       self:playMusic()
    end
end

-- 得到界面的ID
function CommonSceneView:getUIID()
    return self.__uiid
end

function CommonSceneView:backToCall()
    print("返回的数据  = ",UIJump:getBackData())
end

-- 设置界面的ID
-- @uiid: 设置的界面ID
function CommonSceneView:setUIID( uiid )
    self.__uiid = uiid
end


function CommonSceneView:startMusic()
    self:initMusic()
    self:stopEffect()
end

-- 场景进入
function CommonSceneView:onEnter_()
  print("播放音效——————")
	self:startMusic()
	self.shadelayer = RequireModel.CommonLayerView.new()
	self.shadelayer:OpenTouch()
	self:addChild(self.shadelayer)
	local isshade = true
    local function updata(delta)
        isshade = false
        if self.shadelayer then
        	self.shadelayer:removeFromParent(true)
        	self.shadelayer = nil 
        end
    end
    self.schedulyid = cc.Director:getInstance():getScheduler():scheduleScriptFunc(updata,0.1,false)
	
	self:addKeyboardListener()
    -- print("onenter")
end

-- 场景退出
function CommonSceneView:onExit()
	if self.Cleanupresources then
	   self:Cleanupresources()
	end
	-- setCurrentRunNode(nil)
end

-- 处理网络数据请求
function CommonSceneView:dealSocketData(data)
	 
end
function CommonSceneView:switchScene(sceneName)
      self:getApp():run(sceneName)
end
-- 移除自己
function CommonSceneView:removeSelf()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulyid)
	self:setKeypadEnabled(false)
	self:removeNodeEventListener(cc.KEYPAD_EVENT,handler(self, self.addKeyboardListener))
    self:removeFromParent(true)
    self = nil
end

-- 添加键盘监听事件
function CommonSceneView:addKeyboardListener()
	if targetplatform == cc.PLATFORM_OS_ANDROID then
		self:setKeypadEnabled(true)
		self:addNodeEventListener(cc.KEYPAD_EVENT,function(event)
        	if event.key == "back" then
           		
           	elseif event.key == "menu" then
           		                           
        	end
    	end)
	end
end



return CommonSceneView
