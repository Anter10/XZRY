-- 游戏音乐管理类

local GameMusic         = {}
GameMusic.isPLayMusic   = true  -- 控制音乐播放
GameMusic.isPlayEffect  = true  -- 控制音效的播放
GameMusic.musicName     = nil   -- 当前音乐播放文件名
GameMusic.effectName    = nil   -- 当前音效播放文件名

-- 预加载一个音乐文件
-- @filename：音乐文件名
function GameMusic.preloadMusic(filename)
	audio.preloadMusic(filename)
end

-- 播放音乐
-- @filename：音乐文件名
-- @isloop：是否循环
function GameMusic.playMusic(filename, isLoop, ismusic)
    if GameMusic.isPLayMusic then 
  --       if GameMusic.musicName == filename then
		-- 	return
		-- end
		local hasfile = false
	    -- 判断文件路径
	    local filename = filename
	    if cc.FileUtils:getInstance():isFileExist(filename..".wav") then
	       
	       hasfile          = true
	    elseif not cc.FileUtils:getInstance():isFileExist(filename) then
	    	-- print("2音乐文件不存在",filename)
	       hasfile          = false
	    end
        print("1音乐文件存在",hasfile, ismusic)
	    if not hasfile then
           print("音乐文件不存在",filename)
        else
           GameMusic.musicName = filename

           if not ismusic then
              GameMusic.playSound(filename, isLoop)
           else
           	  print("当前播放的音乐 = ",filename, isLoop)
           	  GameMusic.effectName = filename
              audio.playMusic(filename..".wav", isLoop)
           end
	    end
		
	else
		GameMusic.musicName = nil
	end
end

-- 停止音乐
-- @isReleaseData：是否释放音乐
function GameMusic.stopMusic(isReleaseData)
  	audio.stopMusic(isReleaseData)
end

-- 暂停音乐
function GameMusic.pauseMusic()
	GameMusic.isPLayMusic = false
	audio.pauseMusic()
end

-- 恢复音乐
function GameMusic.resumeMusic()
	GameMusic.isPLayMusic = true
	audio.resumeMusic()
end

-- 从内存中卸载一个音乐文件
function GameMusic.unloadMusic(filename)
	audio.unloadMusic(filename)
end

-- 预加载一个音效文件
function GameMusic.preloadSound(filename)
	audio.preloadSound(filename)
end

-- 播放音效
function GameMusic.playSound(filename, isLoop)
	if GameMusic.isPlayEffect then
		print("播放音效12= ",filename,isLoop )
		GameMusic.effectName = filename
		audio.playSound(filename..".wav", isLoop)
	else
		GameMusic.effectName = nil
	end
end

-- 暂停所有音效
function GameMusic.pauseAllSounds()
	GameMusic.isPlayEffect = false
    -- audio.pauseAllSounds()
end

-- 恢复所有的音效
function GameMusic.resumeAllSounds()
	GameMusic.isPlayEffect = true
	audio.resumeAllSounds()
end

-- 停止当前所有音效，并且播放当前音效
-- @name：音效文件名
-- @isloop：是否循环播放
function GameMusic:stopAndPlayEffect(name, isLoop)
	GameMusic.stopAllEffects()
	GameMusic.playSound(name, isloop)
end

--停止所有音效
function GameMusic.stopAllEffects(call)
	GameMusic.volumn = audio.getSoundsVolume()
	-- 迟缓切换音效
	GameMusic.hasstop = false
	GameMusic.stopfinishcall = call
	local function stopAllEffects()
		 if not GameMusic.hasstop and GameMusic.volumn > 0 then
            GameMusic.volumn = GameMusic.volumn - 0.05
         elseif GameMusic.volumn < 1 then
            GameMusic.volumn = GameMusic.volumn + 0.05
		 end
		 
         audio.setSoundsVolume(GameMusic.volumn)
         audio.setMusicVolume(GameMusic.volumn)
         -- print("哪儿停止了音乐",GameMusic.volumn)
         if GameMusic.volumn <= 0 and not GameMusic.hasstop then
         	audio.stopAllSounds()
         	GameMusic.stopMusic(false)
         	GameMusic.hasstop = true
         	GameMusic.effectName = nil
         	if GameMusic.stopfinishcall then
               GameMusic.stopfinishcall()
         	end
         elseif GameMusic.hasstop and GameMusic.volumn >= 1 and GameMusic.schedulestopid  then
         	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(GameMusic.schedulestopid )
         	GameMusic.schedulestop = nil
         	GameMusic.schedulestopid = nil
            -- print("哪儿停止了音乐12",GameMusic.volumn)
         end
	end
    
    -- print("哪儿关闭了音效",GameMusic.effectName, GameMusic.schedulestop)
	if GameMusic.effectName and not GameMusic.schedulestop then
	   GameMusic.schedulestop   = cc.Director:getInstance():getScheduler()
	   GameMusic.schedulestopid = GameMusic.schedulestop:scheduleScriptFunc(stopAllEffects, 0.1, false)
	end
   
end

-- 从内存中卸载一个音效
function GameMusic.unloadSound(filename)
	audio.unloadSound(filename)
end
cc.exports.GameMusic = GameMusic
return GameMusic