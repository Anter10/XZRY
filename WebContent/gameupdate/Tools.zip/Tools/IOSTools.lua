-- 安卓环境下的相关参数

local IOSTools = class("IOSTools")

IOSTools.setFunctions = {
	


	
}

function IOSTools:ctor()
	-- body
end

-- 检测IOS是否有网络连接
-- @返回 true: 有网络连接  false:没有网络连接
function IOSTools.isIOSConnectInternet()
	return IOSTools.callIOSMethod("reachabilityForInternetConnection")
end

-- 检查android环境是否连接WI-FI 
-- @返回 true: 是WIFI  false:不是WIFI
IOSTools.checkIOSWifi = function()
    return IOSTools.callIOSMethod("reachabilityForLocalWiFi") 
end

-- 调用ios环境下的方法
function IOSTools.callIOSMethod(funcName)
    if (cc.PLATFORM_OS_IPHONE == targetplatform) or (cc.PLATFORM_OS_IPAD == targetplatform) or (cc.PLATFORM_OS_MAC == targetplatform) then
            local args = {}
            local luaoc = require "cocos.cocos2d.luaoc"
            local className = "Reachability"
            local ok, ret = luaoc.callStaticMethod(className,funcName)
            if not ok then
            	RequireModel.DialogView.show(107)
               -- print("luaj error:", ret)
            else
            	RequireModel.DialogView.show(107)
                -- print("The ret is:", ret)
            end
        return ok
    else
        return false
    end
end

return IOSTools