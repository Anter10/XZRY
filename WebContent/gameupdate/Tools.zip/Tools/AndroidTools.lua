-- 安卓环境下的相关参数

local AndroidTools = {}

AndroidTools.setFunctions = {
   -- 检测Android是否有网络连接
   -- @返回 true: 有网络连接  false:没有网络连接
   isAndroidConnectInternet = function()
       return AndroidTools.setFunctions.callAndroidMethod("isInternetConnectionAvailable")
   end,
  
    -- 检查android环境是否连接WI-FI
    -- @返回 true: 是WIFI  false:不是WIFI
   checkAndroidWifi = function()
       return AndroidTools.setFunctions.callAndroidMethod("isLocalWiFiAvailable")
   end,
   
   -- 计算两个整数的和
   addTwoNumber = function(num)
      return AndroidTools.setFunctions.callAndroidMethod("isNetworkConnected",{num})
   end,

   -- 调用安卓环境中的方法
   callAndroidMethod = function(funName,args)
            if (cc.PLATFORM_OS_ANDROID == targetplatform) then
                local sigs = "(II)I"
                local luaj = require "cocos.cocos2d.luaj"
                local className = "org/cocos2dx/lua/AppActivity"
                local ok,ret  = luaj.callStaticMethod(className, funName,args,sigs)
                if not ok then
                   -- print("luaj error:", ret)
                   showDialog.show(108)
                else
                   -- print("The ret is:", ret)
                   showDialog.show(109)
                end
                return ret
            else
                RequireModel.DialogView.show(107)
                return false
            end
  end
	
}

 
cc.exports.Android = AndroidTools
return AndroidTools