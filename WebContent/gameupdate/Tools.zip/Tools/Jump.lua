-- 界面跳转类
local Jump = class("Jump", {})

-- 当前主界面的下标是多少
local mainindex = 0

-- 界面跳转的
function Jump:ctor()
	  -- 跳过的所有界面
    self.intoAllUi   =  {}
    -- 在场景中已经创建了的界面
    self.hasCreateUi = {}

    -- 当前显示的界面
    self.runNode   = {}
end

-- 添加程序的入口界面
function Jump:addFirstClass()
    local findata = {}
    findata.__cname =  RequireModel.ComeGameScene.__cname
    findata.__norepeate =  RequireModel.ComeGameScene.__norepeate
    self.intoAllUi[#self.intoAllUi + 1] = findata
    self.runNode = getCurrentRunNode() 
end

-- 得到一件创建了的UI
function Jump:getUI( idorname )
    if idorname then
        className   = idorname
        if type(idorname) == "number" then
           className     = getSystemData():getGameViewsDataById(uinameorid):getClassName()
        end
        for uiIndex, ui in pairs(self.hasCreateUi) do
            if ui and ui.__cname == className then
               return ui
            end
        end
    end
end

-- 界面跳转方向
--[[
  场景 到 场景 
  层级 到 场景
  场景 到 层级(层级的父场景)
--]]

-- 这里的数据都是针对构造函数的数据
-- 跳到某个界面
--[[
    ... 包含的信息
    [1]className or id   : 跳转的类名
--]]
 
-- 得到 跳转得数据
function Jump:getToData()
   local tdata   = Jump.toData
   -- Jump.toData = nil
   return tdata
end

-- 设置跳转的数据
-- @data : 设置跳转的数据
function Jump:setToData(data)
    Jump.toData = data
end

-- 手动设置某个跳过的界面为返回的时候   是否重新创建
-- @uinameorid: 设置的界面ID
-- @norepeate:  是否重新创建
function Jump:setClassNoRepeate( uinameorid, norepeate )
    local removeIndex = 0
    local className   = uinameorid
    if tonumber(uinameorid) then
       className     = getSystemData():getGameViewsDataById(uinameorid):getClassName()
    end
    
    print("移除的UI名称",className)
    for classIndex,uiClass in pairs(self.intoAllUi) do
        if uiClass.__cname == className then
           removeIndex = classIndex
           break
        end
    end
    self.intoAllUi[removeIndex].__norepeate = norepeate
end

-- 设置back后的刷新方法
-- @callback: 界面返回到上一个界面 需要刷新的方法
function Jump:setCallBack(callback)
     self.backCall = callback
end

-- back后调用的方法
function Jump:callBackFunc()
    if self.backCall then
       self:backCall(self:getBackData())
       self.backCall = nil
    end
end

-- 移动到指定的战斗单位
-- @ids: 跳之后除了 MianScene 之外的返回的【场景】的列表
-- @jumpid 跳去的场景ID  如果是表 则会跳一组UI
-- @centerlayers: 中间经历多少层 现在暂时都为{}
-- @todata 跳过去的数据  对应每个跳转的UI数据
-- @norepeate 当前跳的时候需不需要创建 norepeate 对应是否需要重新创建
function Jump:removeToMainJump(ids, jumpid,centerlayers, todata, norepeate)
    local hasfindmain = false
    local allindex    = {}
    print("跳入的所有UI  = ",json.encode(self.intoAllUi))
    for classIndex,classname in ipairs(self.intoAllUi) do
        if not hasfindmain and classname and classname.__cname == "MainScene" then
           hasfindmain = true
        elseif hasfindmain then
           allindex[#allindex + 1] = classIndex
        end
    end
   
    for i=1,#allindex do
        self:removeInto()
    end
   
   
    print("ids = ",json.encode(self.intoAllUi))

    -- self:removeInto()
    print("ids1 = ",json.encode(self.intoAllUi))

    if centerlayers and type(centerlayers) == "table" then
       for i,classnameorid in ipairs(centerlayers) do
           self:removeInto()
       end
    end

    if ids and type(ids) == "table" then
       for i,className in ipairs(ids) do
           if tonumber(className) then
              className     = getSystemData():getGameViewsDataById(uinameorid):getClassName()
           end 
           local intodata   = {}
           intodata.__cname     = className
           intodata.__norepeate = false
           self.intoAllUi[#self.intoAllUi + 1] = intodata 
       end
    end

    
    if type(jumpid) == "string" then
       self:setToData(todata)
       self:jumpTo(jumpid, norepeate)
    elseif type(jumpid) == "table" then
       self:jumpGroupView( jumpid, norepeate, todata, true)
    else

    end
    print("当前所有数据  - ",json.encode(self.intoAllUi))
    
end
 
-- 移除一组 已经创建了的UI
-- @ids: 给定的界面ID
function Jump:removeMoveAGroupView(ids)

   if type(ids) == "table" then
      for uiIndex,uinameorid in pairs(ids) do
          self:removeIndexById(uinameorid)
      end
   end
end

-- 移除进入过的下标
function Jump:removeHasIntoByNameOrId( uinameorid )

     local removeIndex = 0
     local className   = uinameorid
     if tonumber(uinameorid) then
        className     = getSystemData():getGameViewsDataById(uinameorid):getClassName()
     end
     for classIndex,uiClass in ipairs(self.intoAllUi) do
        if uiClass.__cname == className then
           removeIndex = classIndex
           break
        end
     end
     self:removeInto(removeIndex)
end

-- 手动移除某个类的下标 返回的时候跳过该类
-- @uiname: ui的ID 或者 名称
function Jump:removeIndexById(uinameorid)
    local removeIndex = 0
    local className   = uinameorid
    if tonumber(uinameorid) then
       className     = getSystemData():getGameViewsDataById(uinameorid):getClassName()
    end
    
    print("移除的UI名称 = ",className)

    for classIndex,uiClass in ipairs(self.intoAllUi) do
        if uiClass.__cname == className then
           removeIndex = classIndex
           break
        end
    end
   
    if removeIndex > 0 then
       if self.runNode then
          self:cutGrayNumber()
          print(self.runNode.__cname,"当前移除的UI  - ")
          self.runNode:removeFromParent()
          self.runNode = nil
       end
       self:removeInto(removeIndex)
       self:removeHasCreate()
    end 
end



-- 设置back的数据
-- @data : 界面返回的数据
function Jump:setBackData(data)
    Jump.backData = data
end

-- 得到back的数据
function Jump:getBackData()
   local  tdata    = Jump.backData
   -- Jump.backData = nil
   return tdata
end


-- 根据ID得到战斗单位的
-- @idOrJumpToClassName: 界面的   名称或者ID
function Jump:getJumNameByIdOrName(idOrJumpToClassName)
    for classIndex,Class in pairs(RequireModel) do
        if type(Class) ~= "boolean" and ( Class.__cname == idOrJumpToClassName or Class.id == idOrJumpToClassName)  then
           return Class
        end
    end
    return nil
end

-- 对当前场景中的所有节点进行排序
function Jump:getSortZorder()
     local children = getCurrentRunNode():getChildren()
     if type(children) == "table" and #children > 0 then
        local function sortZorder(node1, node2)
           if not node1 then return false end
           if not node2 then return true end
           return node1:getLocalZOrder() > node2:getLocalZOrder()
        end
        table.sort(children, sortZorder)
        local zorder = children[#children]:getLocalZOrder()
        return zorder + 1
     end
     return 100
end

-- 显示界面
-- ToOrBackClass: 跳转的类名
-- ToOrBackClass: 进入的名称
-- ToOrBackdata:  进入的数据
function Jump:goTo(ToOrBackClass, ToOrBackdata, zorder)
       print("当前要去的场景名称 ",ToOrBackClass.__cname,ToOrBackClass.__type)
       -- print("返回的时候剩余的场景 = ",json.encode(self.intoAllUi))
       if ToOrBackClass.__type == 1 then
          print("121212")
          if not zorder then
             zorder = self:getSortZorder()
          end
          print("121213",zorder,type(zorder))
          if ToOrBackdata then
             -- print("json == ",json.encode(ToOrBackdata))
          end
          local uilayer = ToOrBackClass.new(ToOrBackdata)
          print("abcccc ", ToOrBackClass.create)
          if not uilayer and ToOrBackClass.create then
             uilayer = ToOrBackClass:create(ToOrBackdata)
          end
          print("121214")
          self.runNode  = uilayer
          self.runNode.__type  = ToOrBackClass.__type
          self.runNode.__cname = ToOrBackClass.__cname

          self.hasCreateUi[#self.hasCreateUi + 1] = uilayer
          print("当前添加了吗 = ",zorder,uilayer ) 
          getCurrentRunNode():addChild(uilayer, zorder)
          
       elseif ToOrBackClass.__type == 2 then
          -- className.__norepeate  = true
          clearMemory()
          -- 清空灰色层级数量
          RequireModel.CommonLayerView.clearGrayNumber()
          self.hasCreateUi = {}
          print("当前的场景要去的场景数据  = ",ToOrBackClass.__cname)
          if not getCurrentRunNode().switchScene then
             display.runScene(ToOrBackClass.new())
          else
             getCurrentRunNode():switchScene(ToOrBackClass.__cname)
          end
         
          self.runNode = getCurrentRunNode()
         
       end
end

function Jump:setNoRepeate(className , norrepeate )
    for i,v in ipairs(self.intoAllUi) do
        if v.__cname == className then
           v.__norepeate = norrepeate
        end
    end
end


-- 返回到某个界面
-- @zorder: 设置的层级
function Jump:backTo(zorder)
   
    if #self.intoAllUi > 1 then
       local backdata = self:getBackData()
       local allIndex = #self.intoAllUi
       local backToIndex = allIndex - 1
       local repleates   = self.intoAllUi[backToIndex].__cname
       local BackClass   = self:getJumNameByIdOrName(repleates) 
       print("返回的场景名称1 =  ",json.encode(self.intoAllUi[backToIndex]))
       print("返回的场景名称2 =  ",BackClass.__cname,BackClass.__norepeate)
       -- 如果不需要返回的话 不需要移除当前的信息
       self:removeInto()
       -- 当前返回界面是否需要重新创建
       local norepeate = self.intoAllUi[backToIndex].__norepeate
      
      
       self.prenorepeate = false
       -- 移除当前最前面的UI
       local currentrundtype = 1
       -- for i,v in ipairs(self.hasCreateUi) do
       --     print(i,v, "当前创建UI名称 = ",v.__cname, v.__type)
       -- end
       local backtype = BackClass.__type
       print(backtype,"self.hasCreateUi = ",#self.hasCreateUi)
       if #self.hasCreateUi > 0 then
          local uimax = #self.hasCreateUi
          self.runNode = self.hasCreateUi[uimax]
          if self.runNode then
             print(self.runNode, uimax,"self.runNode.__type = ",self.runNode.__type)
             if self.runNode.__type == 1 then
                -- 如果当运行的层级是否有半透明
                print(self.runNode.__cname, "灰色层级移除1 = ",self.runNode:hasGrayLayer())
                self:cutGrayNumber()
                self.prenorepeate = true
                 print("abcc0",self.runNode)
                currentrundtype = self.runNode.__type
                self.runNode:removeFromParent(true)
                print("abcc1")
                self.runNode = nil
             end
          end
       end
       
      
       
       self:removeHasCreate()
       
       if #self.hasCreateUi == 0 and backtype == 2 then
          if getCurrentRunNode().backToCall then 
             getCurrentRunNode():backToCall()
          end
       else
          self.runNode = self.hasCreateUi[#self.hasCreateUi]
       end

       print("肉肉肉肉 = ",self.runNode)
       -- 判断当前运行的节点 是否 为场景  和  即将跳转的场景是否为场景  如果都为场景
       local isstos = false

       if (not self.runNode or #self.hasCreateUi == 0) or ((self.runNode.__type == 2) and backtype == 2 and #self.intoAllUi == 0) then
          isstos = true
       end 

       print("isstosisstos1= ",isstos, getCurrentRunNode().__norepeate) 

       if self.prenorepeate and backtype == 2 then
          isstos = false
       end

       print("isstosisstos2= ",isstos)
       print("not norepeate = ",not norepeate, isstos)
       if not norepeate or isstos then
          if self.runNode and self.runNode.__type == 1 then
             print(self.runNode.__type,"返回的那个场景重现创建了",BackClass.__cname)
             self.runNode:removeFromParent(true)
             self.runNode = nil
          end
          self:removeHasCreate()
          if BackClass.__cname == "ComeGameScene" then
             BackClass = RequireModel.MainScene
          end
          self:goTo(BackClass, backdata, zorder)
       else
          self:callBackFunc()
          if self.runNode and self.runNode.backToCall then
             self.runNode:backToCall()
          end
       end
       -- 返回场景的时候播放场景音效
       if getCurrentRunNode().startMusic then 
          getCurrentRunNode():startMusic()
       end
    elseif self.intoAllUi == 1 then
       local backdata    = self:getBackData()
       local BackClass   = self:getJumNameByIdOrName( self.intoAllUi[1].__cname) 
       self:removeInto(1)
       if BackClass.__cname == "ComeGameScene" then
          BackClass = RequireModel.MainScene
       end
       print("BackClassBackClassBackClass ",BackClass.__cname)
       self:goTo(BackClass, backdata)
    end

    
    return self.runNode
end


function Jump:removeHasCreate(index)
    local tindex =  #self.hasCreateUi
    if index then
       tindex = index
    end
    print("已经创建的次数1  = ",#self.hasCreateUi)
    table.remove(self.hasCreateUi, tindex)
    print("已经创建的次数2  = ",#self.hasCreateUi)
    -- local uis = {}

    -- for i,view in ipairs(self.hasCreateUi) do
    --     uis[#uis + 1] = view
    -- end
    -- self.hasCreateUi  = uis
end

function Jump:removeInto(index)
    print("移除分割线 ————————————————————————————————————")
    local tindex =  #self.intoAllUi
    if index then
       tindex = index
    end

    table.remove(self.intoAllUi,tindex)
    local uis = {}
    
    for i,view in ipairs(self.intoAllUi) do
        if view ~= nil then
           -- print("viewviewview = ",view.__cname)
           uis[#uis + 1] = view
        end
    end

    print("当前的所有已经进入的ID  = ",json.encode(self.intoAllUi))
    self.intoAllUi  = clone(uis)
end

-- 移除遮罩层的计数器
function Jump:cutGrayNumber()
     if self.runNode.hasGrayLayer and self.runNode:hasGrayLayer() then
        RequireModel.CommonLayerView.cutGrayNumber()
        print("灰色层级移除2")
     end
end


-- 跳一组试图  这组试图中只允许一个场景试图存在

-- @ids      需要跳转的所有界面的ID          如: {31,32}
-- @repeates 跳转返回的时候是否需要重新创建:   如: {false, true}
-- @datas    跳转后的数据                  如: {{id = 31}, {id = 32}}
function Jump:jumpGroupView( idrs, repeates, datas, nclear)
     -- 清空灰色层级数量
     RequireModel.CommonLayerView.clearGrayNumber()
     if not nclear then
        self.intoAllUi = {}
        self.hasCreateUi = {}
     end
     for goIndex,id in ipairs(idrs) do
         local jumpdata  = {}
         if datas and datas[goIndex] then
            jumpdata = datas[goIndex]
         end
         local norepeate = false
         if repeates and repeates[goIndex] then
            norepeate = repeates[goIndex]
         end
         -- 设置跳转的数据
         self:setToData(jumpdata)
         -- 开始跳转
         self:jumpTo(id, norepeate)
     end 
end


-- 跳转界面
-- @idOrJumpToClassName : 界面的 ID 或者 名称
-- @norepeate:      true: 返回的时候不需要重新创建  false: 返回的时候需要重新创建  
function Jump:jumpTo(idOrJumpToClassName, norepeate)
    -- 根据类名 或者 类的ID 获得类名
    if tonumber(idOrJumpToClassName) then
       idOrJumpToClassName = getSystemData():getGameViewsDataById(idOrJumpToClassName):getClassName()
    end
    local className     = self:getJumNameByIdOrName(idOrJumpToClassName)
    if className then

       print("当前的额场景名称 = ",className.__cname, norepeate)
    end
    if not className then
       print("——————————————————————————  没有你要跳转的界面 ——————————————————————————")
       printError("")
    elseif (self.runNode and className.__cname ~= self.runNode.__cname) or not self.runNode then
       -- 把当前的类添加到跳转列表里面
       className.__norepeate     = norepeate
       
       if self.intoAllUi[#self.intoAllUi] then
          self.intoAllUi[#self.intoAllUi].__norepeate = norepeate
       end
       if not self:hasIt(className.__cname) then
          local intodata = {}
          intodata.__norepeate = norepeate
          intodata.__cname     = className.__cname

          self.intoAllUi[#self.intoAllUi + 1] = intodata
          if className.__cname == "MainScene" then
             mainindex = #self.intoAllUi
          end
       end
       print("当前的额场景名称 = ",className.__cname)
       -- 得到跳转的数据
       local jumpToData    = self:getToData()
       
       if self.runNode and self.runNode.jumpCallBack then
          self.runNode:jumpCallBack()
       end

       -- if self.hasCreateUi and #self.hasCreateUi > 0 then
       --    self.hasCreateUi[#self.hasCreateUi].__norepeate = norepeate
       -- else
       --    getCurrentRunNode().__norepeate = norepeate
       -- end

       self:goTo(className, jumpToData)
    else
      print(idOrJumpToClassName)
      
    end

    -- printError("idOrJumpToClassNameidOrJumpToClassName = "..self.runNode.__cname)
    
    self.runNode.__noback        = notBack
    return self.runNode
end

-- 判断加入的界面存在没有
function Jump:hasIt(name)
    for k,classs in pairs(self.intoAllUi) do
        if name == classs.__cname  then
           return true
        end
    end
end


function Jump:getRunNode()
    return self.runNode
end

cc.exports.UIJump = Jump.new()  



