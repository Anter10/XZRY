local ListviewNode = class("ListviewNode", RequireModel.CommonNode)

-- 使用格式 listviewdata初始化listview othernodes是需要插入到某一下标的item节点
-- listviewdata = {
--   dir    = 1,         -- listview视图方向
--   size   = cc.size(winsize.width/2,winsize.height/2), -- listview大小
--   models = {RoleView.new(1),RoleView.new(2),RoleView.new(3),RoleView.new(4)}, -- 加载视图节点
--   sonmodels = {RolePropertyView.new(1)}, -- 跟随节点视图

--   leftcall = func,  -- 滑动到最左边回调事件
--   rightcall = func, -- 滑动到最右边回调事件
--   upcall =func,     -- 滑动到最上边回调事件
--   bottomcall = func,-- 滑动到最底部回调事件

--   leftbuttoncall = func, -- 方向按钮回调事件
  
--   background = "HelloWorld.png", -- 背景图片
--   MagneticType = 1, -- 1, 2, 3   -- 视图对齐类型
--   bounce       = false,          -- 是否弹性回弹
--   pos          = {cc.size(60,winsize.height/4),cc.size(winsize.width/4, winsize.height/4)} -- 按钮位置
     -- othernode = {{index = 12, node = node}}
-- }

function ListviewNode:ctor(data)
	self.data = data
    self:setContentSize(self.data.size)
	self.listnode      = nil               -- 滑动视图节点
	self.bindingView   = nil               -- 绑定视图
	self.allVeiwNum    = #self.data.models -- 加载视图总数
    self.currentViewId = 1                 -- 当前视图id
    self.isBegan  = false                  -- listview竖直方向初始时视图时时默认滑动了一下，并不是真正的滑动 
	self.containerSize = self.data.size    -- 视图大小 
	self:enterListview()
end

function ListviewNode:enterListview()
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_START then
            print("select child index = ",sender:getCurSelectedIndex())
        end
    end
	local function scrollViewEvent(sender, evenType)
        if evenType == ccui.ScrollviewEventType.scrollToRight then
            self:setRightCall()
        elseif evenType == ccui.ScrollviewEventType.scrollToLeft then
            self:setLeftCall()
        elseif evenType == ccui.ScrollviewEventType.scrollToTop then
            self:setTopcall()
        elseif evenType == ccui.ScrollviewEventType.scrollToBottom then
            self:setBottomcall()
        else

        end
    end
    
	self.listnode = ccui.ListView:create()
    self:setScrollDirection(self.data.dir)
    -- self.listnode:setMagneticType(self.data.MagneticType)
    self.listnode:setScrollBarEnabled(self.data.bounce)
    if self.data.bounce then
        self.listnode:setScrollBarColor(cc.YELLOW) 
    end
    self.listnode:settouchmoveicon(false)
    -- self.listnode:settouchiconismoving(false)
    self.listnode:setSwallowTouches(false)
    self.listnode:setTouchEnabled(true)
    self.listnode:setBounceEnabled(self.data.bounce)
    self.listnode:setContentSize(cc.size(self.containerSize.width,self.containerSize.height))
    if self.data.background then
        self.listnode:setBackGroundImage(self.data.background)
    end
    -- self.listnode:addEventListener(listViewEvent)
    self.listnode:addScrollViewEventListener(scrollViewEvent)
    self:addChild(self.listnode)
    for modelIndex, model in ipairs(self.data.models) do
        local item = ccui.Layout:create()
        item:setTouchEnabled(true)
        item:setContentSize(model:getContentSize())
        item:addChild(model)
        self.listnode:setItemModel(item)
        self.listnode:pushBackCustomItem(item)
    end 
     
    if self.data.othernode and #self.data.othernode ~= 0 then
        for index,data in pairs(self.data.othernode) do
            local item = ccui.Layout:create()
            item:setTouchEnabled(true)
            item:setContentSize(data.node:getContentSize())
            item:addChild(data.node)
            self.listnode:insertCustomItem(item, data.index)
        end
    end
end

-- 移除当前视图，重新加载视图
function ListviewNode:restartView(modeldata)
    self.listnode:removeAllChildren()
    self:addNewItem(modeldata)
end

-- 加载新的item
function ListviewNode:addNewItem(model)
     for modelIndex, data in ipairs(model) do
        local item = ccui.Layout:create()
        item:setTouchEnabled(true)
        item:setContentSize(data:getContentSize())
        item:addChild(data)
        self.listnode:setItemModel(item)
        self.listnode:pushBackCustomItem(item)
    end 
end

-- 插入指定下标的node
function ListviewNode:insertNewItemByIndex(index, node)
    if node then
        local item = ccui.Layout:create()
        item:setTouchEnabled(true)
        item:setContentSize(node:getContentSize())
        item:addChild(node)
        self.listnode:insertCustomItem(item, index)
    end
end

-- 插入node并且刷新listnode
function ListviewNode:insertAndFlushData(node) 
    local allitemnum = #self.listnode:getItems()
   if node then
        local item = ccui.Layout:create()
        item:setTouchEnabled(true)
        item:setContentSize(node:getContentSize())
        item:addChild(node)
        self.listnode:insertCustomItem(item, allitemnum)
    end
    self.listnode:jumpToPercentVertical(100)
end

-- 设置滑动方向
-- @dir：方向
function ListviewNode:setScrollDirection(dir)
	if dir == 1 then
		self.listnode:setDirection(ccui.ScrollViewDir.horizontal)
	else
		self.listnode:setDirection(ccui.ScrollViewDir.vertical)
	end
end

-- 设置弹到上方钮回调
function ListviewNode:setTopcall()
	-- -- print("SCROLL_TO_TOP")
end

-- 设置弹到下方按钮回调
function ListviewNode:setBottomcall()
	-- print("SCROLL_TO_BOTTOM")
    if self.data.bottomcall then
        self.data.bottomcall()
    end
end

-- 得到节点
function ListviewNode:getListView()
    return self.listnode
end

-- 设置弹到左方按钮回调
function ListviewNode:setLeftCall()
	-- -- print("SCROLL_TO_LEFT")
end

-- 设置弹到右方按钮回调
function ListviewNode:setRightCall()
	-- -- print("SCROLL_TO_RIGHT")
end

return ListviewNode