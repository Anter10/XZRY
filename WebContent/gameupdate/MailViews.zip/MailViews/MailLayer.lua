local MailLayer = class("MailLayer", RequireModel.CommonFullSceneUI)

local maildata = {
	{
		m_type      = "好友邮箱",
		name        = "进攻战报",
		publisher   = "王二",
		publishtime = "2015-1-16",
		parttime    = "剩余7天1小时",
		icon        = "ui_team_100301.png",
		read        = true,
	},
	{
		m_type      = "好友邮箱",
		name        = "防守战报",
		publisher   = "张三",
		publishtime = "2016-1-16",
		parttime    = "剩余7天2小时",
		icon        = "ui_team_100301.png",
		read        = false,
	},
	{
		m_type      = "好友邮箱",
		name        = "攻击战报",
		publisher   = "张五",
		publishtime = "2017-1-16",
		parttime    = "剩余7天3小时",
		icon        = "ui_team_100301.png",
		read        = true,
	},
}

function MailLayer:ctor()
	self.super.ctor(self, UIID.MailLayer,data)
	self.mailid1 = {1,2,3}
	self.mailid2 = {2,1,3}
	self.mailid3 = {3,2,1}

	self.maildata = {}           -- 邮箱列表数据
	self.currentlayerindex = 1   -- 当前选择的邮箱类型下标
	for itemindex,itemdata in pairs(maildata) do
		getPlayerData():setMailData(RequireModel.MailData.new(itemdata))	
	end
	self.data = getPlayerData():getMailData()

	self:init()
end

function MailLayer:init()
	self.background = createSprite("UI_bottom/beijing.png")
	self.background:setPosition(winsize.width/2, winsize.height/2)
	self:addChild(self.background)


	self:addSystemAndBattleReportButton()
	self:addMailSlideNode()
end

-- 添加邮件类型框层
function MailLayer:addMailTypeBottomLayer(index)
	local namestring
	if index == 1 then
		namestring = "系统邮件"
	elseif index == 2 then
		namestring = "战报邮件"
	elseif index == 3 then
		namestring = "好友邮件"
	end
	
	local mailtypelayer = cc.Layer:create()
	local bottom = createSprite("UI_bottom/diban332.png")
	bottom:setScaleY(60/150)
	bottom:setPosition(300, 30)
	mailtypelayer:addChild(bottom)
	mailtypelayer:setContentSize(cc.size(600,60))
	namelabel = Font.getTextLabel(namestring, 24,nil,nil,1,nil,cc.p(0.5, 0.5),mailtypelayer,cc.p(150,30),1,false)
	return mailtypelayer
end

-- 添加邮件滑动层
function MailLayer:addMailSlideNode()
	self:createMailItem(self.currentlayerindex,self.data)
	self.maildata = {
      	dir    = 2,                            -- listview摆放方向
      	size   = cc.size(600,510),             -- 视图大小
      	models = self.models,                  -- listview加载视图
      	leftcall = nil,                        -- 滑动到最左边回调函数
      	rightcall = nil,                       -- 滑动到最右边回调函数
      	upcall =nil,                           -- 滑动到最上边回调函数
      	bottomcall = nil,                      -- 滑动到最下面回调函数

      	leftbuttoncall = func,                 -- 上下按钮回调函数
  
      	background = "UI_bottom/diban322.png", -- listview背景图片
      	MagneticType = 2,                      -- 视图放置类型
      	bounce       = true,                   -- 是否弹性回复
      	-- othernode = {{index = 0, node = self:addMailTypeBottomLayer(1)}}
  	}

	self.mailslidenode = RequireModel.ListviewNode.new(self.maildata)
	self.mailslidenode:setPosition(winsize.width/2-300,100)
	self:addChild(self.mailslidenode)
end

-- 创建邮箱item
function MailLayer:createMailItem(index, data)
	self.models = {}
	if self:addMailTypeBottomLayer(index) then
		self.models[#self.models+1] = self:addMailTypeBottomLayer(index)
	end
	for index,itemdata in pairs(data) do
		-- local data = getSystemData():getEmailDataById(mailid)
		local mailobj = RequireModel.MailItem.new(itemdata)
		self.models[#self.models+1] = mailobj
	end	
end

--刷新邮件数据
function MailLayer:flushMailData(index)
	if index == 1 then
		self:createMailItem(index, self.data)
	elseif index == 2 then
		self:createMailItem(index, self.data)
	elseif index == 3 then
		self:createMailItem(index, self.data)
	end
	self.maildata.models = self.models
end

-- 添加系统和战报按钮
function MailLayer:addSystemAndBattleReportButton()
	local function buttoncallback(index)
		if self.currentlayerindex == index then
			-- 和当前邮箱类型一样
		else
			self:flushMailData(index)
			self.mailslidenode:restartView(self.models)
			self.currentlayerindex = index
		end		
	end 
	self.radioButtonnode = RequireModel.RadioButtonNode.new({dir = 2, num = 3, rect = cc.rect(0,0,83,43), callback = buttoncallback, labelname = {"系统", "战报", "好友"}})
	self.radioButtonnode:setPosition(200, winsize.height*3/4+80)
	self:addChild(self.radioButtonnode)
	self.radioButtonnode:initButton("shanganniu.png", "shanganniu.png",true)
end

return MailLayer