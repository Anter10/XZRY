local MailDialog = class("MailDialog", RequireModel.CommonLayerView)

function MailDialog:ctor(data)
	self.super.ctor(self)
	self:setContentSize(cc.size(600,539))
	self.data = data
	
	self.mailtype = nil    --- 邮箱类型
	self:OpenTouch()
	self.viewsize = self:getContentSize()
	self:setSwallowTouches(true)
	self:setTouchClose(true)
	self:setTouchRect(cc.rect(winsize.width/2 - self.viewsize.width/2 + 100, winsize.height/2 - self.viewsize.height/2,self.viewsize.width, self.viewsize.height))
	self:init()
	--
	print("obj = ", getCurrentRunNode():getChildByName(tostring(UIID.MailLayer))) 
end

function MailDialog:init()
	-- 1：为好友类型 2：为系统邮件
	if self.mailtype == 1 then
		self:addSystemButton()
	elseif self.mailtype == 2 then
		self:addBattleReportButton()
	end
	
	self.background = createSprite("UI_bottom/diban32.png")
	self.background:setPosition(self.viewsize.width/2, self.viewsize.height/2)
	self:addChild(self.background)

	self:setName(self.data:getName())
	self:setPublisher()
	self:setPublishTime()
	self:setInfo()
	self:addCloseButton()
end

-- 设置名称
function MailDialog:setName(name)
	Font.getTextLabel(name, 32,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(300,510),1,false)
end

-- 设置发布者
function MailDialog:setPublisher()
	
end

-- 设置发布时间
function MailDialog:setPublishTime()
	
end

-- 设置简介
function MailDialog:setInfo()
	
end

-- 添加战报邮箱按钮
function MailDialog:addBattleReportButton()
	local function recoverycallback()
		-- 回收按钮
	end
	self.recoverybutton = RequireModel.Button.new("UI_button/guanbi.png","UI_button/guanbi.png","","回放")
    self.recoverybutton:setScale(0.5)
    self.recoverybutton:setPosition(0,0)
    self:addChild(self.recoverybutton)
    self.recoverybutton:setCallback(recoverycallback)

    local function battlecallback()
		-- 报复按钮
	end
	self.battlebutton = RequireModel.Button.new("UI_button/guanbi.png","UI_button/guanbi.png","", "报复")
    self.battlebutton:setScale(0.5)
    self.battlebutton:setPosition(0,0)
    self:addChild(self.battlebutton)
    self.battlebutton:setCallback(battlecallback)
end

-- 设置系统邮件
function MailDialog:addSystemButton()
	local function receivecallback()
		-- 领取按钮
	end

	self.receivebutton = RequireModel.Button.new("UI_button/guanbi.png","UI_button/guanbi.png","", "报复")
    self.receivebutton:setScale(0.5)
    self.receivebutton:setPosition(0,0)
    self:addChild(self.receivebutton)
    self.receivebutton:setCallback(receivecallback)
end

-- 设置关闭按钮
function MailDialog:addCloseButton()
	local function closecallback()
        
    end
    self.colsebutton = RequireModel.Button.new("UI_button/guanbi.png","UI_button/guanbi.png")
    self.colsebutton:setScale(0.5)
    self.colsebutton:setPosition(winsize.width-self.colsebutton:getContentSize().width/2, 50)
    self:addChild(self.colsebutton)
    self.colsebutton:setCallback(closecallback)
end

-- 点击关闭当前层
function MailDialog:touchCloseCallback()
	print("6666666")
	UIJump:backTo()
end

return MailDialog