local MailItem = class("MailItem", RequireModel.CommonNode)

function MailItem:ctor(data)
	self.super.ctor(self)
	self:setContentSize(cc.size(600,150))
	self.data = data
	self:OpenTouch()
	self:setSwallowTouches(false)

	self.background = createSprite("UI_bottom/diban332.png")
	self.background:setPosition(300, 75)
	self:addChild(self.background)
	------ 
	self:setName(self.data:getName())
	self:setIcon(self.data:getIcon())
	self:setPublisher(self.data:getPublisher())
	self:setPublishTime(self.data:getPublishTime())
	self:setRemainTime(self.data:getRemainTime())
end

-- 设置邮件名称
function MailItem:setName(name)
	Font.getTextLabel(name, 16,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(200,120),1,false)
end

-- 设置邮件图标
function MailItem:setIcon(imagefile)
	self.icon = createSprite(imagefile)
	self.icon:setPosition(self.icon:getContentSize().width/2, 75)
	self:addChild(self.icon)
end

-- 设置发布者
function MailItem:setPublisher(publisher)
	Font.getTextLabel("发布者："..publisher, 16,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(200,80),1,false)
end

-- 设置发布时间
function MailItem:setPublishTime(publishtime)
	Font.getTextLabel("发布时间："..publishtime, 16,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(200,40),1,false)
end

-- 设置剩余时间
function MailItem:setRemainTime(parttime)
	Font.getTextLabel("剩余时间："..parttime, 16,nil,nil,1,nil,cc.p(0.5, 0.5),self,cc.p(450,40),1,false)
end

-- 设置是否已读取
function MailItem:isRead()
	
end

-- 触摸开始
function MailItem:onTouchBegan(touch, event)
	self.beginPoint = touch:getLocation()
	return true
end

-- 触摸移动
function MailItem:onTouchMoved(touch, event)
  
end

-- 触摸结束
function MailItem:onTouchEnded(touch, event)
    self.endPoint = touch:getLocation()
    if self:containsTouchLocation(touch:getLocation().x,touch:getLocation().y) then
	  if twoPointDistance(self.endPoint.x,self.endPoint.y, self.beginPoint.x,self.beginPoint.y) < 20 then
         UIJump:setToData(self.data)
	     local maildialog = UIJump:jumpTo("MailDialog", true)
	     maildialog:setPosition(winsize.width/2 - maildialog.viewsize.width/2 +100 , winsize.height/2- maildialog.viewsize.height/2)
      end
    end
end


return MailItem