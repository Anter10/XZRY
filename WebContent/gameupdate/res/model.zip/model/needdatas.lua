local needdatas = class("needdatas",{})


function needdatas:ctor(data)
   self.data = data    
end


function needdatas:getId()
    return self.data["id"]
end


function needdatas:getWho()
    return self.data["who"]
end


function needdatas:getVersion()
    return self.data["version"]
end


function needdatas:getLookfor()
    return self.data["lookfor"]
end


function needdatas:getInfo()
    return self.data["info"]
end


function needdatas:getTime()
    return self.data["time"]
end





return needdatas


