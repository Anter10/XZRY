local LinkActionData = class("LinkActionData",{})


function LinkActionData:ctor(data)
   self.data = data    
end


function LinkActionData:getId()
    return self.data["id"]
end


function LinkActionData:getName()
    return self.data["name"]
end


function LinkActionData:getSkill()
    return self.data["skill"]
end


function LinkActionData:getSkillinfo()
    return self.data["skillinfo"]
end


function LinkActionData:getArray()
    return self.data["array"]
end


function LinkActionData:getGroups()
    return self.data["groups"]
end


function LinkActionData:getCellposx()
    return self.data["cellposx"]
end


function LinkActionData:getRange()
    return self.data["range"]
end


function LinkActionData:getCuthptime()
    return self.data["cuthptime"]
end


function LinkActionData:getBeatackeffect()
    return self.data["beatackeffect"]
end


function LinkActionData:getActionlevel()
    return self.data["actionlevel"]
end


function LinkActionData:getHurtnumber()
    return self.data["hurtnumber"]
end


function LinkActionData:getGrowupeffecttype()
    return self.data["growupeffecttype"]
end


function LinkActionData:getUbattack()
    return self.data["ubattack"]
end


function LinkActionData:getSbattack()
    return self.data["sbattack"]
end


function LinkActionData:getLieground()
    return self.data["lieground"]
end


function LinkActionData:getSsbeattack()
    return self.data["ssbeattack"]
end


function LinkActionData:getCutlighteffs()
    return self.data["cutlighteffs"]
end


function LinkActionData:getIsspecialskill()
    return self.data["isspecialskill"]
end


function LinkActionData:getPlayspeed()
    return self.data["playspeed"]
end


function LinkActionData:getKeepattack()
    return self.data["keepattack"]
end


function LinkActionData:getEvethn()
    return self.data["evethn"]
end


function LinkActionData:getBeatkmusics()
    return self.data["beatkmusics"]
end


function LinkActionData:getBoomatkmusics()
    return self.data["boomatkmusics"]
end


function LinkActionData:getAtkmusics()
    return self.data["atkmusics"]
end





return LinkActionData


