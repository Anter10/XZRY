local TerritoryCellData = class("TerritoryCellData",{})


function TerritoryCellData:ctor(data)
   self.data = data    
end


function TerritoryCellData:getId()
    return self.data["id"]
end


function TerritoryCellData:getType()
    return self.data["type"]
end


function TerritoryCellData:getSpine()
    return self.data["spine"]
end


function TerritoryCellData:getInfo()
    return self.data["info"]
end


function TerritoryCellData:getImage()
    return self.data["image"]
end





return TerritoryCellData


