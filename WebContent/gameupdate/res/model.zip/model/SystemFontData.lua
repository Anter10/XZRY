local SystemFontData = class("SystemFontData",{})


function SystemFontData:ctor(data)
   self.data = data    
end


function SystemFontData:getId()
    return self.data["id"]
end


function SystemFontData:getLantype1()
    return self.data["lantype1"]
end


function SystemFontData:getLantype2()
    return self.data["lantype2"]
end


function SystemFontData:getInfo()
    return self.data["info"]
end


function SystemFontData:getLan1()
    return self.data["lan1"]
end


function SystemFontData:getLan2()
    return self.data["lan2"]
end





return SystemFontData


