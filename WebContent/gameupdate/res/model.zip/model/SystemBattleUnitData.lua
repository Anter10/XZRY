local SystemBattleUnitData = class("SystemBattleUnitData",{})


function SystemBattleUnitData:ctor(data)
   self.data = data    
end


function SystemBattleUnitData:getId()
    return self.data["id"]
end


function SystemBattleUnitData:getRolecgdir()
    return self.data["rolecgdir"]
end


function SystemBattleUnitData:getBeizhu()
    return self.data["beizhu"]
end


function SystemBattleUnitData:getName()
    return self.data["name"]
end


function SystemBattleUnitData:getRoleinfo()
    return self.data["roleinfo"]
end


function SystemBattleUnitData:getJgetid()
    return self.data["jgetid"]
end


function SystemBattleUnitData:getSgetid()
    return self.data["sgetid"]
end


function SystemBattleUnitData:getMaindid()
    return self.data["maindid"]
end


function SystemBattleUnitData:getWork()
    return self.data["work"]
end


function SystemBattleUnitData:getLevel()
    return self.data["level"]
end


function SystemBattleUnitData:getQuality()
    return self.data["quality"]
end


function SystemBattleUnitData:getComid()
    return self.data["comid"]
end


function SystemBattleUnitData:getLife()
    return self.data["life"]
end


function SystemBattleUnitData:getMoveunit()
    return self.data["moveunit"]
end


function SystemBattleUnitData:getCustomemoveunit()
    return self.data["customemoveunit"]
end


function SystemBattleUnitData:getBigattack()
    return self.data["bigattack"]
end


function SystemBattleUnitData:getPattack()
    return self.data["pattack"]
end


function SystemBattleUnitData:getMattack()
    return self.data["mattack"]
end


function SystemBattleUnitData:getPdef()
    return self.data["pdef"]
end


function SystemBattleUnitData:getMdef()
    return self.data["mdef"]
end


function SystemBattleUnitData:getBoomatk()
    return self.data["boomatk"]
end


function SystemBattleUnitData:getBoomhurt()
    return self.data["boomhurt"]
end


function SystemBattleUnitData:getSpeed()
    return self.data["speed"]
end


function SystemBattleUnitData:getPprotected()
    return self.data["pprotected"]
end


function SystemBattleUnitData:getMprotected()
    return self.data["mprotected"]
end


function SystemBattleUnitData:getSkills()
    return self.data["skills"]
end


function SystemBattleUnitData:getLeaderaction()
    return self.data["leaderaction"]
end


function SystemBattleUnitData:getFtf()
    return self.data["ftf"]
end


function SystemBattleUnitData:getBornneed()
    return self.data["bornneed"]
end


function SystemBattleUnitData:getF_stren()
    return self.data["f_stren"]
end


function SystemBattleUnitData:getF_need()
    return self.data["f_need"]
end


function SystemBattleUnitData:getTw_stren()
    return self.data["tw_stren"]
end


function SystemBattleUnitData:getTw_need()
    return self.data["tw_need"]
end


function SystemBattleUnitData:getTh_stren()
    return self.data["th_stren"]
end


function SystemBattleUnitData:getTh_need()
    return self.data["th_need"]
end


function SystemBattleUnitData:getFo_stren()
    return self.data["fo_stren"]
end


function SystemBattleUnitData:getFo_need()
    return self.data["fo_need"]
end


function SystemBattleUnitData:getFi_stren()
    return self.data["fi_stren"]
end


function SystemBattleUnitData:getFi_need()
    return self.data["fi_need"]
end


function SystemBattleUnitData:getOriginalname()
    return self.data["originalname"]
end


function SystemBattleUnitData:getRownumber()
    return self.data["rownumber"]
end


function SystemBattleUnitData:getColumnnumber()
    return self.data["columnnumber"]
end


function SystemBattleUnitData:getMovesinglecelltime()
    return self.data["movesinglecelltime"]
end


function SystemBattleUnitData:getRolewidth()
    return self.data["rolewidth"]
end


function SystemBattleUnitData:getRolehight()
    return self.data["rolehight"]
end


function SystemBattleUnitData:getRolezoomsize()
    return self.data["rolezoomsize"]
end


function SystemBattleUnitData:getAttackmovetime()
    return self.data["attackmovetime"]
end


function SystemBattleUnitData:getAccessoryparts()
    return self.data["accessoryparts"]
end


function SystemBattleUnitData:getBluetype()
    return self.data["bluetype"]
end


function SystemBattleUnitData:getHeadhight()
    return self.data["headhight"]
end


function SystemBattleUnitData:getRoleress()
    return self.data["roleress"]
end


function SystemBattleUnitData:getAlertpos()
    return self.data["alertpos"]
end


function SystemBattleUnitData:getBeattackpos()
    return self.data["beattackpos"]
end


function SystemBattleUnitData:getSpinefile()
    return self.data["spinefile"]
end


function SystemBattleUnitData:getCgspine()
    return self.data["cgspine"]
end


function SystemBattleUnitData:getCgbackground()
    return self.data["cgbackground"]
end


function SystemBattleUnitData:getIcon()
    return self.data["icon"]
end


function SystemBattleUnitData:getUiheadgreyname()
    return self.data["uiheadgreyname"]
end


function SystemBattleUnitData:getStoppos()
    return self.data["stoppos"]
end


function SystemBattleUnitData:getStartlevel()
    return self.data["startlevel"]
end


function SystemBattleUnitData:getSkillatktype()
    return self.data["skillatktype"]
end


function SystemBattleUnitData:getRprel()
    return self.data["rprel"]
end


function SystemBattleUnitData:getRaftl()
    return self.data["raftl"]
end


function SystemBattleUnitData:getNsicon()
    return self.data["nsicon"]
end


function SystemBattleUnitData:getPostype()
    return self.data["postype"]
end


function SystemBattleUnitData:getMainspine()
    return self.data["mainspine"]
end


function SystemBattleUnitData:getMainshadow()
    return self.data["mainshadow"]
end


function SystemBattleUnitData:getMainlightpos()
    return self.data["mainlightpos"]
end


function SystemBattleUnitData:getMainshadowpos()
    return self.data["mainshadowpos"]
end


function SystemBattleUnitData:getMainrolemusic()
    return self.data["mainrolemusic"]
end


function SystemBattleUnitData:getRolewhtype()
    return self.data["rolewhtype"]
end


function SystemBattleUnitData:getBmatkmusic()
    return self.data["bmatkmusic"]
end


function SystemBattleUnitData:getMainchangecolourpng()
    return self.data["mainchangecolourpng"]
end


function SystemBattleUnitData:getCgposxy()
    return self.data["cgposxy"]
end


function SystemBattleUnitData:getRolecgpyy()
    return self.data["rolecgpyy"]
end





return SystemBattleUnitData


