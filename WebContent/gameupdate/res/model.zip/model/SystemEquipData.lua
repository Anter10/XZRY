local SystemEquipData = class("SystemEquipData",{})


function SystemEquipData:ctor(data)
   self.data = data    
end


function SystemEquipData:getId()
    return self.data["id"]
end


function SystemEquipData:getName()
    return self.data["name"]
end


function SystemEquipData:getLevel()
    return self.data["level"]
end


function SystemEquipData:getPart()
    return self.data["part"]
end


function SystemEquipData:getWork()
    return self.data["work"]
end


function SystemEquipData:getRole()
    return self.data["role"]
end


function SystemEquipData:getBaseproperty()
    return self.data["baseproperty"]
end


function SystemEquipData:getValue()
    return self.data["value"]
end


function SystemEquipData:getEquipinfo()
    return self.data["equipinfo"]
end


function SystemEquipData:getEnglishname()
    return self.data["englishname"]
end


function SystemEquipData:getEquipenglishinfo()
    return self.data["equipenglishinfo"]
end


function SystemEquipData:getPrice()
    return self.data["price"]
end


function SystemEquipData:getExperience()
    return self.data["experience"]
end





return SystemEquipData


