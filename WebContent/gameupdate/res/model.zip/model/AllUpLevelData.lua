local AllUpLevelData = class("AllUpLevelData",{})


function AllUpLevelData:ctor(data)
   self.data = data    
end


function AllUpLevelData:getId()
    return self.data["id"]
end


function AllUpLevelData:getHeroexp()
    return self.data["heroexp"]
end


function AllUpLevelData:getRoleexp()
    return self.data["roleexp"]
end





return AllUpLevelData


