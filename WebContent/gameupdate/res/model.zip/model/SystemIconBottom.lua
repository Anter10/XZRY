local SystemIconBottom = class("SystemIconBottom",{})


function SystemIconBottom:ctor(data)
   self.data = data    
end


function SystemIconBottom:getId()
    return self.data["id"]
end


function SystemIconBottom:getName()
    return self.data["name"]
end


function SystemIconBottom:getRes()
    return self.data["res"]
end


function SystemIconBottom:getPrice()
    return self.data["price"]
end


function SystemIconBottom:getOpenlevel()
    return self.data["openlevel"]
end


function SystemIconBottom:getInfo()
    return self.data["info"]
end





return SystemIconBottom


