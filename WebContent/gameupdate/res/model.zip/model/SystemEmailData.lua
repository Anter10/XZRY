local SystemEmailData = class("SystemEmailData",{})


function SystemEmailData:ctor(data)
   self.data = data    
end


function SystemEmailData:getId()
    return self.data["id"]
end


function SystemEmailData:getType()
    return self.data["type"]
end


function SystemEmailData:getName()
    return self.data["name"]
end


function SystemEmailData:getOriginalname()
    return self.data["originalname"]
end





return SystemEmailData


