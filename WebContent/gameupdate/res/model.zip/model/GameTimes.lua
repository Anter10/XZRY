local GameTimes = class("GameTimes",{})


function GameTimes:ctor(data)
   self.data = data    
end


function GameTimes:getId()
    return self.data["id"]
end


function GameTimes:getValue()
    return self.data["value"]
end


function GameTimes:getInfo()
    return self.data["info"]
end





return GameTimes


