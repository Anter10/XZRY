local SystemIconFramData = class("SystemIconFramData",{})


function SystemIconFramData:ctor(data)
   self.data = data    
end


function SystemIconFramData:getId()
    return self.data["id"]
end


function SystemIconFramData:getName()
    return self.data["name"]
end


function SystemIconFramData:getRes()
    return self.data["res"]
end


function SystemIconFramData:getPrice()
    return self.data["price"]
end


function SystemIconFramData:getOpenlevel()
    return self.data["openlevel"]
end


function SystemIconFramData:getInfo()
    return self.data["info"]
end





return SystemIconFramData


