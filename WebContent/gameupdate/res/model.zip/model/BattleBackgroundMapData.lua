local BattleBackgroundMapData = class("BattleBackgroundMapData",{})


function BattleBackgroundMapData:ctor(data)
   self.data = data    
end


function BattleBackgroundMapData:getId()
    return self.data["id"]
end


function BattleBackgroundMapData:getBattlemapfile()
    return self.data["battlemapfile"]
end





return BattleBackgroundMapData


