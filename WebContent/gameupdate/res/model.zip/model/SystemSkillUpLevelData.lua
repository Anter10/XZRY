local SystemSkillUpLevelData = class("SystemSkillUpLevelData",{})


function SystemSkillUpLevelData:ctor(data)
   self.data = data    
end


function SystemSkillUpLevelData:getId()
    return self.data["id"]
end


function SystemSkillUpLevelData:getSkillid()
    return self.data["skillid"]
end


function SystemSkillUpLevelData:getLevel()
    return self.data["level"]
end


function SystemSkillUpLevelData:getUpinfo()
    return self.data["upinfo"]
end


function SystemSkillUpLevelData:getNeeditems()
    return self.data["needitems"]
end





return SystemSkillUpLevelData


