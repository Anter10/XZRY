local SystemMapChapterTask = class("SystemMapChapterTask",{})


function SystemMapChapterTask:ctor(data)
   self.data = data    
end


function SystemMapChapterTask:getId()
    return self.data["id"]
end


function SystemMapChapterTask:getF_task_have()
    return self.data["f_task_have"]
end


function SystemMapChapterTask:getF_task_kill_class()
    return self.data["f_task_kill_class"]
end


function SystemMapChapterTask:getF_task_kill_how()
    return self.data["f_task_kill_how"]
end


function SystemMapChapterTask:getF_task_kill_who()
    return self.data["f_task_kill_who"]
end


function SystemMapChapterTask:getF_task_fund_sth()
    return self.data["f_task_fund_sth"]
end


function SystemMapChapterTask:getF_task_fund_who()
    return self.data["f_task_fund_who"]
end


function SystemMapChapterTask:getF_task_chess()
    return self.data["f_task_chess"]
end


function SystemMapChapterTask:getF_task_chess_room()
    return self.data["f_task_chess_room"]
end


function SystemMapChapterTask:getF_task_mapitem()
    return self.data["f_task_mapitem"]
end


function SystemMapChapterTask:getF_task_mapitem_room()
    return self.data["f_task_mapitem_room"]
end


function SystemMapChapterTask:getF_task_dropitem()
    return self.data["f_task_dropitem"]
end


function SystemMapChapterTask:getF_task_clear_chess()
    return self.data["f_task_clear_chess"]
end


function SystemMapChapterTask:getF_task_clear_mapitem()
    return self.data["f_task_clear_mapitem"]
end


function SystemMapChapterTask:getF_task_clear_dropitem()
    return self.data["f_task_clear_dropitem"]
end


function SystemMapChapterTask:getF_task_start_plot()
    return self.data["f_task_start_plot"]
end


function SystemMapChapterTask:getF_task_start_sound()
    return self.data["f_task_start_sound"]
end


function SystemMapChapterTask:getF_task_start_music()
    return self.data["f_task_start_music"]
end


function SystemMapChapterTask:getF_task_clear_plot()
    return self.data["f_task_clear_plot"]
end


function SystemMapChapterTask:getF_task_clear_sound()
    return self.data["f_task_clear_sound"]
end


function SystemMapChapterTask:getF_task_clear_music()
    return self.data["f_task_clear_music"]
end


function SystemMapChapterTask:getF_task_clear_task()
    return self.data["f_task_clear_task"]
end





return SystemMapChapterTask


