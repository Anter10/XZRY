local BattleRoleSpecialGrowup = class("BattleRoleSpecialGrowup",{})


function BattleRoleSpecialGrowup:ctor(data)
   self.data = data    
end


function BattleRoleSpecialGrowup:getId()
    return self.data["id"]
end


function BattleRoleSpecialGrowup:getName()
    return self.data["name"]
end


function BattleRoleSpecialGrowup:getEfx()
    return self.data["efx"]
end


function BattleRoleSpecialGrowup:getEfx_nodes()
    return self.data["efx_nodes"]
end


function BattleRoleSpecialGrowup:getStartani()
    return self.data["startani"]
end


function BattleRoleSpecialGrowup:getLoopani()
    return self.data["loopani"]
end


function BattleRoleSpecialGrowup:getEndani()
    return self.data["endani"]
end


function BattleRoleSpecialGrowup:getRoom()
    return self.data["room"]
end


function BattleRoleSpecialGrowup:getIsdirection()
    return self.data["isdirection"]
end


function BattleRoleSpecialGrowup:getIsfollow()
    return self.data["isfollow"]
end


function BattleRoleSpecialGrowup:getLayertype()
    return self.data["layertype"]
end


function BattleRoleSpecialGrowup:getLayerzorder()
    return self.data["layerzorder"]
end


function BattleRoleSpecialGrowup:getXypos()
    return self.data["xypos"]
end


function BattleRoleSpecialGrowup:getDelaytimes()
    return self.data["delaytimes"]
end


function BattleRoleSpecialGrowup:getRemefe()
    return self.data["remefe"]
end


function BattleRoleSpecialGrowup:getStrikeoe()
    return self.data["strikeoe"]
end


function BattleRoleSpecialGrowup:getStrikesoltnodes()
    return self.data["strikesoltnodes"]
end





return BattleRoleSpecialGrowup


