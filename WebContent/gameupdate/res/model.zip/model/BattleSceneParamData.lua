local BattleSceneParamData = class("BattleSceneParamData",{})


function BattleSceneParamData:ctor(data)
   self.data = data    
end


function BattleSceneParamData:getId()
    return self.data["id"]
end


function BattleSceneParamData:getSceneWidth()
    return self.data["sceneWidth"]
end


function BattleSceneParamData:getSceneheight()
    return self.data["sceneheight"]
end


function BattleSceneParamData:getCellLeftPadding()
    return self.data["cellLeftPadding"]
end


function BattleSceneParamData:getCellBottomPadding()
    return self.data["cellBottomPadding"]
end


function BattleSceneParamData:getCellHeight()
    return self.data["cellHeight"]
end


function BattleSceneParamData:getCellWidth()
    return self.data["cellWidth"]
end


function BattleSceneParamData:getCellRow()
    return self.data["cellRow"]
end


function BattleSceneParamData:getCellColumn()
    return self.data["cellColumn"]
end


function BattleSceneParamData:getBackgroundMoveSpeed()
    return self.data["backgroundMoveSpeed"]
end


function BattleSceneParamData:getBackPlayerRoleViewTime()
    return self.data["backPlayerRoleViewTime"]
end


function BattleSceneParamData:getBackgroundStartMoveDistance()
    return self.data["backgroundStartMoveDistance"]
end


function BattleSceneParamData:getIconMaxNum()
    return self.data["iconMaxNum"]
end


function BattleSceneParamData:getMapname()
    return self.data["mapname"]
end


function BattleSceneParamData:getBufficonmaxnum()
    return self.data["bufficonmaxnum"]
end


function BattleSceneParamData:getAmmunitionmaxnum()
    return self.data["ammunitionmaxnum"]
end





return BattleSceneParamData


