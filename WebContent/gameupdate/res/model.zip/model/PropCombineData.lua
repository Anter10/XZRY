local PropCombineData = class("PropCombineData",{})


function PropCombineData:ctor(data)
   self.data = data    
end


function PropCombineData:getId()
    return self.data["id"]
end


function PropCombineData:getName()
    return self.data["name"]
end


function PropCombineData:getElevel()
    return self.data["elevel"]
end


function PropCombineData:getMoney_type()
    return self.data["money_type"]
end


function PropCombineData:getMoney_num()
    return self.data["money_num"]
end


function PropCombineData:getCustomes()
    return self.data["customes"]
end


function PropCombineData:getCustomes_num()
    return self.data["customes_num"]
end


function PropCombineData:getGet_num()
    return self.data["get_num"]
end





return PropCombineData


