local SystemBuyDiamondData = class("SystemBuyDiamondData",{})


function SystemBuyDiamondData:ctor(data)
   self.data = data    
end


function SystemBuyDiamondData:getId()
    return self.data["id"]
end


function SystemBuyDiamondData:getName()
    return self.data["name"]
end


function SystemBuyDiamondData:getPrice()
    return self.data["price"]
end


function SystemBuyDiamondData:getBuynum()
    return self.data["buynum"]
end


function SystemBuyDiamondData:getSend()
    return self.data["send"]
end


function SystemBuyDiamondData:getType()
    return self.data["type"]
end


function SystemBuyDiamondData:getIcon()
    return self.data["icon"]
end





return SystemBuyDiamondData


