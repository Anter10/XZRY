local Systemdataring = class("Systemdataring",{})


function Systemdataring:ctor(data)
   self.data = data    
end


function Systemdataring:getId()
    return self.data["id"]
end


function Systemdataring:getNw0()
    return self.data["nw0"]
end


function Systemdataring:getNw1()
    return self.data["nw1"]
end


function Systemdataring:getNw2()
    return self.data["nw2"]
end


function Systemdataring:getNw3()
    return self.data["nw3"]
end


function Systemdataring:getNw4()
    return self.data["nw4"]
end


function Systemdataring:getNw5()
    return self.data["nw5"]
end


function Systemdataring:getNb0()
    return self.data["nb0"]
end


function Systemdataring:getNb1()
    return self.data["nb1"]
end


function Systemdataring:getNb2()
    return self.data["nb2"]
end


function Systemdataring:getNb3()
    return self.data["nb3"]
end


function Systemdataring:getNb4()
    return self.data["nb4"]
end


function Systemdataring:getNb5()
    return self.data["nb5"]
end


function Systemdataring:getNp0()
    return self.data["np0"]
end


function Systemdataring:getNp1()
    return self.data["np1"]
end


function Systemdataring:getNp2()
    return self.data["np2"]
end


function Systemdataring:getNp3()
    return self.data["np3"]
end


function Systemdataring:getNp4()
    return self.data["np4"]
end


function Systemdataring:getNp5()
    return self.data["np5"]
end


function Systemdataring:getNo0()
    return self.data["no0"]
end


function Systemdataring:getNo1()
    return self.data["no1"]
end


function Systemdataring:getNo2()
    return self.data["no2"]
end


function Systemdataring:getNo3()
    return self.data["no3"]
end


function Systemdataring:getNo4()
    return self.data["no4"]
end


function Systemdataring:getNo5()
    return self.data["no5"]
end





return Systemdataring


