local SystemShopTypeData = class("SystemShopTypeData",{})


function SystemShopTypeData:ctor(data)
   self.data = data    
end


function SystemShopTypeData:getId()
    return self.data["id"]
end


function SystemShopTypeData:getType()
    return self.data["type"]
end


function SystemShopTypeData:getShopname()
    return self.data["shopname"]
end


function SystemShopTypeData:getOpenlevel()
    return self.data["openlevel"]
end


function SystemShopTypeData:getInfo()
    return self.data["info"]
end





return SystemShopTypeData


