local AllDialogData = class("AllDialogData",{})


function AllDialogData:ctor(data)
   self.data = data    
end


function AllDialogData:getId()
    return self.data["id"]
end


function AllDialogData:getBeizhu()
    return self.data["beizhu"]
end


function AllDialogData:getWord1()
    return self.data["word1"]
end


function AllDialogData:getWord2()
    return self.data["word2"]
end


function AllDialogData:getShowtype1()
    return self.data["showtype1"]
end


function AllDialogData:getShowtype2()
    return self.data["showtype2"]
end





return AllDialogData


