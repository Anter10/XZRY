local Systemdatanecklace = class("Systemdatanecklace",{})


function Systemdatanecklace:ctor(data)
   self.data = data    
end


function Systemdatanecklace:getId()
    return self.data["id"]
end


function Systemdatanecklace:getNw0()
    return self.data["nw0"]
end


function Systemdatanecklace:getNw1()
    return self.data["nw1"]
end


function Systemdatanecklace:getNw2()
    return self.data["nw2"]
end


function Systemdatanecklace:getNw3()
    return self.data["nw3"]
end


function Systemdatanecklace:getNw4()
    return self.data["nw4"]
end


function Systemdatanecklace:getNw5()
    return self.data["nw5"]
end


function Systemdatanecklace:getNb0()
    return self.data["nb0"]
end


function Systemdatanecklace:getNb1()
    return self.data["nb1"]
end


function Systemdatanecklace:getNb2()
    return self.data["nb2"]
end


function Systemdatanecklace:getNb3()
    return self.data["nb3"]
end


function Systemdatanecklace:getNb4()
    return self.data["nb4"]
end


function Systemdatanecklace:getNb5()
    return self.data["nb5"]
end


function Systemdatanecklace:getNp0()
    return self.data["np0"]
end


function Systemdatanecklace:getNp1()
    return self.data["np1"]
end


function Systemdatanecklace:getNp2()
    return self.data["np2"]
end


function Systemdatanecklace:getNp3()
    return self.data["np3"]
end


function Systemdatanecklace:getNp4()
    return self.data["np4"]
end


function Systemdatanecklace:getNp5()
    return self.data["np5"]
end


function Systemdatanecklace:getNo0()
    return self.data["no0"]
end


function Systemdatanecklace:getNo1()
    return self.data["no1"]
end


function Systemdatanecklace:getNo2()
    return self.data["no2"]
end


function Systemdatanecklace:getNo3()
    return self.data["no3"]
end


function Systemdatanecklace:getNo4()
    return self.data["no4"]
end


function Systemdatanecklace:getNo5()
    return self.data["no5"]
end





return Systemdatanecklace


