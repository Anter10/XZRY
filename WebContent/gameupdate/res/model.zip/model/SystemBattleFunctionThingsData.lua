local SystemBattleFunctionThingsData = class("SystemBattleFunctionThingsData",{})


function SystemBattleFunctionThingsData:ctor(data)
   self.data = data    
end


function SystemBattleFunctionThingsData:getId()
    return self.data["id"]
end


function SystemBattleFunctionThingsData:getIconfile()
    return self.data["iconfile"]
end


function SystemBattleFunctionThingsData:getSpinefile()
    return self.data["spinefile"]
end


function SystemBattleFunctionThingsData:getName()
    return self.data["name"]
end


function SystemBattleFunctionThingsData:getDescribe()
    return self.data["describe"]
end


function SystemBattleFunctionThingsData:getType()
    return self.data["type"]
end


function SystemBattleFunctionThingsData:getThingswidth()
    return self.data["thingswidth"]
end


function SystemBattleFunctionThingsData:getThingsheight()
    return self.data["thingsheight"]
end


function SystemBattleFunctionThingsData:getHp()
    return self.data["hp"]
end


function SystemBattleFunctionThingsData:getPossesspos()
    return self.data["possesspos"]
end





return SystemBattleFunctionThingsData


