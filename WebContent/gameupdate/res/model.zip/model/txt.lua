local txt = class("txt",{})


function txt:ctor(data)
   self.data = data    
end


function txt:getId()
    return self.data["id"]
end


function txt:getName()
    return self.data["name"]
end





return txt


