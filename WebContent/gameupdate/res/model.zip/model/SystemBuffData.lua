local SystemBuffData = class("SystemBuffData",{})


function SystemBuffData:ctor(data)
   self.data = data    
end


function SystemBuffData:getId()
    return self.data["id"]
end


function SystemBuffData:getName()
    return self.data["name"]
end


function SystemBuffData:getInfo()
    return self.data["info"]
end


function SystemBuffData:getCondition()
    return self.data["condition"]
end


function SystemBuffData:getOtherbuff()
    return self.data["otherbuff"]
end


function SystemBuffData:getTarget()
    return self.data["target"]
end


function SystemBuffData:getMaxlayer()
    return self.data["maxlayer"]
end


function SystemBuffData:getKeeptime()
    return self.data["keeptime"]
end


function SystemBuffData:getJumpnum()
    return self.data["jumpnum"]
end


function SystemBuffData:getEveryjumptime()
    return self.data["everyjumptime"]
end


function SystemBuffData:getCanclear()
    return self.data["canclear"]
end


function SystemBuffData:getCanrepeate()
    return self.data["canrepeate"]
end


function SystemBuffData:getCanreplace()
    return self.data["canreplace"]
end


function SystemBuffData:getCanadd()
    return self.data["canadd"]
end


function SystemBuffData:getEffecttype()
    return self.data["effecttype"]
end


function SystemBuffData:getEffectvalue()
    return self.data["effectvalue"]
end


function SystemBuffData:getEfectuplevel()
    return self.data["efectuplevel"]
end


function SystemBuffData:getIcon()
    return self.data["icon"]
end


function SystemBuffData:getHpbaricon()
    return self.data["hpbaricon"]
end


function SystemBuffData:getHasinspireeffect()
    return self.data["hasinspireeffect"]
end


function SystemBuffData:getInspireeffectid()
    return self.data["inspireeffectid"]
end


function SystemBuffData:getEffectid()
    return self.data["effectid"]
end


function SystemBuffData:getFirsteffect()
    return self.data["firsteffect"]
end


function SystemBuffData:getAllbattleunique()
    return self.data["allbattleunique"]
end


function SystemBuffData:getAddorcut()
    return self.data["addorcut"]
end


function SystemBuffData:getEffectnpc()
    return self.data["effectnpc"]
end


function SystemBuffData:getSmallicon()
    return self.data["smallicon"]
end


function SystemBuffData:getEffectmusic()
    return self.data["effectmusic"]
end


function SystemBuffData:getKeepmusic()
    return self.data["keepmusic"]
end


function SystemBuffData:getMusiceffect()
    return self.data["musiceffect"]
end





return SystemBuffData


