local SystemOnlyUiTextData = class("SystemOnlyUiTextData",{})


function SystemOnlyUiTextData:ctor(data)
   self.data = data    
end


function SystemOnlyUiTextData:getId()
    return self.data["id"]
end


function SystemOnlyUiTextData:getInfo()
    return self.data["info"]
end


function SystemOnlyUiTextData:getWord1()
    return self.data["word1"]
end


function SystemOnlyUiTextData:getWord2()
    return self.data["word2"]
end





return SystemOnlyUiTextData


