local RolesAllDialogData = class("RolesAllDialogData",{})


function RolesAllDialogData:ctor(data)
   self.data = data    
end


function RolesAllDialogData:getId()
    return self.data["id"]
end


function RolesAllDialogData:getBeizhu()
    return self.data["beizhu"]
end


function RolesAllDialogData:getUiid()
    return self.data["uiid"]
end


function RolesAllDialogData:getRoles()
    return self.data["roles"]
end


function RolesAllDialogData:getInitroles()
    return self.data["initroles"]
end


function RolesAllDialogData:getDialog()
    return self.data["dialog"]
end





return RolesAllDialogData


