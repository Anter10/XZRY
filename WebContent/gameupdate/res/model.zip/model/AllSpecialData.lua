local AllSpecialData = class("AllSpecialData",{})


function AllSpecialData:ctor(data)
   self.data = data    
end


function AllSpecialData:getId()
    return self.data["id"]
end


function AllSpecialData:getResname()
    return self.data["resname"]
end


function AllSpecialData:getName()
    return self.data["name"]
end


function AllSpecialData:getInfo()
    return self.data["info"]
end





return AllSpecialData


