local ProperityEffectData = class("ProperityEffectData",{})


function ProperityEffectData:ctor(data)
   self.data = data    
end


function ProperityEffectData:getId()
    return self.data["id"]
end


function ProperityEffectData:getInfo()
    return self.data["info"]
end





return ProperityEffectData


