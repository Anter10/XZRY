local SystemEmailTypeData = class("SystemEmailTypeData",{})


function SystemEmailTypeData:ctor(data)
   self.data = data    
end


function SystemEmailTypeData:getId()
    return self.data["id"]
end


function SystemEmailTypeData:getType()
    return self.data["type"]
end


function SystemEmailTypeData:getName()
    return self.data["name"]
end


function SystemEmailTypeData:getOriginalname()
    return self.data["originalname"]
end


function SystemEmailTypeData:getOpenlevel()
    return self.data["openlevel"]
end


function SystemEmailTypeData:getInfo()
    return self.data["info"]
end





return SystemEmailTypeData


