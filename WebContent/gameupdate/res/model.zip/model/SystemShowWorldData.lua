local SystemShowWorldData = class("SystemShowWorldData",{})


function SystemShowWorldData:ctor(data)
   self.data = data    
end


function SystemShowWorldData:getId()
    return self.data["id"]
end


function SystemShowWorldData:getInfo()
    return self.data["info"]
end


function SystemShowWorldData:getWord1()
    return self.data["word1"]
end


function SystemShowWorldData:getWord2()
    return self.data["word2"]
end


function SystemShowWorldData:getShowtype1()
    return self.data["showtype1"]
end


function SystemShowWorldData:getShowtype2()
    return self.data["showtype2"]
end





return SystemShowWorldData


