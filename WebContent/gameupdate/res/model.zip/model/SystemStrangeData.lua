local SystemStrangeData = class("SystemStrangeData",{})


function SystemStrangeData:ctor(data)
   self.data = data    
end


function SystemStrangeData:getId()
    return self.data["id"]
end


function SystemStrangeData:getName()
    return self.data["name"]
end


function SystemStrangeData:getChange_cost()
    return self.data["change_cost"]
end


function SystemStrangeData:getProperty()
    return self.data["property"]
end


function SystemStrangeData:getInfo()
    return self.data["info"]
end





return SystemStrangeData


