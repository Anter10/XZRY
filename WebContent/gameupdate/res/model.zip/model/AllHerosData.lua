local AllHerosData = class("AllHerosData",{})


function AllHerosData:ctor(data)
   self.data = data    
end


function AllHerosData:getId()
    return self.data["id"]
end


function AllHerosData:getHeroids()
    return self.data["heroids"]
end





return AllHerosData


