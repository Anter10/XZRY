local RoleSuitData = class("RoleSuitData",{})


function RoleSuitData:ctor(data)
   self.data = data    
end


function RoleSuitData:getId()
    return self.data["id"]
end


function RoleSuitData:getProperty()
    return self.data["property"]
end


function RoleSuitData:getValue()
    return self.data["value"]
end


function RoleSuitData:getEffect()
    return self.data["effect"]
end


function RoleSuitData:getSuitgrowup()
    return self.data["suitgrowup"]
end





return RoleSuitData


