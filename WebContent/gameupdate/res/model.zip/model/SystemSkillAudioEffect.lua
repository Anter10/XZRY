local SystemSkillAudioEffect = class("SystemSkillAudioEffect",{})


function SystemSkillAudioEffect:ctor(data)
   self.data = data    
end


function SystemSkillAudioEffect:getId()
    return self.data["id"]
end


function SystemSkillAudioEffect:getInfo()
    return self.data["info"]
end


function SystemSkillAudioEffect:getRoleid()
    return self.data["roleid"]
end


function SystemSkillAudioEffect:getSkillid()
    return self.data["skillid"]
end


function SystemSkillAudioEffect:getFilename()
    return self.data["filename"]
end


function SystemSkillAudioEffect:getLooptime()
    return self.data["looptime"]
end





return SystemSkillAudioEffect


