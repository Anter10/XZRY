local SystemSkillData = class("SystemSkillData",{})


function SystemSkillData:ctor(data)
   self.data = data    
end


function SystemSkillData:getId()
    return self.data["id"]
end


function SystemSkillData:getRole()
    return self.data["role"]
end


function SystemSkillData:getName()
    return self.data["name"]
end


function SystemSkillData:getInfo()
    return self.data["info"]
end


function SystemSkillData:getType()
    return self.data["type"]
end


function SystemSkillData:getUseof()
    return self.data["useof"]
end


function SystemSkillData:getCustome()
    return self.data["custome"]
end


function SystemSkillData:getOutput()
    return self.data["output"]
end


function SystemSkillData:getTarget()
    return self.data["target"]
end


function SystemSkillData:getClickmethod()
    return self.data["clickmethod"]
end


function SystemSkillData:getOriginalpoint()
    return self.data["originalpoint"]
end


function SystemSkillData:getCanselectrange()
    return self.data["canselectrange"]
end


function SystemSkillData:getEffectrange()
    return self.data["effectrange"]
end


function SystemSkillData:getStoreround()
    return self.data["storeround"]
end


function SystemSkillData:getCd()
    return self.data["cd"]
end


function SystemSkillData:getSonskillorbuff()
    return self.data["sonskillorbuff"]
end


function SystemSkillData:getIcon()
    return self.data["icon"]
end


function SystemSkillData:getIcon1()
    return self.data["icon1"]
end


function SystemSkillData:getStarteffectid()
    return self.data["starteffectid"]
end


function SystemSkillData:getActionid()
    return self.data["actionid"]
end


function SystemSkillData:getPre_start()
    return self.data["pre_start"]
end


function SystemSkillData:getChangexy()
    return self.data["changexy"]
end


function SystemSkillData:getFlyspeed()
    return self.data["flyspeed"]
end


function SystemSkillData:getMusiceffect()
    return self.data["musiceffect"]
end


function SystemSkillData:getMaxlevel()
    return self.data["maxlevel"]
end


function SystemSkillData:getSkilleffecttype()
    return self.data["skilleffecttype"]
end


function SystemSkillData:getSkillatktype()
    return self.data["skillatktype"]
end


function SystemSkillData:getLiedowncanattack()
    return self.data["liedowncanattack"]
end


function SystemSkillData:getFirstfinish()
    return self.data["firstfinish"]
end


function SystemSkillData:getOpenlevels()
    return self.data["openlevels"]
end


function SystemSkillData:getUp_money_num()
    return self.data["up_money_num"]
end


function SystemSkillData:getUp_need_items1()
    return self.data["up_need_items1"]
end


function SystemSkillData:getUp_need_items2()
    return self.data["up_need_items2"]
end


function SystemSkillData:getSkillbpos()
    return self.data["skillbpos"]
end


function SystemSkillData:getIsfirst()
    return self.data["isfirst"]
end


function SystemSkillData:getKeepattack()
    return self.data["keepattack"]
end


function SystemSkillData:getIsnear()
    return self.data["isnear"]
end


function SystemSkillData:getPreparemusic()
    return self.data["preparemusic"]
end


function SystemSkillData:getCancelreleasemusic()
    return self.data["cancelreleasemusic"]
end





return SystemSkillData


