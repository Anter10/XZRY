local SystemSpecialSkillData = class("SystemSpecialSkillData",{})


function SystemSpecialSkillData:ctor(data)
   self.data = data    
end


function SystemSpecialSkillData:getId()
    return self.data["id"]
end


function SystemSpecialSkillData:getRole()
    return self.data["role"]
end


function SystemSpecialSkillData:getName()
    return self.data["name"]
end


function SystemSpecialSkillData:getInfo()
    return self.data["info"]
end


function SystemSpecialSkillData:getType()
    return self.data["type"]
end


function SystemSpecialSkillData:getUseof()
    return self.data["useof"]
end


function SystemSpecialSkillData:getEffectrange()
    return self.data["effectrange"]
end


function SystemSpecialSkillData:getPhurt()
    return self.data["phurt"]
end


function SystemSpecialSkillData:getMhurt()
    return self.data["mhurt"]
end


function SystemSpecialSkillData:getSelfbuff()
    return self.data["selfbuff"]
end


function SystemSpecialSkillData:getEnemybuff()
    return self.data["enemybuff"]
end


function SystemSpecialSkillData:getIcon()
    return self.data["icon"]
end


function SystemSpecialSkillData:getIcon1()
    return self.data["icon1"]
end


function SystemSpecialSkillData:getStarteffect()
    return self.data["starteffect"]
end


function SystemSpecialSkillData:getSameef()
    return self.data["sameef"]
end


function SystemSpecialSkillData:getDiffef()
    return self.data["diffef"]
end


function SystemSpecialSkillData:getActionname()
    return self.data["actionname"]
end


function SystemSpecialSkillData:getPreopen()
    return self.data["preopen"]
end


function SystemSpecialSkillData:getHasmove()
    return self.data["hasmove"]
end


function SystemSpecialSkillData:getFlyspeed()
    return self.data["flyspeed"]
end


function SystemSpecialSkillData:getOpenmusicef()
    return self.data["openmusicef"]
end


function SystemSpecialSkillData:getMaxlevel()
    return self.data["maxlevel"]
end


function SystemSpecialSkillData:getAitype()
    return self.data["aitype"]
end


function SystemSpecialSkillData:getIsnearopen()
    return self.data["isnearopen"]
end


function SystemSpecialSkillData:getLiedowncanattack()
    return self.data["liedowncanattack"]
end


function SystemSpecialSkillData:getFirstfinish()
    return self.data["firstfinish"]
end


function SystemSpecialSkillData:getOpenlevels()
    return self.data["openlevels"]
end


function SystemSpecialSkillData:getUp_money_num()
    return self.data["up_money_num"]
end


function SystemSpecialSkillData:getUp_need_items1()
    return self.data["up_need_items1"]
end


function SystemSpecialSkillData:getUp_need_items2()
    return self.data["up_need_items2"]
end





return SystemSpecialSkillData


