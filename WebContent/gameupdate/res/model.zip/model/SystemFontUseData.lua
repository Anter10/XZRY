local SystemFontUseData = class("SystemFontUseData",{})


function SystemFontUseData:ctor(data)
   self.data = data    
end


function SystemFontUseData:getId()
    return self.data["id"]
end


function SystemFontUseData:getSign()
    return self.data["sign"]
end


function SystemFontUseData:getInfo()
    return self.data["info"]
end





return SystemFontUseData


