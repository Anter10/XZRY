local SystemChatTypeData = class("SystemChatTypeData",{})


function SystemChatTypeData:ctor(data)
   self.data = data    
end


function SystemChatTypeData:getId()
    return self.data["id"]
end


function SystemChatTypeData:getName()
    return self.data["name"]
end


function SystemChatTypeData:getOriginalname()
    return self.data["originalname"]
end


function SystemChatTypeData:getOpen_level()
    return self.data["open_level"]
end


function SystemChatTypeData:getCan_reverse()
    return self.data["can_reverse"]
end





return SystemChatTypeData


