local SystemGameMusic = class("SystemGameMusic",{})


function SystemGameMusic:ctor(data)
   self.data = data    
end


function SystemGameMusic:getId()
    return self.data["id"]
end


function SystemGameMusic:getInfo()
    return self.data["info"]
end


function SystemGameMusic:getLoop()
    return self.data["loop"]
end


function SystemGameMusic:getLoopnum()
    return self.data["loopnum"]
end


function SystemGameMusic:getLooptype()
    return self.data["looptype"]
end


function SystemGameMusic:getFilename()
    return self.data["filename"]
end





return SystemGameMusic


