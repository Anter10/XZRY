local Systemdataarmor = class("Systemdataarmor",{})


function Systemdataarmor:ctor(data)
   self.data = data    
end


function Systemdataarmor:getId()
    return self.data["id"]
end


function Systemdataarmor:getNw0()
    return self.data["nw0"]
end


function Systemdataarmor:getNw1()
    return self.data["nw1"]
end


function Systemdataarmor:getNw2()
    return self.data["nw2"]
end


function Systemdataarmor:getNw3()
    return self.data["nw3"]
end


function Systemdataarmor:getNw4()
    return self.data["nw4"]
end


function Systemdataarmor:getNw5()
    return self.data["nw5"]
end


function Systemdataarmor:getNb0()
    return self.data["nb0"]
end


function Systemdataarmor:getNb1()
    return self.data["nb1"]
end


function Systemdataarmor:getNb2()
    return self.data["nb2"]
end


function Systemdataarmor:getNb3()
    return self.data["nb3"]
end


function Systemdataarmor:getNb4()
    return self.data["nb4"]
end


function Systemdataarmor:getNb5()
    return self.data["nb5"]
end


function Systemdataarmor:getNp0()
    return self.data["np0"]
end


function Systemdataarmor:getNp1()
    return self.data["np1"]
end


function Systemdataarmor:getNp2()
    return self.data["np2"]
end


function Systemdataarmor:getNp3()
    return self.data["np3"]
end


function Systemdataarmor:getNp4()
    return self.data["np4"]
end


function Systemdataarmor:getNp5()
    return self.data["np5"]
end


function Systemdataarmor:getNo0()
    return self.data["no0"]
end


function Systemdataarmor:getNo1()
    return self.data["no1"]
end


function Systemdataarmor:getNo2()
    return self.data["no2"]
end


function Systemdataarmor:getNo3()
    return self.data["no3"]
end


function Systemdataarmor:getNo4()
    return self.data["no4"]
end


function Systemdataarmor:getNo5()
    return self.data["no5"]
end


function Systemdataarmor:getFw0()
    return self.data["fw0"]
end


function Systemdataarmor:getFw1()
    return self.data["fw1"]
end


function Systemdataarmor:getFw2()
    return self.data["fw2"]
end


function Systemdataarmor:getFw3()
    return self.data["fw3"]
end


function Systemdataarmor:getFw4()
    return self.data["fw4"]
end


function Systemdataarmor:getFw5()
    return self.data["fw5"]
end


function Systemdataarmor:getFb0()
    return self.data["fb0"]
end


function Systemdataarmor:getFb1()
    return self.data["fb1"]
end


function Systemdataarmor:getFb2()
    return self.data["fb2"]
end


function Systemdataarmor:getFb3()
    return self.data["fb3"]
end


function Systemdataarmor:getFb4()
    return self.data["fb4"]
end


function Systemdataarmor:getFb5()
    return self.data["fb5"]
end


function Systemdataarmor:getFp0()
    return self.data["fp0"]
end


function Systemdataarmor:getFp1()
    return self.data["fp1"]
end


function Systemdataarmor:getFp2()
    return self.data["fp2"]
end


function Systemdataarmor:getFp3()
    return self.data["fp3"]
end


function Systemdataarmor:getFp4()
    return self.data["fp4"]
end


function Systemdataarmor:getFp5()
    return self.data["fp5"]
end


function Systemdataarmor:getFo0()
    return self.data["fo0"]
end


function Systemdataarmor:getFo1()
    return self.data["fo1"]
end


function Systemdataarmor:getFo2()
    return self.data["fo2"]
end


function Systemdataarmor:getFo3()
    return self.data["fo3"]
end


function Systemdataarmor:getFo4()
    return self.data["fo4"]
end


function Systemdataarmor:getFo5()
    return self.data["fo5"]
end


function Systemdataarmor:getMw0()
    return self.data["mw0"]
end


function Systemdataarmor:getMw1()
    return self.data["mw1"]
end


function Systemdataarmor:getMw2()
    return self.data["mw2"]
end


function Systemdataarmor:getMw3()
    return self.data["mw3"]
end


function Systemdataarmor:getMw4()
    return self.data["mw4"]
end


function Systemdataarmor:getMw5()
    return self.data["mw5"]
end


function Systemdataarmor:getMb0()
    return self.data["mb0"]
end


function Systemdataarmor:getMb1()
    return self.data["mb1"]
end


function Systemdataarmor:getMb2()
    return self.data["mb2"]
end


function Systemdataarmor:getMb3()
    return self.data["mb3"]
end


function Systemdataarmor:getMb4()
    return self.data["mb4"]
end


function Systemdataarmor:getMb5()
    return self.data["mb5"]
end


function Systemdataarmor:getMp0()
    return self.data["mp0"]
end


function Systemdataarmor:getMp1()
    return self.data["mp1"]
end


function Systemdataarmor:getMp2()
    return self.data["mp2"]
end


function Systemdataarmor:getMp3()
    return self.data["mp3"]
end


function Systemdataarmor:getMp4()
    return self.data["mp4"]
end


function Systemdataarmor:getMp5()
    return self.data["mp5"]
end


function Systemdataarmor:getMo0()
    return self.data["mo0"]
end


function Systemdataarmor:getMo1()
    return self.data["mo1"]
end


function Systemdataarmor:getMo2()
    return self.data["mo2"]
end


function Systemdataarmor:getMo3()
    return self.data["mo3"]
end


function Systemdataarmor:getMo4()
    return self.data["mo4"]
end


function Systemdataarmor:getMo5()
    return self.data["mo5"]
end





return Systemdataarmor


