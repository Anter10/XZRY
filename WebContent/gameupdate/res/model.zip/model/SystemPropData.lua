local SystemPropData = class("SystemPropData",{})


function SystemPropData:ctor(data)
   self.data = data    
end


function SystemPropData:getId()
    return self.data["id"]
end


function SystemPropData:getBeizhu()
    return self.data["beizhu"]
end


function SystemPropData:getName()
    return self.data["name"]
end


function SystemPropData:getInfo()
    return self.data["info"]
end


function SystemPropData:getJgetid()
    return self.data["jgetid"]
end


function SystemPropData:getLevle()
    return self.data["levle"]
end


function SystemPropData:getType()
    return self.data["type"]
end


function SystemPropData:getF_quality()
    return self.data["f_quality"]
end


function SystemPropData:getWork()
    return self.data["work"]
end


function SystemPropData:getCanadd()
    return self.data["canadd"]
end


function SystemPropData:getMaxadd()
    return self.data["maxadd"]
end


function SystemPropData:getBaseproperity()
    return self.data["baseproperity"]
end


function SystemPropData:getAddproperity()
    return self.data["addproperity"]
end


function SystemPropData:getEquipskill()
    return self.data["equipskill"]
end


function SystemPropData:getBuytype()
    return self.data["buytype"]
end


function SystemPropData:getBuyprice()
    return self.data["buyprice"]
end


function SystemPropData:getSealtype()
    return self.data["sealtype"]
end


function SystemPropData:getSealprice()
    return self.data["sealprice"]
end


function SystemPropData:getBind()
    return self.data["bind"]
end


function SystemPropData:getUnique()
    return self.data["unique"]
end


function SystemPropData:getTimeeffect()
    return self.data["timeeffect"]
end


function SystemPropData:getCd()
    return self.data["cd"]
end


function SystemPropData:getIcon()
    return self.data["icon"]
end


function SystemPropData:getEnglishname()
    return self.data["englishname"]
end


function SystemPropData:getEnglishinfo()
    return self.data["englishinfo"]
end


function SystemPropData:getFromwhere()
    return self.data["fromwhere"]
end


function SystemPropData:getMapcellpng()
    return self.data["mapcellpng"]
end


function SystemPropData:getMapfrontpng()
    return self.data["mapfrontpng"]
end





return SystemPropData


