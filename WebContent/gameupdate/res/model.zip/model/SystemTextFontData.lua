local SystemTextFontData = class("SystemTextFontData",{})


function SystemTextFontData:ctor(data)
   self.data = data    
end


function SystemTextFontData:getId()
    return self.data["id"]
end


function SystemTextFontData:getFont()
    return self.data["font"]
end


function SystemTextFontData:getSizelan1()
    return self.data["sizelan1"]
end


function SystemTextFontData:getSizelan2()
    return self.data["sizelan2"]
end


function SystemTextFontData:getColorlan1()
    return self.data["colorlan1"]
end


function SystemTextFontData:getColorlan2()
    return self.data["colorlan2"]
end





return SystemTextFontData


