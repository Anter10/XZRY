local Systemdatashoes = class("Systemdatashoes",{})


function Systemdatashoes:ctor(data)
   self.data = data    
end


function Systemdatashoes:getId()
    return self.data["id"]
end


function Systemdatashoes:getNw0()
    return self.data["nw0"]
end


function Systemdatashoes:getNw1()
    return self.data["nw1"]
end


function Systemdatashoes:getNw2()
    return self.data["nw2"]
end


function Systemdatashoes:getNw3()
    return self.data["nw3"]
end


function Systemdatashoes:getNw4()
    return self.data["nw4"]
end


function Systemdatashoes:getNw5()
    return self.data["nw5"]
end


function Systemdatashoes:getNb0()
    return self.data["nb0"]
end


function Systemdatashoes:getNb1()
    return self.data["nb1"]
end


function Systemdatashoes:getNb2()
    return self.data["nb2"]
end


function Systemdatashoes:getNb3()
    return self.data["nb3"]
end


function Systemdatashoes:getNb4()
    return self.data["nb4"]
end


function Systemdatashoes:getNb5()
    return self.data["nb5"]
end


function Systemdatashoes:getNp0()
    return self.data["np0"]
end


function Systemdatashoes:getNp1()
    return self.data["np1"]
end


function Systemdatashoes:getNp2()
    return self.data["np2"]
end


function Systemdatashoes:getNp3()
    return self.data["np3"]
end


function Systemdatashoes:getNp4()
    return self.data["np4"]
end


function Systemdatashoes:getNp5()
    return self.data["np5"]
end


function Systemdatashoes:getNo0()
    return self.data["no0"]
end


function Systemdatashoes:getNo1()
    return self.data["no1"]
end


function Systemdatashoes:getNo2()
    return self.data["no2"]
end


function Systemdatashoes:getNo3()
    return self.data["no3"]
end


function Systemdatashoes:getNo4()
    return self.data["no4"]
end


function Systemdatashoes:getNo5()
    return self.data["no5"]
end


function Systemdatashoes:getFw0()
    return self.data["fw0"]
end


function Systemdatashoes:getFw1()
    return self.data["fw1"]
end


function Systemdatashoes:getFw2()
    return self.data["fw2"]
end


function Systemdatashoes:getFw3()
    return self.data["fw3"]
end


function Systemdatashoes:getFw4()
    return self.data["fw4"]
end


function Systemdatashoes:getFw5()
    return self.data["fw5"]
end


function Systemdatashoes:getFb0()
    return self.data["fb0"]
end


function Systemdatashoes:getFb1()
    return self.data["fb1"]
end


function Systemdatashoes:getFb2()
    return self.data["fb2"]
end


function Systemdatashoes:getFb3()
    return self.data["fb3"]
end


function Systemdatashoes:getFb4()
    return self.data["fb4"]
end


function Systemdatashoes:getFb5()
    return self.data["fb5"]
end


function Systemdatashoes:getFp0()
    return self.data["fp0"]
end


function Systemdatashoes:getFp1()
    return self.data["fp1"]
end


function Systemdatashoes:getFp2()
    return self.data["fp2"]
end


function Systemdatashoes:getFp3()
    return self.data["fp3"]
end


function Systemdatashoes:getFp4()
    return self.data["fp4"]
end


function Systemdatashoes:getFp5()
    return self.data["fp5"]
end


function Systemdatashoes:getFo0()
    return self.data["fo0"]
end


function Systemdatashoes:getFo1()
    return self.data["fo1"]
end


function Systemdatashoes:getFo2()
    return self.data["fo2"]
end


function Systemdatashoes:getFo3()
    return self.data["fo3"]
end


function Systemdatashoes:getFo4()
    return self.data["fo4"]
end


function Systemdatashoes:getFo5()
    return self.data["fo5"]
end


function Systemdatashoes:getMw0()
    return self.data["mw0"]
end


function Systemdatashoes:getMw1()
    return self.data["mw1"]
end


function Systemdatashoes:getMw2()
    return self.data["mw2"]
end


function Systemdatashoes:getMw3()
    return self.data["mw3"]
end


function Systemdatashoes:getMw4()
    return self.data["mw4"]
end


function Systemdatashoes:getMw5()
    return self.data["mw5"]
end


function Systemdatashoes:getMb0()
    return self.data["mb0"]
end


function Systemdatashoes:getMb1()
    return self.data["mb1"]
end


function Systemdatashoes:getMb2()
    return self.data["mb2"]
end


function Systemdatashoes:getMb3()
    return self.data["mb3"]
end


function Systemdatashoes:getMb4()
    return self.data["mb4"]
end


function Systemdatashoes:getMb5()
    return self.data["mb5"]
end


function Systemdatashoes:getMp0()
    return self.data["mp0"]
end


function Systemdatashoes:getMp1()
    return self.data["mp1"]
end


function Systemdatashoes:getMp2()
    return self.data["mp2"]
end


function Systemdatashoes:getMp3()
    return self.data["mp3"]
end


function Systemdatashoes:getMp4()
    return self.data["mp4"]
end


function Systemdatashoes:getMp5()
    return self.data["mp5"]
end


function Systemdatashoes:getMo0()
    return self.data["mo0"]
end


function Systemdatashoes:getMo1()
    return self.data["mo1"]
end


function Systemdatashoes:getMo2()
    return self.data["mo2"]
end


function Systemdatashoes:getMo3()
    return self.data["mo3"]
end


function Systemdatashoes:getMo4()
    return self.data["mo4"]
end


function Systemdatashoes:getMo5()
    return self.data["mo5"]
end





return Systemdatashoes


