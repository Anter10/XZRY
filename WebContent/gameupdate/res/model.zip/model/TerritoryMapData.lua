local TerritoryMapData = class("TerritoryMapData",{})


function TerritoryMapData:ctor(data)
   self.data = data    
end


function TerritoryMapData:getId()
    return self.data["id"]
end


function TerritoryMapData:getMapdata()
    return self.data["mapdata"]
end





return TerritoryMapData


