local SystemHeroPromotionData = class("SystemHeroPromotionData",{})


function SystemHeroPromotionData:ctor(data)
   self.data = data    
end


function SystemHeroPromotionData:getId()
    return self.data["id"]
end


function SystemHeroPromotionData:getHeroid()
    return self.data["heroid"]
end


function SystemHeroPromotionData:getPromotion()
    return self.data["promotion"]
end


function SystemHeroPromotionData:getNeedlevel()
    return self.data["needlevel"]
end


function SystemHeroPromotionData:getNeeditems()
    return self.data["needitems"]
end


function SystemHeroPromotionData:getInfo()
    return self.data["info"]
end





return SystemHeroPromotionData


