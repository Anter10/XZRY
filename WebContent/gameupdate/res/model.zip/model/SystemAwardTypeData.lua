local SystemAwardTypeData = class("SystemAwardTypeData",{})


function SystemAwardTypeData:ctor(data)
   self.data = data    
end


function SystemAwardTypeData:getId()
    return self.data["id"]
end


function SystemAwardTypeData:getId_info()
    return self.data["id_info"]
end


function SystemAwardTypeData:getIcon()
    return self.data["icon"]
end


function SystemAwardTypeData:getInfo()
    return self.data["info"]
end





return SystemAwardTypeData


