local MainCityBuilds = class("MainCityBuilds",{})


function MainCityBuilds:ctor(data)
   self.data = data    
end


function MainCityBuilds:getId()
    return self.data["id"]
end


function MainCityBuilds:getName()
    return self.data["name"]
end


function MainCityBuilds:getUselevel()
    return self.data["uselevel"]
end


function MainCityBuilds:getUsemainres()
    return self.data["usemainres"]
end





return MainCityBuilds


