local DialogViewData = class("DialogViewData",{})


function DialogViewData:ctor(data)
   self.data = data    
end


function DialogViewData:getId()
    return self.data["id"]
end


function DialogViewData:getName()
    return self.data["name"]
end


function DialogViewData:getType()
    return self.data["type"]
end


function DialogViewData:getInfo()
    return self.data["info"]
end


function DialogViewData:getSize()
    return self.data["size"]
end


function DialogViewData:getOriginalinfo()
    return self.data["originalinfo"]
end


function DialogViewData:getButton1()
    return self.data["button1"]
end


function DialogViewData:getButton2()
    return self.data["button2"]
end


function DialogViewData:getButton3()
    return self.data["button3"]
end


function DialogViewData:getShowtype()
    return self.data["showtype"]
end


function DialogViewData:getFontsize()
    return self.data["fontsize"]
end





return DialogViewData


