local SystemBuildLevelData = class("SystemBuildLevelData",{})


function SystemBuildLevelData:ctor(data)
   self.data = data    
end


function SystemBuildLevelData:getId()
    return self.data["id"]
end


function SystemBuildLevelData:getLevel()
    return self.data["level"]
end


function SystemBuildLevelData:getName()
    return self.data["name"]
end





return SystemBuildLevelData


