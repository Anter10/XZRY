local SystemHeroRandomActions = class("SystemHeroRandomActions",{})


function SystemHeroRandomActions:ctor(data)
   self.data = data    
end


function SystemHeroRandomActions:getId()
    return self.data["id"]
end


function SystemHeroRandomActions:getName()
    return self.data["name"]
end


function SystemHeroRandomActions:getActions()
    return self.data["actions"]
end





return SystemHeroRandomActions


