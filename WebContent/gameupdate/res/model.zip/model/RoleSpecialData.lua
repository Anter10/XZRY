local RoleSpecialData = class("RoleSpecialData",{})


function RoleSpecialData:ctor(data)
   self.data = data    
end


function RoleSpecialData:getId()
    return self.data["id"]
end


function RoleSpecialData:getInfo()
    return self.data["info"]
end


function RoleSpecialData:getRoleid()
    return self.data["roleid"]
end


function RoleSpecialData:getActionname()
    return self.data["actionname"]
end


function RoleSpecialData:getEfxevents()
    return self.data["efxevents"]
end


function RoleSpecialData:getEfx()
    return self.data["efx"]
end


function RoleSpecialData:getEfx_nodes()
    return self.data["efx_nodes"]
end


function RoleSpecialData:getEfxloop()
    return self.data["efxloop"]
end


function RoleSpecialData:getEfxroom()
    return self.data["efxroom"]
end


function RoleSpecialData:getEfxisdirection()
    return self.data["efxisdirection"]
end


function RoleSpecialData:getEfxisfollow()
    return self.data["efxisfollow"]
end


function RoleSpecialData:getEfxlayertype()
    return self.data["efxlayertype"]
end


function RoleSpecialData:getEfxlayerzorder()
    return self.data["efxlayerzorder"]
end


function RoleSpecialData:getEfxxy()
    return self.data["efxxy"]
end


function RoleSpecialData:getInspireevent()
    return self.data["inspireevent"]
end


function RoleSpecialData:getInspireevent_nodes()
    return self.data["inspireevent_nodes"]
end


function RoleSpecialData:getInspireloop()
    return self.data["inspireloop"]
end


function RoleSpecialData:getInspireroom()
    return self.data["inspireroom"]
end


function RoleSpecialData:getInspirisdirection()
    return self.data["inspirisdirection"]
end


function RoleSpecialData:getInspirefollow()
    return self.data["inspirefollow"]
end


function RoleSpecialData:getInspirelayertype()
    return self.data["inspirelayertype"]
end


function RoleSpecialData:getInspirelayerzorder()
    return self.data["inspirelayerzorder"]
end


function RoleSpecialData:getInspirexy()
    return self.data["inspirexy"]
end





return RoleSpecialData


