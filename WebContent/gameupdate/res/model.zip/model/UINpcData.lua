local UINpcData = class("UINpcData",{})


function UINpcData:ctor(data)
   self.data = data    
end


function UINpcData:getId()
    return self.data["id"]
end


function UINpcData:getName()
    return self.data["name"]
end


function UINpcData:getSpinefile()
    return self.data["spinefile"]
end


function UINpcData:getScale()
    return self.data["scale"]
end


function UINpcData:getClickmusiceffect()
    return self.data["clickmusiceffect"]
end


function UINpcData:getAnimation()
    return self.data["animation"]
end


function UINpcData:getTouchrange()
    return self.data["touchrange"]
end


function UINpcData:getDialog()
    return self.data["dialog"]
end





return UINpcData


