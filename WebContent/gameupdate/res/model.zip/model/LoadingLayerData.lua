local LoadingLayerData = class("LoadingLayerData",{})


function LoadingLayerData:ctor(data)
   self.data = data    
end


function LoadingLayerData:getId()
    return self.data["id"]
end


function LoadingLayerData:getType()
    return self.data["type"]
end


function LoadingLayerData:getName()
    return self.data["name"]
end


function LoadingLayerData:getBottom()
    return self.data["bottom"]
end


function LoadingLayerData:getCenter()
    return self.data["center"]
end


function LoadingLayerData:getUpper()
    return self.data["upper"]
end


function LoadingLayerData:getBackground()
    return self.data["background"]
end


function LoadingLayerData:getInfo()
    return self.data["info"]
end





return LoadingLayerData


