local SystemIntensifyData = class("SystemIntensifyData",{})


function SystemIntensifyData:ctor(data)
   self.data = data    
end


function SystemIntensifyData:getId()
    return self.data["id"]
end


function SystemIntensifyData:getRid()
    return self.data["rid"]
end


function SystemIntensifyData:getName()
    return self.data["name"]
end


function SystemIntensifyData:getQuality()
    return self.data["quality"]
end


function SystemIntensifyData:getS1_s()
    return self.data["s1_s"]
end


function SystemIntensifyData:getS2_s()
    return self.data["s2_s"]
end


function SystemIntensifyData:getS3_s()
    return self.data["s3_s"]
end


function SystemIntensifyData:getS4_s()
    return self.data["s4_s"]
end


function SystemIntensifyData:getS5_s()
    return self.data["s5_s"]
end


function SystemIntensifyData:getS1_p()
    return self.data["s1_p"]
end


function SystemIntensifyData:getS2_p()
    return self.data["s2_p"]
end


function SystemIntensifyData:getS3_p()
    return self.data["s3_p"]
end


function SystemIntensifyData:getS4_p()
    return self.data["s4_p"]
end


function SystemIntensifyData:getS5_p()
    return self.data["s5_p"]
end


function SystemIntensifyData:getStrength_needmoneytype()
    return self.data["strength_needmoneytype"]
end


function SystemIntensifyData:getMoneynum()
    return self.data["moneynum"]
end


function SystemIntensifyData:getS1_m()
    return self.data["s1_m"]
end


function SystemIntensifyData:getS2_m()
    return self.data["s2_m"]
end


function SystemIntensifyData:getS3_m()
    return self.data["s3_m"]
end


function SystemIntensifyData:getS4_m()
    return self.data["s4_m"]
end


function SystemIntensifyData:getS5_m()
    return self.data["s5_m"]
end


function SystemIntensifyData:getSp0()
    return self.data["sp0"]
end


function SystemIntensifyData:getSp1()
    return self.data["sp1"]
end


function SystemIntensifyData:getSp2()
    return self.data["sp2"]
end


function SystemIntensifyData:getSp3()
    return self.data["sp3"]
end


function SystemIntensifyData:getSp4()
    return self.data["sp4"]
end


function SystemIntensifyData:getSp5()
    return self.data["sp5"]
end





return SystemIntensifyData


