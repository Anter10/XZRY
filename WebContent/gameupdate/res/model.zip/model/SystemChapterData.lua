local SystemChapterData = class("SystemChapterData",{})


function SystemChapterData:ctor(data)
   self.data = data    
end


function SystemChapterData:getId()
    return self.data["id"]
end


function SystemChapterData:getName()
    return self.data["name"]
end


function SystemChapterData:getOriginalname()
    return self.data["originalname"]
end


function SystemChapterData:getLevels()
    return self.data["levels"]
end


function SystemChapterData:getArwrds()
    return self.data["arwrds"]
end


function SystemChapterData:getBackgroundfile()
    return self.data["backgroundfile"]
end


function SystemChapterData:getOpenlevel()
    return self.data["openlevel"]
end


function SystemChapterData:getUpchapter()
    return self.data["upchapter"]
end


function SystemChapterData:getLevelpos()
    return self.data["levelpos"]
end





return SystemChapterData


