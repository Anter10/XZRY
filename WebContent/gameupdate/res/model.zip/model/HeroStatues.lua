local HeroStatues = class("HeroStatues",{})


function HeroStatues:ctor(data)
   self.data = data    
end


function HeroStatues:getId()
    return self.data["id"]
end


function HeroStatues:getName()
    return self.data["name"]
end


function HeroStatues:getIcon()
    return self.data["icon"]
end


function HeroStatues:getInfo()
    return self.data["info"]
end


function HeroStatues:getMusicfile()
    return self.data["musicfile"]
end





return HeroStatues


