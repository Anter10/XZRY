local SystemColor = class("SystemColor",{})


function SystemColor:ctor(data)
   self.data = data    
end


function SystemColor:getId()
    return self.data["id"]
end


function SystemColor:getName()
    return self.data["name"]
end


function SystemColor:getR()
    return self.data["r"]
end


function SystemColor:getG()
    return self.data["g"]
end


function SystemColor:getB()
    return self.data["b"]
end


function SystemColor:getA()
    return self.data["a"]
end





return SystemColor


