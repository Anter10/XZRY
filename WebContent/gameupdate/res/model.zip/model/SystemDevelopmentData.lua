local SystemDevelopmentData = class("SystemDevelopmentData",{})


function SystemDevelopmentData:ctor(data)
   self.data = data    
end


function SystemDevelopmentData:getId()
    return self.data["id"]
end


function SystemDevelopmentData:getName()
    return self.data["name"]
end


function SystemDevelopmentData:getLevel()
    return self.data["level"]
end


function SystemDevelopmentData:getOpenlevel()
    return self.data["openlevel"]
end


function SystemDevelopmentData:getUp_custome()
    return self.data["up_custome"]
end


function SystemDevelopmentData:getUp_time()
    return self.data["up_time"]
end


function SystemDevelopmentData:getAddspeedcos()
    return self.data["addspeedcos"]
end


function SystemDevelopmentData:getFunc()
    return self.data["func"]
end


function SystemDevelopmentData:getEt()
    return self.data["et"]
end


function SystemDevelopmentData:getEv()
    return self.data["ev"]
end


function SystemDevelopmentData:getCe()
    return self.data["ce"]
end


function SystemDevelopmentData:getUae()
    return self.data["uae"]
end


function SystemDevelopmentData:getNpc()
    return self.data["npc"]
end


function SystemDevelopmentData:getBuildtype()
    return self.data["buildtype"]
end


function SystemDevelopmentData:getBulidinfo()
    return self.data["bulidinfo"]
end





return SystemDevelopmentData


