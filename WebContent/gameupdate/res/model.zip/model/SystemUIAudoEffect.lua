local SystemUIAudoEffect = class("SystemUIAudoEffect",{})


function SystemUIAudoEffect:ctor(data)
   self.data = data    
end


function SystemUIAudoEffect:getId()
    return self.data["id"]
end


function SystemUIAudoEffect:getInfo()
    return self.data["info"]
end


function SystemUIAudoEffect:getFilename()
    return self.data["filename"]
end





return SystemUIAudoEffect


