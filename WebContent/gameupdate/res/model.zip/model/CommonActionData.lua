local CommonActionData = class("CommonActionData",{})


function CommonActionData:ctor(data)
   self.data = data    
end


function CommonActionData:getId()
    return self.data["id"]
end


function CommonActionData:getActionname()
    return self.data["actionname"]
end


function CommonActionData:getInfo()
    return self.data["info"]
end





return CommonActionData


