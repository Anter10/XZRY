local SystemSonSkillData = class("SystemSonSkillData",{})


function SystemSonSkillData:ctor(data)
   self.data = data    
end


function SystemSonSkillData:getId()
    return self.data["id"]
end


function SystemSonSkillData:getName()
    return self.data["name"]
end


function SystemSonSkillData:getTarget()
    return self.data["target"]
end


function SystemSonSkillData:getEffecttype()
    return self.data["effecttype"]
end


function SystemSonSkillData:getEffectvalue()
    return self.data["effectvalue"]
end


function SystemSonSkillData:getEffectuplevel()
    return self.data["effectuplevel"]
end


function SystemSonSkillData:getEffectid()
    return self.data["effectid"]
end


function SystemSonSkillData:getMusiceffect()
    return self.data["musiceffect"]
end





return SystemSonSkillData


