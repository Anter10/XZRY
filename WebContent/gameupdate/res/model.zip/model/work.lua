local work = class("work",{})


function work:ctor(data)
   self.data = data    
end


function work:getId()
    return self.data["id"]
end


function work:getPos()
    return self.data["pos"]
end


function work:getType()
    return self.data["type"]
end


function work:getNeeds()
    return self.data["needs"]
end


function work:getPro()
    return self.data["pro"]
end


function work:getImage()
    return self.data["image"]
end


function work:getWho()
    return self.data["who"]
end


function work:getMake()
    return self.data["make"]
end


function work:getFinish()
    return self.data["finish"]
end


function work:getFinish_statue()
    return self.data["finish_statue"]
end





return work


