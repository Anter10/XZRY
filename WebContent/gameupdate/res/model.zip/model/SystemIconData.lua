local SystemIconData = class("SystemIconData",{})


function SystemIconData:ctor(data)
   self.data = data    
end


function SystemIconData:getId()
    return self.data["id"]
end


function SystemIconData:getName()
    return self.data["name"]
end


function SystemIconData:getRes()
    return self.data["res"]
end


function SystemIconData:getPrice()
    return self.data["price"]
end


function SystemIconData:getOpenlevel()
    return self.data["openlevel"]
end


function SystemIconData:getInfo()
    return self.data["info"]
end





return SystemIconData


