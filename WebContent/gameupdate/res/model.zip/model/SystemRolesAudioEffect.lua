local SystemRolesAudioEffect = class("SystemRolesAudioEffect",{})


function SystemRolesAudioEffect:ctor(data)
   self.data = data    
end


function SystemRolesAudioEffect:getId()
    return self.data["id"]
end


function SystemRolesAudioEffect:getRoleid()
    return self.data["roleid"]
end


function SystemRolesAudioEffect:getInfo()
    return self.data["info"]
end


function SystemRolesAudioEffect:getFilename()
    return self.data["filename"]
end





return SystemRolesAudioEffect


