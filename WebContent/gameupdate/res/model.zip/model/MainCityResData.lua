local MainCityResData = class("MainCityResData",{})


function MainCityResData:ctor(data)
   self.data = data    
end


function MainCityResData:getId()
    return self.data["id"]
end


function MainCityResData:getRtype()
    return self.data["rtype"]
end


function MainCityResData:getName()
    return self.data["name"]
end


function MainCityResData:getRes()
    return self.data["res"]
end


function MainCityResData:getPartpos()
    return self.data["partpos"]
end


function MainCityResData:getDaysolts()
    return self.data["daysolts"]
end


function MainCityResData:getSoltsres()
    return self.data["soltsres"]
end


function MainCityResData:getAnimation()
    return self.data["animation"]
end


function MainCityResData:getTouchrange()
    return self.data["touchrange"]
end


function MainCityResData:getCorrelationfunction()
    return self.data["correlationfunction"]
end


function MainCityResData:getClickaudio()
    return self.data["clickaudio"]
end


function MainCityResData:getRestaudio()
    return self.data["restaudio"]
end


function MainCityResData:getChangecolour()
    return self.data["changecolour"]
end





return MainCityResData


