local SystemTavernData = class("SystemTavernData",{})


function SystemTavernData:ctor(data)
   self.data = data    
end


function SystemTavernData:getId()
    return self.data["id"]
end


function SystemTavernData:getName()
    return self.data["name"]
end


function SystemTavernData:getCustom()
    return self.data["custom"]
end


function SystemTavernData:getCd()
    return self.data["cd"]
end


function SystemTavernData:getBfnum()
    return self.data["bfnum"]
end


function SystemTavernData:getOfnum()
    return self.data["ofnum"]
end


function SystemTavernData:getOfrand()
    return self.data["ofrand"]
end


function SystemTavernData:getItems()
    return self.data["items"]
end


function SystemTavernData:getRoles()
    return self.data["roles"]
end


function SystemTavernData:getEqsis()
    return self.data["eqsis"]
end


function SystemTavernData:getSsis()
    return self.data["ssis"]
end


function SystemTavernData:getIcon()
    return self.data["icon"]
end


function SystemTavernData:getDescribe()
    return self.data["describe"]
end


function SystemTavernData:getGoodsshelvesnum()
    return self.data["goodsshelvesnum"]
end





return SystemTavernData


