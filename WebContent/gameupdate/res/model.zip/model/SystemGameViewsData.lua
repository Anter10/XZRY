local SystemGameViewsData = class("SystemGameViewsData",{})


function SystemGameViewsData:ctor(data)
   self.data = data    
end


function SystemGameViewsData:getId()
    return self.data["id"]
end


function SystemGameViewsData:getViewname()
    return self.data["viewname"]
end


function SystemGameViewsData:getOlevel()
    return self.data["olevel"]
end


function SystemGameViewsData:getOpencondition()
    return self.data["opencondition"]
end


function SystemGameViewsData:getNewplayer()
    return self.data["newplayer"]
end


function SystemGameViewsData:getOthername()
    return self.data["othername"]
end


function SystemGameViewsData:getClassname()
    return self.data["classname"]
end


function SystemGameViewsData:getShowde()
    return self.data["showde"]
end


function SystemGameViewsData:getUseinfo()
    return self.data["useinfo"]
end


function SystemGameViewsData:getUsetype()
    return self.data["usetype"]
end


function SystemGameViewsData:getMusic()
    return self.data["music"]
end





return SystemGameViewsData


