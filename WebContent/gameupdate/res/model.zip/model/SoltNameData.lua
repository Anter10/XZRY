local SoltNameData = class("SoltNameData",{})


function SoltNameData:ctor(data)
   self.data = data    
end


function SoltNameData:getId()
    return self.data["id"]
end


function SoltNameData:getName()
    return self.data["name"]
end


function SoltNameData:getSoltname()
    return self.data["soltname"]
end





return SoltNameData


