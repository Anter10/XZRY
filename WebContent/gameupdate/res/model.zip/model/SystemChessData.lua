local SystemChessData = class("SystemChessData",{})


function SystemChessData:ctor(data)
   self.data = data    
end


function SystemChessData:getId()
    return self.data["id"]
end


function SystemChessData:getInfo()
    return self.data["info"]
end


function SystemChessData:getLevel()
    return self.data["level"]
end


function SystemChessData:getF_type()
    return self.data["f_type"]
end


function SystemChessData:getChessfile()
    return self.data["chessfile"]
end


function SystemChessData:getF_shadow_image()
    return self.data["f_shadow_image"]
end


function SystemChessData:getF_move_fr()
    return self.data["f_move_fr"]
end


function SystemChessData:getOncejumpnum()
    return self.data["oncejumpnum"]
end


function SystemChessData:getSeveralroundsaction()
    return self.data["severalroundsaction"]
end


function SystemChessData:getF_sp()
    return self.data["f_sp"]
end


function SystemChessData:getMsg()
    return self.data["msg"]
end


function SystemChessData:getF_frist_reward_id()
    return self.data["f_frist_reward_id"]
end


function SystemChessData:getF_reward_id()
    return self.data["f_reward_id"]
end


function SystemChessData:getBattmelmapid()
    return self.data["battmelmapid"]
end





return SystemChessData


