local Systemdataweapon = class("Systemdataweapon",{})


function Systemdataweapon:ctor(data)
   self.data = data    
end


function Systemdataweapon:getId()
    return self.data["id"]
end


function Systemdataweapon:getNw0()
    return self.data["nw0"]
end


function Systemdataweapon:getNw1()
    return self.data["nw1"]
end


function Systemdataweapon:getNw2()
    return self.data["nw2"]
end


function Systemdataweapon:getNw3()
    return self.data["nw3"]
end


function Systemdataweapon:getNw4()
    return self.data["nw4"]
end


function Systemdataweapon:getNw5()
    return self.data["nw5"]
end


function Systemdataweapon:getNb0()
    return self.data["nb0"]
end


function Systemdataweapon:getNb1()
    return self.data["nb1"]
end


function Systemdataweapon:getNb2()
    return self.data["nb2"]
end


function Systemdataweapon:getNb3()
    return self.data["nb3"]
end


function Systemdataweapon:getNb4()
    return self.data["nb4"]
end


function Systemdataweapon:getNb5()
    return self.data["nb5"]
end


function Systemdataweapon:getNp0()
    return self.data["np0"]
end


function Systemdataweapon:getNp1()
    return self.data["np1"]
end


function Systemdataweapon:getNp2()
    return self.data["np2"]
end


function Systemdataweapon:getNp3()
    return self.data["np3"]
end


function Systemdataweapon:getNp4()
    return self.data["np4"]
end


function Systemdataweapon:getNp5()
    return self.data["np5"]
end


function Systemdataweapon:getNo0()
    return self.data["no0"]
end


function Systemdataweapon:getNo1()
    return self.data["no1"]
end


function Systemdataweapon:getNo2()
    return self.data["no2"]
end


function Systemdataweapon:getNo3()
    return self.data["no3"]
end


function Systemdataweapon:getNo4()
    return self.data["no4"]
end


function Systemdataweapon:getNo5()
    return self.data["no5"]
end


function Systemdataweapon:getFw0()
    return self.data["fw0"]
end


function Systemdataweapon:getFw1()
    return self.data["fw1"]
end


function Systemdataweapon:getFw2()
    return self.data["fw2"]
end


function Systemdataweapon:getFw3()
    return self.data["fw3"]
end


function Systemdataweapon:getFw4()
    return self.data["fw4"]
end


function Systemdataweapon:getFw5()
    return self.data["fw5"]
end


function Systemdataweapon:getFb0()
    return self.data["fb0"]
end


function Systemdataweapon:getFb1()
    return self.data["fb1"]
end


function Systemdataweapon:getFb2()
    return self.data["fb2"]
end


function Systemdataweapon:getFb3()
    return self.data["fb3"]
end


function Systemdataweapon:getFb4()
    return self.data["fb4"]
end


function Systemdataweapon:getFb5()
    return self.data["fb5"]
end


function Systemdataweapon:getFp0()
    return self.data["fp0"]
end


function Systemdataweapon:getFp1()
    return self.data["fp1"]
end


function Systemdataweapon:getFp2()
    return self.data["fp2"]
end


function Systemdataweapon:getFp3()
    return self.data["fp3"]
end


function Systemdataweapon:getFp4()
    return self.data["fp4"]
end


function Systemdataweapon:getFp5()
    return self.data["fp5"]
end


function Systemdataweapon:getFo0()
    return self.data["fo0"]
end


function Systemdataweapon:getFo1()
    return self.data["fo1"]
end


function Systemdataweapon:getFo2()
    return self.data["fo2"]
end


function Systemdataweapon:getFo3()
    return self.data["fo3"]
end


function Systemdataweapon:getFo4()
    return self.data["fo4"]
end


function Systemdataweapon:getFo5()
    return self.data["fo5"]
end


function Systemdataweapon:getMw0()
    return self.data["mw0"]
end


function Systemdataweapon:getMw1()
    return self.data["mw1"]
end


function Systemdataweapon:getMw2()
    return self.data["mw2"]
end


function Systemdataweapon:getMw3()
    return self.data["mw3"]
end


function Systemdataweapon:getMw4()
    return self.data["mw4"]
end


function Systemdataweapon:getMw5()
    return self.data["mw5"]
end


function Systemdataweapon:getMb0()
    return self.data["mb0"]
end


function Systemdataweapon:getMb1()
    return self.data["mb1"]
end


function Systemdataweapon:getMb2()
    return self.data["mb2"]
end


function Systemdataweapon:getMb3()
    return self.data["mb3"]
end


function Systemdataweapon:getMb4()
    return self.data["mb4"]
end


function Systemdataweapon:getMb5()
    return self.data["mb5"]
end


function Systemdataweapon:getMp0()
    return self.data["mp0"]
end


function Systemdataweapon:getMp1()
    return self.data["mp1"]
end


function Systemdataweapon:getMp2()
    return self.data["mp2"]
end


function Systemdataweapon:getMp3()
    return self.data["mp3"]
end


function Systemdataweapon:getMp4()
    return self.data["mp4"]
end


function Systemdataweapon:getMp5()
    return self.data["mp5"]
end


function Systemdataweapon:getMo0()
    return self.data["mo0"]
end


function Systemdataweapon:getMo1()
    return self.data["mo1"]
end


function Systemdataweapon:getMo2()
    return self.data["mo2"]
end


function Systemdataweapon:getMo3()
    return self.data["mo3"]
end


function Systemdataweapon:getMo4()
    return self.data["mo4"]
end


function Systemdataweapon:getMo5()
    return self.data["mo5"]
end





return Systemdataweapon


