local AllLanguageData = class("AllLanguageData",{})


function AllLanguageData:ctor(data)
   self.data = data    
end


function AllLanguageData:getId()
    return self.data["id"]
end


function AllLanguageData:getInfo()
    return self.data["info"]
end





return AllLanguageData


