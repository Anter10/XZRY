local HeroStatueConvert = class("HeroStatueConvert",{})


function HeroStatueConvert:ctor(data)
   self.data = data    
end


function HeroStatueConvert:getId()
    return self.data["id"]
end


function HeroStatueConvert:getCurrent_statue()
    return self.data["current_statue"]
end


function HeroStatueConvert:getConvert_statue()
    return self.data["convert_statue"]
end


function HeroStatueConvert:getAnimationArray()
    return self.data["animationArray"]
end


function HeroStatueConvert:getStartinfo()
    return self.data["startinfo"]
end


function HeroStatueConvert:getEndinfo()
    return self.data["endinfo"]
end





return HeroStatueConvert


