local SystemMapChapterData = class("SystemMapChapterData",{})


function SystemMapChapterData:ctor(data)
   self.data = data    
end


function SystemMapChapterData:getId()
    return self.data["id"]
end


function SystemMapChapterData:getF_kind()
    return self.data["f_kind"]
end


function SystemMapChapterData:getF_difficulty()
    return self.data["f_difficulty"]
end


function SystemMapChapterData:getF_gr_level()
    return self.data["f_gr_level"]
end


function SystemMapChapterData:getF_instance()
    return self.data["f_instance"]
end


function SystemMapChapterData:getF_chapter()
    return self.data["f_chapter"]
end


function SystemMapChapterData:getF_grade()
    return self.data["f_grade"]
end


function SystemMapChapterData:getF_unlock()
    return self.data["f_unlock"]
end


function SystemMapChapterData:getF_story_png()
    return self.data["f_story_png"]
end


function SystemMapChapterData:getF_map_file()
    return self.data["f_map_file"]
end


function SystemMapChapterData:getF_animation_list()
    return self.data["f_animation_list"]
end


function SystemMapChapterData:getF_base_png()
    return self.data["f_base_png"]
end


function SystemMapChapterData:getF_close_range()
    return self.data["f_close_range"]
end


function SystemMapChapterData:getF_weather()
    return self.data["f_weather"]
end


function SystemMapChapterData:getF_bron_xy()
    return self.data["f_bron_xy"]
end


function SystemMapChapterData:getF_move_spot()
    return self.data["f_move_spot"]
end


function SystemMapChapterData:getF_random_chess()
    return self.data["f_random_chess"]
end


function SystemMapChapterData:getF_random_room()
    return self.data["f_random_room"]
end


function SystemMapChapterData:getF_fixed_chess_room()
    return self.data["f_fixed_chess_room"]
end


function SystemMapChapterData:getF_box_chess_room()
    return self.data["f_box_chess_room"]
end


function SystemMapChapterData:getF_task()
    return self.data["f_task"]
end


function SystemMapChapterData:getF_instance_frist_reward()
    return self.data["f_instance_frist_reward"]
end


function SystemMapChapterData:getF_instance_reward()
    return self.data["f_instance_reward"]
end


function SystemMapChapterData:getF_monster_preview()
    return self.data["f_monster_preview"]
end


function SystemMapChapterData:getF_reward_preview()
    return self.data["f_reward_preview"]
end


function SystemMapChapterData:getBattmelmapid()
    return self.data["battmelmapid"]
end


function SystemMapChapterData:getMapmusic()
    return self.data["mapmusic"]
end





return SystemMapChapterData


