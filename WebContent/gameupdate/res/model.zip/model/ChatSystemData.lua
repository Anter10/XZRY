local ChatSystemData = class("ChatSystemData",{})


function ChatSystemData:ctor(data)
   self.data = data    
end


function ChatSystemData:getId()
    return self.data["id"]
end


function ChatSystemData:getTilte()
    return self.data["tilte"]
end


function ChatSystemData:getInfo()
    return self.data["info"]
end





return ChatSystemData


