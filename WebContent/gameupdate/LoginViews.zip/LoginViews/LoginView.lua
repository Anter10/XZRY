
local LoginView = class("LoginView",RequireModel.CommonLayerView)
 
local files             = RequireModel.fileManager
local checkInternet     = RequireModel.CheckInternet
local DialogView        = RequireModel.DialogView

function LoginView:dealSocketData(data)
    -- 设置发送消息的类型
    sendMessageToServer(SENDMESSAGEIDS.PostPlayerMessageId)
    
end
local tspsss  = nil
--160M,34-37帧
function  LoginView:ctor()
    -- 登陆视图
    self.dengccbnode = nil
    self.denglutab   = {}
    -- 功能视图
    self.gongnengccbnode = nil
    self.gongnengtab = {}
    self:setBackGround() 
    self:addCcb()
    -- RequireModel.ShowRolesDialogLayer.Show("Z01J02B102031")
    --GMData.getHero(2121212)
    local lll = RequireModel.CommonLayerView.new()
    self:addChild(lll,100)
    lll:setPosition(cc.p(111,222))
    local spinefilename = "efx_ui001"
        -- 创建一个spine 骨骼Node
    local spineFIle = spinefilename..".skel"
 
    -- tlabel:setPosition(cc.p(210,333))
    -- self:addChild(tlabel, 120)
    -- self.spinefile  = spineFIle
    --   self.specialEffect  =  sp.SkeletonAnimation:create(spineFIle,spinefilename..".atlas",1)
    --   self:addChild(self.specialEffect, 21)
    --   self.specialEffect:setPosition(cc.p(322,411))
    --   self.specialEffect:setAnimation(0,"a3",true)
       -- local tdata = getSystemData():getBattleUnitDataById(100101)
       -- self.item  =  RequireModel.IconNode.new(tdata)
       -- -- self.item:setBottom("jiesuan/js_juesedi.png")
       -- self.item:setShowSize(cc.size(90,90))
       -- self.item:setPosition(cc.p(325, 510))
       -- self.item:setShowScale(0.6)
       -- self.item:setShowImage(tdata:getIcon())
       -- -- self.ccbdata["icon"]:setVisible(false)
       
       -- self:addChild(self.item,110)

    -- -- print("缩放后的坐标 = ",lll:getPositionX(),lll:getPositionY())
   -- print("getStringArray12 ",json.encode(getStringArray("1#0#1","#")))
    
    -- self.Layer = cc.LayerColor:create(cc.c4f(222,122,122,255))
    -- self:addChild(self.Layer,120)
    -- self.Layer:setContentSize(cc.size(300,200))
    -- self.Layer:setAnchorPoint(cc.p(0.5,0.5))
    
    -- self.sprite = cc.Sprite:create("ooo.png")
    -- self:addChild(self.sprite,10000)
    -- self.sprite:setPosition(cc.p(330,))
    -- setGray(self.sprite)

    local function callss( )
        -- print("缩放后的坐标 = ",lll:getPositionX(),lll:getPositionY())
        
    end
    -- RequireModel.ShowRolesDialogLayer.Show(50001)
    -- tspsss = sp.SkeletonAnimation:create("efx_ui029.skel","efx_ui029.atlas")
    -- tspsss:setPosition(winsize.width/2,winsize.height/2 + 220)
    -- self:addChild(tspsss)
    -- tspsss:setAnimation(0,"a1",true)
    -- tspsss:setBonePosition(BATTLEENUM.MapCellBone.lb,-600, 0)
    -- self.length = 400





    -- local scaleTo = cc.ScaleTo:create(2, 0.4)
    -- local scaleTo1 = cc.ScaleTo:create(2, 1)
    -- local seq = cc.Sequence:create(scaleTo,scaleTo1)
    -- local rep = cc.RepeatForever:create(seq)
    -- self.Layer:runAction(rep)
    

    -- 设置长链接的IP地址
   -- Font.getTextLabel(text,fontsize,color,dimensions,hAlignment,vAlignment,anchor,fnode,pos,order,mb)
   -- Font.getTextLabel("你好吗 ",21,cc.c4f(222,12,12,255),cc.size(120,212),1,1,cc.p(0,0),self,cc.p(320,210),32,false)
   -- -- print("sssdmdmndnd = ", CTString("1.3.5","1.2.3", ","))
 
    
    -- 功能视图
    -- RequireModel.AndroidTools.setFunctions.isAndroidConnectInternet()
    
 

    local dllayer = VersionUpdate.new(5)
    self:addChild(dllayer,12)
    -- dllayer:startUpdate()
    
    local writePath = cc.FileUtils:getInstance():getWritablePath()
    -- local savePath = writePath.."abc"
    print("savePath = ",writePath)
    -- print("LoginView name = ",LoginView.__type)

end
 

-- 添加ccb文件
function LoginView:addCcb()
    ccb["UIComeGameScene"]=self.denglutab
    local dengluproxy = cc.CCBProxy:create()
    self.dengccbnode = CCBReaderLoad("UI_ccbi/ui_denglu_denglukuang.ccbi",dengluproxy,self.denglutab)
    self.dengccbnode:setPosition(winsize.width/2-300 ,winsize.height/2+40)
    self:addChild(self.dengccbnode)

    ccb["UIDenglu_gongneng"]=self.gongnengtab
    local gongnengproxy = cc.CCBProxy:create()
    self.gongnengccbnode = CCBReaderLoad("UI_ccbi/ui_denglu_gongneng.ccbi",gongnengproxy,self.gongnengtab)
    self.gongnengccbnode:setPosition(winsize.width - 60 ,winsize.height - 140)
    self:addChild(self.gongnengccbnode)

    -- --添加中点的ccb
    -- ccb["TeamLayerMiddle"]=self.middleccbtab
    -- local middleproxy = cc.CCBProxy:create()
    -- self.middleccbnode = CCBReaderLoad("ui_team.ccbi",middleproxy,self.middleccbtab)
    -- self.middleccbnode:setPosition(winsize.width/2,winsize.height/2)
    -- self:addChild(self.middleccbnode,-1)

    --  --添加中上点的ccb
    -- ccb["TeamLayerTopMiddle"]=self.topmiddleccbtab
    -- local topmiddleproxy = cc.CCBProxy:create()
    -- self.topmiddleccbnode = CCBReaderLoad("ui_team_shang3.ccbi",topmiddleproxy,self.topmiddleccbtab)
    -- self.topmiddleccbnode:setPosition(winsize.width/2,winsize.height)
    -- self:addChild(self.topmiddleccbnode,-1)
    -- --添加中下点的ccb
    -- ccb["TeamLayerLowerMiddle"]=self.lowermiddleccbtab
    -- local lowermiddleproxy = cc.CCBProxy:create()
    -- self.lowermiddleccbnode = CCBReaderLoad("ui_team_xia.ccbi",lowermiddleproxy,self.lowermiddleccbtab)
    -- self.lowermiddleccbnode:setPosition(winsize.width/2,0)
    -- self:addChild(self.lowermiddleccbnode,-1)
    -- local effects =  RequireModel.Spefcialeffectsmanage.getSpecialManage()

    -- local effect = effects:createSpecialeffects(BATTLEENUM.SteadyEffectIds.showse, true ,false)
    -- -- prin
    -- self:addChild(effect,22120)
    -- effect:playAnimation("a1")
    -- effect:setPosition(cc.p(320,220))

    self:setAcountBox()
    self:setLoginButton()
    self:setGongnnegButton()
    -- RequireModel.ShowRolesDialogLayer.Show(50001)
end

-- 设置账号输入框
function LoginView:setAcountBox()
    local function zhanghaoCallback(strEventName,pSender)
        local edit = pSender
        local strFmt 
        if strEventName == "began" then
            strFmt = string.format("editBox %p DidBegin !", edit)
            --print(strFmt)
        elseif strEventName == "ended" then
            strFmt = string.format("editBox %p DidEnd !", edit)
            --print(strFmt) 
        elseif strEventName == "return" then
            strFmt = string.format("editBox %p was returned !",edit)
            if edit == EditName then
                TTFShowEditReturn:setString("Name EditBox return !")
            elseif edit == EditPassword then
                TTFShowEditReturn:setString("Password EditBox return !")
            elseif edit == EditEmail then
                TTFShowEditReturn:setString("Email EditBox return !")
            end
            --print(strFmt)
        elseif strEventName == "changed" then
            strFmt = string.format("editBox %p TextChanged, text: %s ", edit, edit:getText())
            --print(strFmt)
        end
    end
    
    self.account=cc.EditBox:create(cc.size(winsize.width-500,60),cc.Scale9Sprite:create(" "))
    self.account:setPosition(self.denglutab["accountBox"]:getPositionX()+5,self.denglutab["accountBox"]:getPositionY()-5) -- mymac减20,ipone减5
    self.account:setPlaceHolder("账号:")
    -- self.account:setPlaceholderFontColor(cc.c3b(255,255,255))
    self.account:setFontSize(24)
    self.account:setScaleX(0.5)
    -- self.m_zhanghao:setFontName("Paint Boy")
    self.account:setColor(cc.c4f(255,255,255,255))
    self.account:setMaxLength(16)
    self.account:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE )
    self.account:setInputMode(cc.EDITBOX_INPUT_MODE_EMAILADDR)
    self.denglutab["accountBox"]:getParent():addChild(self.account)
    
    -- local accountBg = createSprite("adla.png")
    -- accountBg:setAnchorPoint(cc.p(0,0))
    -- accountBg:setPosition(self.denglutab["accountBox"]:getPositionX(),self.denglutab["accountBox"]:getPositionY())
    -- self.denglutab["accountBox"]:getParent():addChild(accountBg)

    -- self.denglutab["accountBox"]:removeFromParent()
    -- self.denglutab["passwordBox"]:setScaleX((winsize.width-500)/self.denglutab["passwordBox"]:getContentSize().width)
    -- self.denglutab["passwordBox"]:setScaleY(60/self.denglutab["passwordBox"]:getContentSize().height)

    self.password = cc.EditBox:create(cc.size(winsize.width-500,60),cc.Scale9Sprite:create(""))
    self.password:setPosition(self.denglutab["passwordBox"]:getPositionX()+5,self.denglutab["passwordBox"]:getPositionY()) -- mymac减10,iphone减0
    -- self.password:setFontColor(cc.c3b(255,255,255))
    self.password:setScaleX(0.5)
    self.password:setFontSize(24)
    self.password:setPlaceHolder("密码:")
    self.password:setMaxLength(16)
    self.password:setInputFlag(cc.EDITBOX_INPUT_FLAG_PASSWORD)
    self.password:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
    self.denglutab["passwordBox"]:getParent():addChild(self.password)
    
    -- local passwordBg = createSprite("adla.png")
    -- passwordBg:setAnchorPoint(cc.p(0,0))
    -- passwordBg:setPosition(self.denglutab["passwordBox"]:getPositionX(),self.denglutab["passwordBox"]:getPositionY())
    -- self.denglutab["passwordBox"]:getParent():addChild(passwordBg)

    -- self.denglutab["passwordBox"]:removeFromParent()

    local userpassword = files.readFile("userpasswordfile.json")
    -- print("保存的玩家数据 = ",json.encode(userpassword))
    if userpassword and userpassword[#userpassword] and  userpassword[#userpassword].pwd and userpassword[#userpassword].id then
        self.account:setText(userpassword[#userpassword].pwd)
        self.password:setText(userpassword[#userpassword].id)
    end

end

-- 设置登陆功能按钮
function LoginView:setGongnnegButton()
    local function setHornCallback()
        UIJump:jumpTo("InformView")
    end
    -- 喇叭按钮
    self.hornButton = RequireModel.Button:create(self.gongnengtab["hornicon"]:getSpriteFrame(),self.gongnengtab["hornicon"]:getSpriteFrame())
    self.hornButton:setPosition(self.gongnengtab["hornicon"]:getPositionX(),self.gongnengtab["hornicon"]:getPositionY())
    self.gongnengtab["hornicon"]:getParent():addChild(self.hornButton)
    self.gongnengtab["hornicon"]:removeFromParent()
    self.gongnengtab["hornicon"] = nil

    self.hornButton:setCallback(setHornCallback)

    local function setSignCallback()
        UIJump:jumpTo("HelpView")
    end

    -- 感叹号按钮
    self.signButton = RequireModel.Button:create(self.gongnengtab["xinxiicon"]:getSpriteFrame(),self.gongnengtab["xinxiicon"]:getSpriteFrame())
    self.signButton:setPosition(self.gongnengtab["xinxiicon"]:getPositionX(),self.gongnengtab["xinxiicon"]:getPositionY())
    self.gongnengtab["xinxiicon"]:getParent():addChild(self.signButton)
    self.gongnengtab["xinxiicon"]:removeFromParent()
    self.gongnengtab["xinxiicon"] = nil
    self.signButton:setCallback(setSignCallback)

    local function setMusicCallback()
        UIJump:jumpTo("MusicSetView")
    end
    -- 音乐按钮
    self.musicButton = RequireModel.Button:create(self.gongnengtab["musicicon"]:getSpriteFrame(),self.gongnengtab["musicicon"]:getSpriteFrame())
    self.musicButton:setPosition(self.gongnengtab["musicicon"]:getPositionX(),self.gongnengtab["musicicon"]:getPositionY())
    self.gongnengtab["musicicon"]:getParent():addChild(self.musicButton)
    self.gongnengtab["musicicon"]:removeFromParent()
    self.gongnengtab["musicicon"] = nil
    self.musicButton:setCallback(setMusicCallback)
end

-- 设置登陆注册按钮
function LoginView:setLoginButton()
    local function LoginViewCallback()
        local zhanghao = self.account:getText()
        local mima = self.password:getText()
        -- print("帐号＝ ",zhanghao,"密码＝ ",mima)
        if zhanghao~=nil and zhanghao~="" and mima~=nil and mima~="" then
            -- if not self.mm then
            getCurrentRunNode().mm = mima
            getCurrentRunNode().zh = zhanghao
            -- -- print("Android = ",)
            -- RequireModel.BattleScene.becomeSPVE()
            -- UIJump:jumpTo(301)
            -- cc.CMessage:setFunction("DealPlayerLoginData")
            -- sendMessageToServer(SENDMESSAGEIDS.PostLoginId,zhanghao,mima)
            -- local function casss(movex)
            --     tspsss:setBonePosition(BATTLEENUM.MapCellBone.rb,movex, 0)
            --     tspsss:setBonePosition(BATTLEENUM.MapCellBone.lb,-200, 0)
            --    -- :setBonePos(  )
            -- end
            -- MoveAPointToPoint(0.2,-self.length, casss)
            
            -- GMData.getItem(511002)
            -- local function  dealdata(data)
                
            --     print("请求得到的数据 ",json.encode(data))
            -- end
            -- HttpSendpost( "http://localhost:9080/XZRY/senddata.jsp" ,data, dealdata)
            -- RequireModel.BattleScene.becomeSPVE()
            -- UIJump:jumpTo("BattleScene")

            cc.CMessage:setFunction("DealPlayerLoginData")
           sendMessageToServer(SENDMESSAGEIDS.PostLoginId,zhanghao,mima) 

            -- self.spine2:setPositionY(self.spine2:getPositionY()+1)
        end
    end

    self.loginButton = RequireModel.Button:create(self.denglutab["loginButton"]:getSpriteFrame(),self.denglutab["loginButton"]:getSpriteFrame())
    self.loginButton:setPosition(self.denglutab["loginButton"]:getPositionX(),self.denglutab["loginButton"]:getPositionY())
    self.loginButton.selectedSprite:setScale(1.1)
    self.dengccbnode:addChild(self.loginButton)
    self.denglutab["loginButton"]:removeFromParent()
    self.denglutab["loginButton"] = nil
    self.loginButton:setCallback(LoginViewCallback)

    local logincion = createSprite("ui_denglu/dl_login.png")
    logincion:setPosition(self.loginButton:getContentSize().width/2, self.loginButton:getContentSize().height/2)
    self.loginButton:addChild(logincion)

    local function setRsgisterCallback()
        
    end
    
    

    self.resgsterButton = RequireModel.Button:create(self.denglutab["registerButton"]:getSpriteFrame(),self.denglutab["registerButton"]:getSpriteFrame())
    self.resgsterButton:setPosition(self.denglutab["registerButton"]:getPositionX(),self.denglutab["registerButton"]:getPositionY())
    self.dengccbnode:addChild(self.resgsterButton)
    self.denglutab["registerButton"]:removeFromParent()
    self.denglutab["registerButton"] = nil
    self.resgsterButton:setCallback(setRsgisterCallback)

    local registercion = createSprite("ui_denglu/dl_register.png")
    registercion:setPosition(self.resgsterButton:getContentSize().width/2, self.resgsterButton:getContentSize().height/2)
    self.resgsterButton:addChild(registercion)

end

-- 设置背景ui
function LoginView:setBackGround()
    local loginLoadLayer = RequireModel.LoginLoadLayer.new(1)
     loginLoadLayer:setPosition(display.cx, display.cy)
     self:addChild(loginLoadLayer,100)
     loginLoadLayer:startLoadingTexture()

    local background = createSprite("ui_denglu/dengluditu.png")
    background:setPosition(winsize.width/2, winsize.height/2)
    self:addChild(background,-1)

    local logo = createSprite("ui_denglu/newlogo.png")
    logo:setPosition(logo:getContentSize().width/2+30, winsize.height-logo:getContentSize().height/2-30)
    self:addChild(logo,2)

    -- local virtory = createSprite("ui_denglu/vowofvictory.png")
    -- virtory:setPosition(logo:getContentSize().width/2+30, logo:getPositionY()-logo:getContentSize().height/2-10)
    -- self:addChild(virtory,2)

     local background = sp.SkeletonAnimation:create("d_cg1_a.skel","d_cg1_a.atlas")
    background:setPosition(winsize.width/2,winsize.height/2)
    self:addChild(background)
    background:setAnimation(0,"a3",true)

    local spine1 = sp.SkeletonAnimation:create("ui_cg_spine_100401.skel","ui_cg_spine_100401.atlas")
    spine1:setPosition(1000,-24)
    self:addChild(spine1)
    spine1:setAnimation(0,"a3",true)
    -- spine1:bianmohu()

    -- local logo1 = sp.SkeletonAnimation:create("ax_x/main_toy_1_c.skel","ax_x/main_toy_1_c.atlas")
    -- -- local logo1 = sp.SkeletonAnimation:create("main_tongyong_y2.skel","main_tongyong_y2.atlas")
    -- logo1:setPosition(winsize.width/2,winsize.height/2-100)
    -- self:addChild(logo1,99999)
    -- logo1:setAnimation(0,"endbuildani",true)
    -- logo1:bianmohu()

    -- self:setScale(0.6)
end


function LoginView:tianjiashijian()
    local function LoginViewchenggong()
        self:zhanghaomimacunchu()
        -- self:getParent():getApp():run(ZhandouScene)
    end


end

function LoginView:zhanghaomimacunchu()
    -- if Shuju.getInstance():getzhanghao()==self.m_zhanghao and Shuju.getInstance():getmima()==self.m_mima then
    --  return
    -- end
    -- Shuju.getInstance():setzhanghaomima(self.m_zhanghao:getText(),self.m_mima:getText())
end

return LoginView
