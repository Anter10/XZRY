local InformView = class("InformView", RequireModel.CommonLayerView)

function InformView:ctor()
	self.super.ctor(self)
	self:OpenTouch()
	self.currentpages = 1 --当前页数
	self:becomeBlackBackground()
	self:setSwallowTouches(true)
	self:addSwitchButton()
	self:initUI()
	self:initPageButton()
	self:addCloseButton()
end

function InformView:initUI()
	self.background = createSprite("UI_bottom/diban5.png")
	self.background:setScaleX(winsize.width/2/self.background:getContentSize().width)
	self.background:setScaleY(winsize.height/2/self.background:getContentSize().height)
	self.background:setPosition(winsize.width/2, winsize.height/2)
	self:addChild(self.background)

	self.backgroundrect = cc.rect(winsize.width/2-self.background:getContentSize().width/2, winsize.height/2-self.background:getContentSize().height/2, self.background:getContentSize().width, self.background:getContentSize().height)

	self:flushicon(self.currentpages)
end

-- 刷新数据
function InformView:flushicon(index)
	if self.heroicon then
		self.heroicon:removeFromParent()
		self.heroicon = nil
	end
	if index == 1 then
		self.leftbutton:setVisible(false)
	elseif index == 5 then
		self.rightbutton:setVisible(false)
	else
		self.leftbutton:setVisible(true)
		self.rightbutton:setVisible(true)
	end
	self.currentpages = index
	local imagename = "Hero_icon/ui_team_100"..index.."01.png"
	self.heroicon = createSprite(imagename)
	self.heroicon:setPosition(self.background:getContentSize().width/2, self.background:getContentSize().height/2)
	self.background:addChild(self.heroicon)
end

-- 初始化翻页按钮
function InformView:initPageButton()
	local parma = {dir = 1 , num = 5, rect = cc.rect(winsize.width/2-200, 100, 32, 32),callback = handler(self, self.flushicon) }
	self.radiobuttonnode = RequireModel.RadioButtonNode.new(parma)
	self.radiobuttonnode:setPosition(0,180)
	self.radiobuttonnode:initButton("radio_button_off.png", "radio_button_on.png", false)
	self:addChild(self.radiobuttonnode)
end

-- 左右切换按钮
function InformView:addSwitchButton()
	local function rightcallback()
		if self.currentpages == 5 then
			-- self.currentpages = 1
		else
			self.currentpages = self.currentpages + 1
			if self.currentpages == 5 then
    			self.rightbutton:setVisible(false)
    		else
    			self.leftbutton:setVisible(true)
    			self.rightbutton:setVisible(true)
    		end
		end
		self:flushicon(self.currentpages)
		self.radiobuttonnode:setButtonState(self.currentpages)
	end

	local function leftcallback()
		if self.currentpages == 1 then
			-- self.currentpages = 5
		else
			self.currentpages = self.currentpages - 1
			if self.currentpages == 1 then
    			self.leftbutton:setVisible(false)
    		else
    			self.rightbutton:setVisible(true)
    			self.leftbutton:setVisible(true)
    		end

		end
		self:flushicon(self.currentpages)
		self.radiobuttonnode:setButtonState(self.currentpages)
	end

	self.rightbutton = RequireModel.Button.new("UI_button/shuxingbian.png","UI_button/shuxingbian.png")
    self.rightbutton:setPosition(winsize.width*3/4, winsize.height/2)
    self:addChild(self.rightbutton)
    self.rightbutton:setCallback(rightcallback)

    self.leftbutton = RequireModel.Button.new("UI_button/shuxingbian.png","UI_button/shuxingbian.png")
    self.leftbutton:setScaleX(-1)
    self.leftbutton:setPosition(winsize.width/4, winsize.height/2)
    self:addChild(self.leftbutton)
    self.leftbutton:setCallback(leftcallback)


    if self.currentpages == 1 then
    	self.leftbutton:setVisible(false)
    elseif self.currentpages == 5 then
    	self.rightbutton:setVisible(false)
    end
end

-- 添加关闭按钮
function InformView:addCloseButton()
    local function closecallback()
        UIJump:backTo()
    end
    self.closebutton = RequireModel.Button.new("UI_button/btn_bt_back01.png","UI_button/btn_bt_back01.png")
    self.closebutton:setScale(0.5)
    self.closebutton:setPosition(winsize.width*3/4, winsize.height*3/4)
    self:addChild(self.closebutton)
    self.closebutton:setCallback(closecallback)
end

return InformView