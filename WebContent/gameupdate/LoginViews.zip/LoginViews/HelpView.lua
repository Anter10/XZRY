local HelpView = class("HelpView", RequireModel.CommonLayerView)

function HelpView:ctor()
	self.super.ctor(self)
	self:OpenTouch()
	self:becomeBlackBackground()
	self:setSwallowTouches(true)

	self:initui()
	self:addCloseButton()
end

function HelpView:initui()
	self.background = createSprite("UI_bottom/diban5.png")
	self.background:setScaleX(winsize.width/2/self.background:getContentSize().width)
	self.background:setScaleY(winsize.height/2/self.background:getContentSize().height)
	self.background:setPosition(winsize.width/2, winsize.height/2)
	self:addChild(self.background)

	self.backgroundrect = cc.rect(winsize.width/2-self.background:getContentSize().width/2, winsize.height/2-self.background:getContentSize().height/2, self.background:getContentSize().width, self.background:getContentSize().height)

end

-- 添加关闭按钮
function HelpView:addCloseButton()
    local function closecallback()
        UIJump:backTo()
    end
    self.closebutton = RequireModel.Button.new("UI_button/btn_bt_back01.png","UI_button/btn_bt_back01.png")
    self.closebutton:setScale(0.5)
    self.closebutton:setPosition(winsize.width*3/4, winsize.height*3/4)
    self:addChild(self.closebutton)
    self.closebutton:setCallback(closecallback)
end

return HelpView