local MusicSetView = class("MusicSetView", RequireModel.CommonLayerView)

function MusicSetView:ctor()
	self.super.ctor(self)
	self:OpenTouch()
	self:becomeBlackBackground()
	self:setSwallowTouches(true)

	self:initui()
	self:addCloseButton()
end

function MusicSetView:initui()
	self.background = createSprite("UI_bottom/diban5.png")
	self.background:setScaleX(winsize.width/2/self.background:getContentSize().width)
	self.background:setScaleY(winsize.height/2/self.background:getContentSize().height)
	self.background:setPosition(winsize.width/2, winsize.height/2)
	self:addChild(self.background)

	self.backgroundrect = cc.rect(winsize.width/2-self.background:getContentSize().width/2, winsize.height/2-self.background:getContentSize().height/2, self.background:getContentSize().width, self.background:getContentSize().height)

	local function selectedEvent(sender,eventType)
        if eventType == ccui.CheckBoxEventType.selected then
            self._displayValueLabel:setString("Selected")
        elseif eventType == ccui.CheckBoxEventType.unselected then
            self._displayValueLabel:setString("Unselected")
        end
    end
	local checkBox = ccui.CheckBox:create()
    checkBox:setTouchEnabled(true)
    checkBox:setSelectedState(true)
    checkBox:loadTextures("UI_temp/check_box_normal.png",
                                  "UI_temp/check_box_normal_press.png",
                                  "UI_temp/check_box_active.png",
                                  "UI_temp/check_box_normal_disable.png",
                                  "UI_temp/check_box_active_disable.png")
    checkBox:setPosition(cc.p(self.backgroundrect.width/2, self.backgroundrect.height/2-50))
    checkBox:addEventListener(selectedEvent)

    self.background:addChild(checkBox)

    local function percentChangedEvent(sender,eventType)
                if eventType == ccui.SliderEventType.percentChanged then
                    local slider = sender
                    local percent = "Percent " .. (slider:getPercent() / slider:getMaxPercent() * 100)
                    self._displayValueLabel:setString(percent)
                elseif eventType == ccui.SliderEventType.slideBallUp then
                    self._displayValueLabel:setString("Slide Ball Up")
                elseif eventType == ccui.SliderEventType.slideBallDown then
                    self._displayValueLabel:setString("Slide Ball Down")
                elseif eventType == ccui.SliderEventType.slideBallCancel then
                    self._displayValueLabel:setString("Slide Ball Cancel")
                end
            end

    local slider = ccui.Slider:create()
    slider:setTouchEnabled(true)
    slider:loadBarTexture("UI_temp/sliderTrack.png")
    slider:loadSlidBallTextures("UI_temp/sliderThumb.png", "UI_temp/sliderThumb.png", "")
    slider:loadProgressBarTexture("UI_temp/sliderProgress.png")
    slider:setPosition(cc.p(self.backgroundrect.width/2, self.backgroundrect.height/2+20))
    slider:setMaxPercent(10000)
    slider:addEventListener(percentChangedEvent)

    self.background:addChild(slider)
end

-- 添加关闭按钮
function MusicSetView:addCloseButton()
    local function closecallback()
        UIJump:backTo()
    end
    self.closebutton = RequireModel.Button.new("UI_button/btn_bt_back01.png","UI_button/btn_bt_back01.png")
    self.closebutton:setScale(0.5)
    self.closebutton:setPosition(winsize.width*3/4, winsize.height*3/4)
    self:addChild(self.closebutton)
    self.closebutton:setCallback(closecallback)
end

return MusicSetView