local ChatView = class("ChatView", RequireModel.CommonFullSceneUI)

function ChatView:ctor()
	self.super.ctor(self)

	self.currentlayerindex = 1   -- 当前选择的按钮类型
	self:init()
end

function ChatView:init()
	self.background = createSprite("UI_bottom/beijing.png")
	self.background:setPosition(winsize.width/2, winsize.height/2)
	self:addChild(self.background)

	self.middlebottom = createSprite("diban322.png")
	self.middlebottom:setPosition(winsize.width/2, winsize.height/2)
	self:addChild(self.middlebottom)

	self.middlesize = self.middlebottom:getContentSize()

	self:addTypeButton()
	self:setInputBox()
	self:initChatContent()
	self:setCloseButton()
end

-- 添加分类按钮
function ChatView:addTypeButton()
	local function buttoncallback(index)
		if self.currentlayerindex == index then
			
		else
			self:flushChatData(index)
			-- self.mailslidenode:restartView(self.models)
			self.currentlayerindex = index
		end		
	end 
	self.radioButtonnode = RequireModel.RadioButtonNode.new({dir = 2, num = 4, rect = cc.rect(0,0,83,43), callback = buttoncallback, labelname = {"系统", "世界", "工会", "队伍"}})
	self.radioButtonnode:setPosition(200, winsize.height*3/4+80)
	self:addChild(self.radioButtonnode)
	self.radioButtonnode:initButton("shanganniu.png", "shanganniu.png",true)
end

-- 初始化聊天内容
function ChatView:initChatContent()
	self:createChatItem()
	self.maildata = {
      	dir    = 2,                            -- listview摆放方向
      	size   = cc.size(600,360),             -- 视图大小
      	models = self.models,                  -- listview加载视图
      	leftcall = nil,                        -- 滑动到最左边回调函数
      	rightcall = nil,                       -- 滑动到最右边回调函数
      	upcall =nil,                           -- 滑动到最上边回调函数
      	bottomcall = nil,                      -- 滑动到最下面回调函数

      	leftbuttoncall = func,                 -- 上下按钮回调函数
  
      	background = "UI_bottom/diban321.png", -- listview背景图片
      	MagneticType = 1,                      -- 视图放置类型
      	bounce       = true,                   -- 是否弹性回复
  	}

	self.mailslidenode = RequireModel.ListviewNode.new(self.maildata)
	self.mailslidenode:setPosition(0,60)
	self.middlebottom:addChild(self.mailslidenode)
	self:createChatItem("hello world", 1)
end

-- 刷新聊天内容
function ChatView:flushChatData(index)
	
end

-- 创建聊天item
function ChatView:createChatItem(content, dir)
	self.models = {}
	local itemlayer
	local contentlabel
	if content then
		itemlayer = cc.Layer:create()
		itemlayer:setContentSize(cc.size(600,60))
		contentlabel = cc.LabelTTF:create(content, "Arial", 24)
		contentlabel:setAnchorPoint(cc.p(0,0))
		if dir == 1 then
			contentlabel:setPosition(0,30)
		else
			contentlabel:setPosition(600-contentlabel:getContentSize().width,30)
		end
		itemlayer:addChild(contentlabel)
		-- contentlabel = Font.getTextLabel(content, 24,nil,nil,1,nil,cc.p(0, 0),itemlayer,cc.p(0,30),1,false)
		-- print("size = ", contentlabel:getContentSize().width, contentlabel:getContentSize().height)
		self.mailslidenode:insertAndFlushData(itemlayer)
	end
end

-- 设置输入框
function ChatView:setInputBox()
	self.inputbox=cc.EditBox:create(cc.size(300,60),cc.Scale9Sprite:create(" "))
    self.inputbox:setPosition(240, 30)
    self.inputbox:setPlaceHolder("点击输入:")
    self.inputbox:setPlaceholderFontColor(cc.c3b(255,255,255))
    self.inputbox:setFontSize(24)
    self.inputbox:setScaleX(0.5)
    -- self.m_zhanghao:setFontName("Paint Boy")
    self.inputbox:setFontColor(cc.c3b(255,0,0))
    self.inputbox:setMaxLength(16)
    self.inputbox:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE )
    self.inputbox:setInputMode(cc.EDITBOX_INPUT_MODE_EMAILADDR)
    self.middlebottom:addChild(self.inputbox)

    local function sendCallback()
    	local content = self.inputbox:getText()
    	print("发送内容:", content)
    	self:createChatItem(content, 2)
    	self.inputbox:setText("")
    	self:createChatItem("hello world", 1)
    end

    self.sendbutton = RequireModel.Button:create("ui_bt_headdi_01.png","ui_bt_headdi_01.png",nil,"发送")
    self.sendbutton:setPosition(self.middlesize.width - self.sendbutton:getContentSize().width/2, self.sendbutton:getContentSize().height/2)
    self.sendbutton:setCallback(sendCallback)
    self.middlebottom:addChild(self.sendbutton)
end

-- 添加关闭按钮
function ChatView:setCloseButton()
    local function closecallback()
        UIJump:backTo()
    end
    self.closebutton = RequireModel.Button.new("UI_button/btn_bt_back01.png","UI_button/btn_bt_back01.png")
    self.closebutton:setScale(0.5)
    self.closebutton:setPosition(winsize.width - self.closebutton:getContentSize().width/2, winsize.height-self.closebutton:getContentSize().height/2)
    self:addChild(self.closebutton)
    self.closebutton:setCallback(closecallback)
end

return ChatView