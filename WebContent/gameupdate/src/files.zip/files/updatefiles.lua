local updatefiles = {}
 

-- version:版本号 data该版本更新的资源
updatefiles.allversion = {
	{
	    version = "0.0.1", data = {"res/","src/"}
    }
}


return updatefiles